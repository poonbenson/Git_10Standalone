winTitlePrefix = 'BigKeeper_20261016F'
#winTitlePrefix = 'BigKeeper_20250810a - For Release'
#This have to match the line in the launcher.bat lines, to keep launcher singleton:
#taskkill /FI "WINDOWTITLE eq BigKeeper_*" /F
#start /min cmd /c python N:\bpPipeline\bigKeeperPy\bigKeeperPySide6_standalone.py

# To print-message by with line number
from inspect import currentframe
def println(inContent = '-'):
    print('{} : {}'.format(currentframe().f_back.f_lineno, inContent))

import subprocess, os, sys, time, pathlib, shutil
println('PYTHON version : {}'.format(sys.version))

# path of bigKeeperTest_publish : N:\BigKeeper
# WIP of bigKeeperTest_publish : I:\iCloud~com~omz-software~Pythonista3\pySide2UI\wip

# To import PySide2 QT modules
'''
from PySide2.QtWidgets import *
from PySide2.QtCore import *
from PySide2.QtGui import *
'''

# To import PySide6 QT modules
from PySide6.QtWidgets import *
from PySide6.QtCore import *
from PySide6.QtGui import *



# To import standard modules



if sys.version_info.major >= 3:
    import configparser


# ref: https://www.daniweb.com/programming/software-development/threads/265576/how-can-i-specify-the-size-of-the-python-command-line-window-in-my-code
os.system("mode con cols=100 lines=10")

# To import XML modules
import xml.etree.ElementTree as ET

# To determine current software environment at
sys.path.append(r'N:\bpPipeline\bigKeeperPy\py\BigKeeperGlob\wip\published')
import bigCodingAssistant_published
CurrentSoftwareName = bigCodingAssistant_published.tool().bigCheckSoftware()

println('PYTHON version : {}'.format(sys.version))


import bigKeeperInfoGlobal_published
getBigKInfo = bigKeeperInfoGlobal_published.bigKeepCLASS()
println('currentSoftwareName is: {}'.format(CurrentSoftwareName))

try:
    println('__file__:')
    println(__file__)
    thisPyPath = __file__
except:
    println('sys argv:')
    println(sys.argv[0])
    println('sys argv done')
    thisPyPath = sys.argv[0]

# Pre-Define Global Variables
pathOfIconPathsStudio = r'N:\bpPipeline\bigKeeperPyIni\bigPathsStudio.ini'

edgePath = r'C:\Program Files (x86)\Microsoft\Edge\Application\msedge.exe'
edgeShotlistProfilePath = r'C:\localScript\edgeShotlistProfile'
publicGmailLoginPath = r'N:\bpPipeline\bigKeeperPyIni\bpuserpublicGmail\login.txt'
publicGmailPasswordPath = r'N:\bpPipeline\bigKeeperPyIni\bpuserpublicGmail\password.txt'

# To determine current version mode (developer, tester or release)
pathOfDeveloper = r'N:\bpPipeline\bigKeeperPy\repo_01Developer'
pathOfTester = r'N:\bpPipeline\bigKeeperPy\repo_03Tester'
pathOfRelease = r'N:\bpPipeline\bigKeeperPy\repo_09Release'
pathOfEnvIni = r'N:\bpPipeline\bigKeeperPyIni\env.ini'




thisPath = (os.path.dirname(os.path.abspath(thisPyPath)))
println('this Path ' + thisPath)


if thisPath == pathOfDeveloper:
    bannerImage = r"N:\bpPipeline\bigKeeperPy\bigKeeperPyIcon_developer.jpg"
    uiPath = os.path.join(pathOfDeveloper, 'ui')
    iconPath = os.path.join(pathOfDeveloper, 'icon')
elif thisPath == pathOfTester:
    bannerImage = r"N:\bpPipeline\bigKeeperPy\bigKeeperPyIcon_tester.jpg"
    uiPath = os.path.join(pathOfTester, 'ui')
    iconPath = os.path.join(pathOfTester, 'icon')
elif thisPath == pathOfRelease:
    bannerImage = r"N:\bpPipeline\bigKeeperPy\bigKeeperPyIcon_release.jpg"
    uiPath = os.path.join(pathOfRelease, 'ui')
    iconPath = os.path.join(pathOfRelease, 'icon')
else:
    #eg. for In Python IDE, Standalone
    bannerImage = r"N:\bpPipeline\bigKeeperPy\bigKeeperPyIcon_InPythongOrDCC.jpg"
    uiPath = os.path.join(pathOfRelease, 'ui')
    iconPath = os.path.join(pathOfRelease, 'icon')

import bigKeeperInfoGlobal_published

#bigKInfo = bigKeeperInfoGlobal_published.bigKeepCLASS()

# To import compiled UI that created from QT Designer

#sys.path.append(r'N:\bpPipeline\bigKeeperPy')
#import bigKeeperPyUi as UiPy # path of compiled py : N:\BigKeeper          WIP : N:\BigKeeper\py\pySide2UI\ui
#import childMenu as UiPyChild # path : N:\BigKeeper         WIP : N:\BigKeeper\py\pySide2UI\ui
#import listView as UiList  # path : N:\BigKeeper         WIP : N:\BigKeeper\py\pySide2UI\ui
#sys.path.remove(r'N:\bpPipeline\bigKeeperPy')



sys.path.append(uiPath)
sys.path.append(r'N:\bpPipeline\bigKeeperPy\py\pySide2UI\ui')

# For PySide2 UI
#import bigKeeperPyUi_newLayout as UiPy
#import childMenu as UiPyChild # path : N:\BigKeeper         WIP : N:\BigKeeper\py\pySide2UI\ui
#import listView_dev as UiList
#import listViewB as UiListB
#import DialogWindow as UiDialog # path : N:\BigKeeper\py\pySide2UI\ui        WIP : I:\iCloud~com~omz-software~Pythonista3\pySide2UI\ui
#import doneWindow as UiDone
#import nukeReadNodeFrameInOut as UiNukeTemp
#import newTaskWindow as UiNewTask
#import presetWindow as UiPreset


# For PySide6 UI
import bigKeeperPyUi_PySide6_newLayout as UiPy
import childMenu_PySide6 as UiPyChild # path : N:\BigKeeper         WIP : N:\BigKeeper\py\pySide2UI\ui
import listView_dev_PySide6 as UiList
import listViewB_PySide6 as UiListB
import DialogWindow_PySide6 as UiDialog # path : N:\BigKeeper\py\pySide2UI\ui        WIP : I:\iCloud~com~omz-software~Pythonista3\pySide2UI\ui
import doneWindow_PySide6 as UiDone
import nukeReadNodeFrameInOut_PySide6 as UiNukeTemp
import newTaskWindow_PySide6 as UiNewTask
import presetWindow_PySide6 as UiPreset

sys.path.remove(uiPath)
sys.path.remove(r'N:\bpPipeline\bigKeeperPy\py\pySide2UI\ui')






sys.path.append(r'N:\bpPipeline\bigKeeperPy\py\externalPyModule')



# To initiate current software environment variables
externalToolPath = r'N:\bpPipeline\bigKeeperPy\py\externalTool'
#rvPath = r'C:\Program Files\Shotgun\RV-2021.0.0\bin\rv.exe'
rvTemplate = r'N:\bpPipeline\rv\_bigkeeperPyData\rv.template'

# robocopy flags shared by every template-tree create.
# /E   copy sub-folders including the empty ones, which is all these templates are
# /NFL /NDL /NJH /NJS   silence the file list, folder list, job header and job summary
# /MT:16   multi-thread
# /R:1 /W:1   retry once and wait one second. The default is 1,000,000 retries at 30
#             seconds each, which would hang a create for days on a single locked folder.
roboCopyFlags = r'/E /NFL /NDL /NJH /NJS /MT:16 /R:3 /W:5'

taskTypeNotSelected = '-----'
# The first row of taskTypeShotPreset.txt / taskTypeAssetPreset.txt.
# Keeps the comboBox showing nothing chosen, OK rejects it.

pinnedProjectNames = ('BigAssetCollections',)
# The projects that always sit at the top of the Project Name comboBox

visualBoardExtension = '.pur'
# The PureRef file the Visual Board buttons open. The board is named after the folder it sits
# in, and it is opened through its Windows file association.

rvSessionStorageRootPath = r'K:\z_RvSession'
# Every RV session (.rv) lives here, mirroring the project tree under its own project folder :
# K:\z_RvSession\ChanFilm\scenes\Sc01TramSeq\CG0010\components\comp\output\v0005.rv. The folder
# RV reviews on the job drive keeps a Windows shortcut, v0005.rv.lnk, pointing back here. Same as
# the Visual Board, nothing checks that K: is mapped.

visualBoardStorageRootPath = r'K:\z_VisualBoard'
# Every Visual Board lives here, mirroring the project tree under its own project folder :
# K:\z_VisualBoard\ChanFilm\lib\bldg5060s\bldg5060s.pur. The matching folder on the job drive
# keeps a Windows shortcut pointing back here. Nothing checks that K: is mapped -- an unmapped
# drive fails on the spot with its own error.

freeLayerMaskType = 'FreeLayerMask'
# The inType of the Free LayerMask Write node, and the tail of its version folder name :
# v0007_FreeLayerMask. nukeBornWriteNode builds the folder, nukeUpdateWriteNodeVer finds
# the four version digits by looking backwards from this word instead of rebuilding the path.

bigKWriteTypeKnobName = 'bigKWriteType'
# User knob stamped on every bigK Write node at birth, holding its inType.
# Nodes made before this knob existed return None, which is exactly "not special".

# the four version digits by looking backwards from this word instead of rebuilding the path.

bigKWriteTypeKnobName = 'bigKWriteType'
# User knob stamped on every bigK Write node at birth, holding its inType.
# Nodes made before this knob existed return None, which is exactly "not special".

lightQCType = 'LightQC'
lightQCBackdropName = 'bigK_' + lightQCType
lightQCPublishFolderName = 'published' + lightQCType
# The LightQC step, renamed from LightPublish. One word drives the backdrop inType, the
# backdrop node name (bigK_LightQC), and the folder it copies into (publishedLightQC).
# Nothing reads the old bigK_lightPublish backdrop or the old publishedLightPreRend folder --
# lightQCCopyAction tells the artist to re-build the backdrop instead.

compWriteNodePresetFileName = 'compWriteNodePreset.txt'
# The per project Write node preset, in the project work folder next to compPrerendPreset.txt
8# and the two taskType preset files. One preset per line.

compWriteNodeSingleFileTypes = ['mov', 'mp4', 'mxf']



compWriteNodePresetFileName = 'compWriteNodePreset.txt'
# The per project Write node preset, in the project work folder next to compPrerendPreset.txt
# and the two taskType preset files. One preset per line.

compWriteNodeSingleFileTypes = ['mov', 'mp4', 'mxf']
# File types that write one single file instead of a frame sequence, so the .%04d frame padding is dropped from the path.

in_nuke = None
in_maya = None
in_houdini = None
in_blender  = None
in_python = None
nukeWrongFormatProj = ['WOF', 'PoonFilm']
bigKeeperCacheFolderPath = os.path.join(os.environ['LOCALAPPDATA'], 'bigKeeperPy')

println(os.path.isdir(bigKeeperCacheFolderPath))
if not os.path.isdir(bigKeeperCacheFolderPath):
    os.mkdir(bigKeeperCacheFolderPath)
println(os.path.isdir(bigKeeperCacheFolderPath))


if CurrentSoftwareName == 'nuke':

    in_nuke = True
    import nuke
    import nukescripts
    cacheProjName = r'projCache_nuke.txt'
    wipExtension = r'.nk'
elif CurrentSoftwareName == 'maya':
    in_maya = True
    import maya.cmds as cmds
    cacheProjName = r'projCache_maya.txt'
    wipExtension = r'.mb'
elif CurrentSoftwareName == 'houdini':
    in_houdini = True
    import hou
    cacheProjName = r'projCache_houdini.txt'
    wipExtension = r'.hip'
elif CurrentSoftwareName == 'blender':
    in_blender = True
    import bpy
    cacheProjName = r'projCache_blender.txt'
    wipExtension = r'.blend'
elif CurrentSoftwareName == 'python':
    in_python = True
    cacheProjName = r'projCache_python.txt'
    wipExtension = r'.py'

themeWindowColor = QColor(239, 239, 239)
themeBaseColor = QColor(255, 255, 255)
themeTextColor = QColor(0, 0, 0)
themeHighlightColor = QColor(48, 140, 198)
themeDisabledTextColor = QColor(190, 190, 190)

def standalonePaletteBuild():
    palette = QApplication.style().standardPalette()
    palette.setColor(QPalette.Window, themeWindowColor)
    palette.setColor(QPalette.WindowText, themeTextColor)
    palette.setColor(QPalette.Base, themeBaseColor)
    palette.setColor(QPalette.ToolTipText, themeTextColor)
    palette.setColor(QPalette.Text, themeTextColor)
    palette.setColor(QPalette.Button, themeWindowColor)
    palette.setColor(QPalette.ButtonText, themeTextColor)
    palette.setColor(QPalette.Highlight, themeHighlightColor)
    palette.setColor(QPalette.Disabled, QPalette.Text, themeDisabledTextColor)
    palette.setColor(QPalette.Disabled, QPalette.ButtonText, themeDisabledTextColor)
    return palette

if in_python:
    try:
        app = QApplication()
        app.setStyle('Fusion')
        app.setPalette(standalonePaletteBuild())
    except:
        pass
else:
    pass

println(cacheProjName)



# The QT MainWindow Class
class BigMainWindow(UiPy.Ui_MainWindow, QMainWindow):

    dlg_instance = None # maintain a single instance of the dialog in Production
    @classmethod
    def show_window(cls):
        try:
            if not cls.dlg_instance:
                cls.dlg_instance = BigMainWindow()

            if cls.dlg_instance.isHidden():
                cls.dlg_instance.show()
            else:
                cls.dlg_instance.raise_()
                cls.dlg_instance.activateWindow()
        except:
            window = BigMainWindow()
            window.show()


    def SoftwareMainWindow(self):
        self.main_window_ptr = QApplication.activeWindow()
        return self.main_window_ptr

    def __init__(self):
        super(BigMainWindow, self).__init__(parent = self.SoftwareMainWindow())
        self.setupUi(self)
        #self.setWindowTitle(r'BigKeeper Py - alpha version - Developer Mode')
        #WindowTitleName = winTitlePrefix + ' BigKeeperPy-alpha ' + os.path.basename(thisPath)
        WindowTitleName = winTitlePrefix + ' PySide6 - ' + os.path.basename(thisPath)
        self.setWindowTitle(WindowTitleName)
        self.setWindowIcon(QIcon(os.path.join(iconPath, 'standalone6.png')))
        self.prerendKeyword = ""

        #self.label_9.setPixmap(QPixmap(r"N:/bpPipeline/bigKeeperPy/bigKeeperPyIcon_developer.jpg"))
        self.label_9.setPixmap(QPixmap(bannerImage))
        self.label_9.setScaledContents(False)
        self.label_mayaIcon.setPixmap(QPixmap(os.path.join(iconPath, 'maya.png')))
        self.label_mayaIcon.setScaledContents(True)
        self.label_nukeIcon.setPixmap(QPixmap(os.path.join(iconPath, 'nuke.png')))
        self.label_nukeIcon.setScaledContents(True)
        self.label_houdiniIcon.setPixmap(QPixmap(os.path.join(iconPath, 'houdini.png')))
        self.label_houdiniIcon.setScaledContents(True)

        self.horizontalSlider_echoSwitch.setRange(0,2)
        #self.horizontalSlider_echoSwitch.valueChanged.connect(self.printEcho)
        self.horizontalSlider_echoSwitch.valueChanged.connect(self.printEchoUIFeedback)
        self.horizontalSlider_echoSwitch.valueChanged.connect(self.echoSwitchOtherAction)

        # The parent folder last picked for a FreeLayerMask Write node. This session only.
        self.freeLayerMaskLastFolder = ''

        # The preset line last picked for a Write node. This session only.
        self.compWriteNodePresetLastChoice = ''

        self.comboBoxEntries = self.listBigKeeperProject()
        self.comboBoxEntries.sort()

        # The pinned projects sit at the top of the comboBox, in the order written in
        # pinnedProjectNames. It is comboBoxEntries that is reordered, never the widget :
        # the comboBox fires activated[int] and comboBoxAction2 turns that index back into
        # a project name through this very list, so the two must stay in the same order.
        # A name that is not in the list is skipped, an xml entry can be renamed, and
        # listBigKeeperProject drops any project whose path is off the N drive.
        pinnedEntries = []
        for eachPinnedName in pinnedProjectNames:
            if eachPinnedName in self.comboBoxEntries:
                pinnedEntries.append(eachPinnedName)
                self.comboBoxEntries.remove(eachPinnedName)

        self.comboBoxEntries = pinnedEntries + self.comboBoxEntries

        self.comboBoxProjects.addItems(self.comboBoxEntries)
        self.pushButton_2.clicked.connect(self.launchProjExplorer)

        # prepare for storing and reload last selected project
        previousSelDetail = self.readProjCache()
        previousProj = previousSelDetail[0]
        println('previousProj is :')
        println(previousProj)

        try:
            self.comboBoxProjects.setCurrentText(previousProj)
            self.comboBoxAction2(previousProj)
        except:
            pass


        #self.comboBoxProjects.activated.connect(self.comboBoxAction1) #show position of the items

        #PySide2 works as String
        #self.comboBoxProjects.activated[str].connect(self.comboBoxAction2) #show content of the items as a string
        #PySide6 not works as String but int
        self.comboBoxProjects.activated[int].connect(self.comboBoxAction2) #show content of the items as a int

        self.listWidget_1.itemClicked.connect(lambda : self.listWidget_2_appear2(self.listWidget_1.currentItem(), 'typeScene'))
        self.listWidget_AssetType.itemClicked.connect(lambda : self.listWidget_2_appear2(self.listWidget_AssetType.currentItem(), 'typeLib'))
        self.listWidget_1.setSortingEnabled(True)
        self.listWidget_AssetType.setSortingEnabled(True)

        self.listWidget_2.itemClicked.connect(lambda : self.listWidget_3_appear(self.listWidget_2.currentItem(), 'typeScene'))
        self.listWidget_Asset.itemClicked.connect(lambda : self.listWidget_3_appear(self.listWidget_Asset.currentItem(), 'typeLib'))
        self.listWidget_2.setSortingEnabled(True)
        self.listWidget_Asset.setSortingEnabled(True)

        self.listWidget_3.itemClicked.connect(lambda : self.listWidget_shotTask_action(self.listWidget_3.currentItem(), 'typeScene'))
        self.listWidget_AssetTask.itemClicked.connect(lambda : self.listWidget_shotTask_action(self.listWidget_AssetTask.currentItem(), 'typeLib'))
        #self.listWidget_3.itemDoubleClicked.connect(self.listWidget_3B_action)
        self.listWidget_3.itemDoubleClicked.connect(lambda : self.listWidget_3C_action(self.listWidget_3.currentItem(), 'typeScene'))
        self.listWidget_AssetTask.itemDoubleClicked.connect(lambda : self.listWidget_3C_action(self.listWidget_AssetTask.currentItem(), 'typeLib'))
        self.listWidget_3.setSortingEnabled(True)
        self.listWidget_AssetTask.setSortingEnabled(True)

        #self.pushButton_listWidget1Refresh.clicked.connect(self.listWidget_1_appear)
        self.pushButton_listWidget1Refresh.clicked.connect(lambda : self.listWidget_1_appear('typeScene'))
        self.pushButton_listWidgetAssetRefresh.clicked.connect(lambda : self.listWidget_1_appear('typeLib'))

        self.listWidget_1.setSelectionMode(QListWidget.ExtendedSelection)

        #self.pushButton_newSeq.clicked.connect()
        #self.pushButton_newShot.clicked.connect()
        #self.pushButton_newShotBatch.clicked.connect()
        #self.pushButton_newScnTask.clicked.connect(self.createShotNewTask_appear)
        self.pushButton_newScnTask.clicked.connect(lambda : self.newTaskKeywordShow('typeScene'))
        self.pushButton_newScnTask.setDisabled(True)

        self.pushButton_newAssetTask.clicked.connect(lambda : self.newTaskKeywordShow('typeLib'))
        self.pushButton_newAssetTask.setDisabled(True)

        #nukeLabel = self.envRead('NUKE', 'label')
        #mayaLabel = self.envRead('MAYA', 'label')

        self.pushButton_LaunchMaya2022_update0.clicked.connect(self.launchStudioEnvMaya)
        self.pushButton_LaunchMaya2022_update0.setText(self.envRead('MAYA', 'label'))
        #self.pushButton_LaunchNuke13_0_v2.clicked.connect(self.launchStudioEnvNuke)
        self.pushButton_LaunchNuke13_0_v2.clicked.connect(self.launchStudioEnvNuke)
        self.pushButton_LaunchNuke13_0_v2.setText(self.envRead('NUKE', 'label'))

        #Temp workaround !!!!!!!!!! #Temp workaround !!!!!!!!!! #Temp workaround !!!!!!!!!! #Temp workaround !!!!!!!!!!
        #if os.path.isdir(r'c:\Program Files\Nuke13.0v3'):
            #self.pushButton_LaunchNuke13_0_v2.setText(nukeLabel)
        self.pushButton_LaunchNukeX13_0_v2.clicked.connect(self.launchStudioEnvNukeX)
        self.pushButton_LaunchNukeX13_0_v2.setEnabled(True)
        self.pushButton_LaunchNukeAssist13_0_v2.clicked.connect(self.launchStudioEnvNukeAssist)
        self.pushButton_LaunchNukeAssist13_0_v2.setEnabled(True)
        self.pushButton_LaunchNukeStudio13_0_v2.clicked.connect(self.launchStudioEnvNukeStudio)
        self.pushButton_LaunchNukeStudio13_0_v2.setEnabled(True)
        self.pushButton_LaunchHieroPlayer.clicked.connect(self.launchStudioEnvNukeStudioHiero)
        self.pushButton_LaunchHieroPlayer.setEnabled(True)
        self.pushButton_LaunchHieroPlayer.setText(self.envRead('HIERO', 'label'))

        self.pushButton_launchHoudini1.clicked.connect(self.launchStudioEnvHoudini)
        self.pushButton_launchHoudini1.setText(self.envRead('HOUDINI', 'label'))


        self.pushButton_LaunchMayaLegacySelection.clicked.connect(self.launchMayaLegacySelection)
        self.pushButton_mayaOther.setText(self.envRead('MAYA', 'Legacy\nSelDisplay'))
        self.pushButton_mayaOther.clicked.connect(self.launchStudioEnvMayaFolder)
        self.pushButton_mayaOther.setText(self.envRead('MAYA', 'batFolderPathLabel'))
        self.pushButton_nukeOther.clicked.connect(self.launchStudioEnvNukeFolder)
        self.pushButton_nukeOther.setText(self.envRead('NUKE', 'batFolderPathLabel'))
        self.pushButton_houdiniOther.clicked.connect(self.launchStudioEnvHoudiniFolder)
        self.pushButton_houdiniOther.setText(self.envRead('HOUDINI', 'batFolderPathLabel'))
        self.pushButton_hieroPlayerOther.clicked.connect(self.launchStudioEnvNukeStudioHieroOther)
        self.pushButton_hieroPlayerOther.setText(self.envRead('HIERO', 'batFolderPathLabel'))

        self.pushButton_dailyFolder.clicked.connect(self.launchDailyFolder)
        self.pushButton_dailyFolder2.clicked.connect(self.launchDailyFolder)

        self.pushButton_LaunchCpuCoreController.clicked.connect(lambda: self.deadlineCoreOverride())
        self.pushButton_LaunchCpuCoreController.setText('Deadline CPU\nController')
        self.pushButton_LaunchGpuCoreController.clicked.connect(lambda: self.deadlineCoreOverrideGPU())
        self.pushButton_LaunchGpuCoreController.setText('Deadline GPU\nController')


        self.checkBox.toggled.connect(self.publicGmailCheckBoxAction)
        self.checkBox.setChecked(True)
        self.publicGmailCheckBoxAction()

        self.pushButton.clicked.connect(self.copyPublicGmailLogin)
        self.pushButton_3.clicked.connect(self.copyPublicGmailPassword)



        self.pushButton_shotlist.clicked.connect(self.launchShotlist)
        self.pushButton_shotlist.setText(self.iconPathRead(pathOfIconPathsStudio, 'SHOTLIST', 'label'))

        self.pushButton_roughcut.clicked.connect(self.launchRoughcut)
        self.pushButton_roughcut.setText(self.iconPathRead(pathOfIconPathsStudio, 'ROUGHCUT', 'label'))

        self.pushButton_commentClient.clicked.connect(self.launchCommentClient)
        self.pushButton_commentClient.setText(self.iconPathRead(pathOfIconPathsStudio, 'COMMENTCLIENT', 'label'))
        self.pushButton_commentInternal.clicked.connect(self.launchCommentInternal)

        self.pushButton_miscCookbook.clicked.connect(self.launchMiscCookbook)
        self.pushButton_miscCookbook.setText(self.iconPathRead(pathOfIconPathsStudio, 'LEARNING', 'label'))

        self.pushButton_miscLoginInfo.clicked.connect(self.launchMiscLoginInfo)
        self.pushButton_miscLoginInfo.setText(self.iconPathRead(pathOfIconPathsStudio, 'LOGINS', 'label'))

        self.pushButton_miscStaffContact.clicked.connect(self.launchStaffContact)
        self.pushButton_miscStaffContact.setText(self.iconPathRead(pathOfIconPathsStudio, 'STAFFCONTACT', 'label'))


        self.pushButton_sender.clicked.connect(self.launchbigSyncSender)
        self.pushButton_Watcher.clicked.connect(self.launchbigSyncWatcher)





        self.pushButton_7zip.clicked.connect(self.myAction2)
        self.pushButton_action1.clicked.connect(self.myAction3)
        #self.pushButton_action1.clicked.connect(self.dialog)

        self.pushButton_19.clicked.connect(lambda : self.assetShotExploreAction('typeScene'))
        self.pushButton_20.clicked.connect(lambda : self.assetShotExploreAction('typeLib'))

        self.pushButton_vBoardShotTab.clicked.connect(lambda : self.visualBoardAction('typeScene', 'levelRoot'))
        self.pushButton_vBoardSeq.clicked.connect(lambda : self.visualBoardAction('typeScene', 'levelSequence'))
        self.pushButton_vBoardShot.clicked.connect(lambda : self.visualBoardAction('typeScene', 'levelShot'))
        self.pushButton_vBoardScnTask.clicked.connect(lambda : self.visualBoardAction('typeScene', 'levelTask'))
        self.pushButton_vBoardAssetTab.clicked.connect(lambda : self.visualBoardAction('typeLib', 'levelRoot'))
        self.pushButton_vBoardType.clicked.connect(lambda : self.visualBoardAction('typeLib', 'levelSequence'))
        self.pushButton_vBoardAsset.clicked.connect(lambda : self.visualBoardAction('typeLib', 'levelShot'))
        self.pushButton_vBoardAssetTask.clicked.connect(lambda : self.visualBoardAction('typeLib', 'levelTask'))

        self.pushButton_Location_2.clicked.connect(self.openCurrentOpeningLocationPath)
        self.pushButton_versionUp.clicked.connect(lambda : self.versionUpSaveWIP(True))
        self.pushButton_versionUp.setStyleSheet("background-color:rgb(204,153,128); color:rgb(136, 77, 85)")
        #self.pushButton_versionUp.setVisible(False)



        self.childUi = ChildWindow(parent = self)
        self.wrongFormatUi = subListView(parent = self)
        self.wrongFormatUi.listWidget.itemDoubleClicked.connect(self.listWidget_A_action)
        self.wrongFormatUi.pushButton_exec.clicked.connect(lambda : self.listWidget_A_action(self.wrongFormatUi.listWidget.currentItem()))
        self.wrongFormatUi.setWindowTitle('Edit task in Wrong-Format-Projects')

        self.rvPreviousVersionUi = subListView(parent = self)
        self.rvPreviousVersionUi.listWidget.itemDoubleClicked.connect(lambda item : self.rvReviewAction(self.rvPreviousVersionInType, item.data(Qt.UserRole)))
        self.rvPreviousVersionUi.pushButton_exec.clicked.connect(lambda : self.rvReviewAction(self.rvPreviousVersionInType, self.rvPreviousVersionUi.listWidget.currentItem().data(Qt.UserRole)))
        self.rvPreviousVersionUi.setWindowTitle('RV Review Previous ver')

        #self.prerendKeywordListUi  = prerendKeywordListView(parent = self)

        self.dialogUi = NewWIPDialogWindow(parent = self)
        self.doneUi = doneWindow(parent = self)
        self.initializeNewWIPDialogWindow()
        self.createShotNewTaskUi = createShotNewTaskWindow(parent = self)
        self.prerendKeywordUi = nukeAskKeywordWindow(parent = self)
        self.newTaskKeywordUi = nukeAskKeywordWindow(parent = self)
        self.initializePrerendKeywordUi()
        self.initializeNewTaskKeywordUi()


        self.pushButton_newSeq.clicked.connect(lambda : self.newSequenceCreateAction('typeScene'))
        self.pushButton_newSeq.setEnabled(True)
        self.pushButton_newShot.clicked.connect(lambda : self.newShotCreateAction('typeScene'))
        self.pushButton_newShot.setEnabled(False)
        self.pushButton_newShotBatch.clicked.connect(lambda : self.newShotCreateBatchAction('typeScene'))
        self.pushButton_newShotBatch.setEnabled(False)

        self.pushButton_newType.clicked.connect(lambda : self.newSequenceCreateAction('typeLib'))
        self.pushButton_newType.setEnabled(True)
        self.pushButton_newAsset.clicked.connect(lambda : self.newShotCreateAction('typeLib'))
        self.pushButton_newAsset.setEnabled(False)
        self.pushButton_newAssetBatch.clicked.connect(lambda : self.newShotCreateBatchAction('typeLib'))
        self.pushButton_newAssetBatch.setEnabled(False)



        self.pushButton_scnUpdate.clicked.connect(self.openSceneUpdate)
        self.pushButton_scnUpdate.setText('Scene Update')
        self.pushButton_scnUpdate_2.clicked.connect(self.launchSceneUpdate)
        self.pushButton_scnUpdate_2.setText('Scene Update OLD')

        self.reviveUi = subListView(parent = self)
        self.reviveUi.listWidget.itemDoubleClicked.connect(self.reviveOpenAction)
        self.reviveUi.pushButton_exec.clicked.connect(lambda : self.reviveOpenAction(self.reviveUi.listWidget.currentItem()))
        self.reviveUi.setWindowTitle('Revive previous version')
        self.pushButton_revive.clicked.connect(self.reviveAction)
        self.pushButton_revive.setStyleSheet("background-color:rgb(128,179,179); color:rgb(10, 10, 10)")
        self.pushButton_revive.setEnabled(True)
        self.pushButton_closeNukeScript.clicked.connect(self.pretendCloseNukeScript)

        self.sceneUpdateUi = SceneUpDateListView(parent = self)
        #self.sceneUpdateUi.listWidget.itemDoubleClicked.connect(self.sceneUpdateAction)
        #self.sceneUpdateUi.pushButton_exec.clicked.connect(self.sceneUpdateAllAction())
        self.sceneUpdateUi.setWindowTitle('Scene Update Dialog')

        self.pushButton_getFrameRange.clicked.connect(self.getCurrentFrameInfo)
        self.pushButton_getFrameRange.setStyleSheet("background-color:rgb(128,179,179); color:rgb(10, 10, 10)")
        if in_nuke:
            self.pushButton_getFrameRange.setText('Get Frame Range\n- Project Setting-')

            self.nukeTempUi = nukeTempWindow(parent = self)
            self.pushButton_NukeReadNodeTempTool.clicked.connect(self.nukeTempTool1)
            #self.pushButton_NukeReadNodeTempTool.clicked.connect(self.nukeTempUi.LoadInOutFrame())
            self.nukeTempUi.initializeNukeTempWindow()

        else:
            self.pushButton_getFrameRange.setText('Get Frame Range')
            self.pushButton_NukeReadNodeTempTool.setVisible(False)

        self.createShotNewTaskUi.pushButton_execute.clicked.connect(self.createShotNewTaskAction)
        self.createShotNewTaskUi.pushButton_cancel.clicked.connect(self.createShotNewTaskClose)

        self.pushButton_CompLatestRv.clicked.connect(self.compLatestRvAction)
        self.pushButton_CompLatestRv.setEnabled(False)

        self.pushButton_shotAction2.clicked.connect(self.openCacheFolder)
        self.pushButton_shotAction2.setText('-Cache- Folder')
        self.pushButton_shotAction2.setEnabled(False)

        self.pushButton_shotAction3.clicked.connect(self.openOutputFolder)
        self.pushButton_shotAction3.setText('-Output- Folder')
        self.pushButton_shotAction3.setEnabled(False)





        #self.getBigKInfo = bigKeeperInfoGlobal_published.bigKeepCLASS()




        #self.pushButton_openCal.clicked.connect(lambda: self.openScheduleLink())
        self.pushButton_openCal.clicked.connect(lambda: self.openTeam11Folder())
        self.pushButton_openCal.setText('Team11 Schedule')
        self.pushButton_openCal2.clicked.connect(lambda: self.openTeam12Folder())
        self.pushButton_openCal2.setText('Team12 Schedule')


        # Nuke Tab
        #self.pushButton_genWritePrerend.clicked.connect(lambda : self.nukeBornWriteNode('PreRend'))
        self.pushButton_genWritePrerend.clicked.connect(lambda: self.prerendKeywordShow())
        self.pushButton_genWritePrerend.setText('Prerend')
        self.pushButton_genWriteLayerMask.clicked.connect(lambda : self.nukeBornWriteNode('LayerMask'))
        self.pushButton_genWriteLayerMask.setText('LayerMask')
        self.pushButton_genWriteCompMaster.clicked.connect(lambda : self.nukeBornWriteNode('CompMaster'))
        self.pushButton_genWriteCompMaster.setText('CompMaster')
        self.pushButton_genWriteCompMasterV.clicked.connect(lambda : self.nukeBornWriteNode('CompMasterToV'))
        self.pushButton_genWriteCompMasterV.setText('CompMaster-V')
        self.pushButton_genWriteFreeLayerMask.clicked.connect(lambda : self.nukeBornWriteNode(freeLayerMaskType))

        self.pushButton_genLightPublishBackdrop.clicked.connect(self.lightQCBornBackdrop)
        self.pushButton_lightPublishAction.clicked.connect(self.lightQCCopyAction)


        self.pushButton_genCgRenderBackdrop.clicked.connect(self.genCgRenderBackdrop)
        self.pushButton_genCgRenderBackdrop.setEnabled(False)

        self.pushButton_genOtherBackdrop.clicked.connect(self.genOtherBackdrop)
        self.pushButton_genOtherBackdrop.setEnabled(False)
        self.pushButton_FileKnobFreeze.clicked.connect(self.fileKnobFreeze)
        self.pushButton_FileKnobUnFreeze.clicked.connect(self.fileKnobUnFreeze)

        '''
        self.label_27.setVisible(False)
        self.pushButton_genCgRenderBackdrop.setVisible(False)
        self.pushButton_genOtherBackdrop.setVisible(False)
        '''


        #Cmd Tab
        self.pushButton_sortoutfile.clicked.connect(lambda: self.cleanUpCompOutput(self.listWidget_1.selectedItems()))
        self.pushButton_sortoutfile.setEnabled(False)
        self.pushButton_exeDel.clicked.connect(lambda: self.cleanUpDelAction('delAction'))
        self.pushButton_exeMove.clicked.connect(lambda: self.cleanUpDelAction('moveAction'))


        # Define a list containing the full paths of Nuke script files
        script_files = [
            r"N:\mnt\job\24901BigPicture_TestProj\WorkingFile\BigPicture24_TestProj\scenes\bensonSeq\bkpy0010\components\comp\wip\bkpy0010_comp_wip_v0017.nk",
            r"N:\mnt\job\24901BigPicture_TestProj\WorkingFile\BigPicture24_TestProj\scenes\bensonSeq\bkpy0010\components\comp\wip\bkpy0010_comp_wip_v0009.nk",
            # Add more script file paths as needed
        ]
        #self.pushButton_sortoutfile_1a.clicked.connect(lambda: self.extractReadNodePath(script_files))


        self.listBigKeeperProject()

        self.updateCurrentOpeningLocationPath()
        self.tabWidget.setCurrentIndex(0)
        #self.tabWidget.setTabVisible(2, self.horizontalSlider_echoSwitch.value())
        self.tabWidget.setTabVisible(3, self.horizontalSlider_echoSwitch.value())
        self.pushButton_genWriteFreeLayerMask.setEnabled(self.horizontalSlider_echoSwitch.value() > 0)
        self.pushButton_scnUpdate_2.setVisible(self.horizontalSlider_echoSwitch.value() > 0)


        self.pushButton_shotAction.setText('shotActionMenu')
        self.pushButton_shotAction.setEnabled(False)
        self.shotActionMenu = QMenu(self.pushButton_shotAction)
        self.shotTaskTypeAction = QAction('Task Type', self)
        self.shotAction1 = QAction('Edit Shot Task', self)
        #self.shotAction2 = QAction('RV latest Comp Output', self)
        self.shotAction3 = QAction('RV Build & Review Latest ver', self)
        self.shotAction4 = QAction('RV Review Previous ver', self)
        self.shotActionMenu.addAction(self.shotTaskTypeAction)
        self.shotActionMenu.addSeparator()
        self.shotActionMenu.addAction(self.shotAction1)
        #self.shotActionMenu.addAction(self.shotAction2)
        self.shotActionMenu.addAction(self.shotAction3)
        self.shotActionMenu.addAction(self.shotAction4)
        self.pushButton_shotAction.setMenu(self.shotActionMenu)
        # 'Task Type' above is only a placeholder, aboutToShow writes the row before it is seen.
        self.shotActionMenu.aboutToShow.connect(lambda : self.taskTypeMenuRefresh('typeScene'))
        self.shotTaskTypeAction.triggered.connect(lambda : self.taskTypeChangeAction('typeScene'))
        self.shotAction1.triggered.connect(lambda : self.editTaskAction('typeScene'))
        #self.shotAction2.triggered.connect(self.shotAction2Action)
        self.shotAction3.triggered.connect(lambda : self.rvReviewAction('typeScene', None))
        self.shotAction4.triggered.connect(lambda : self.rvPreviousVersionShow('typeScene'))

        self.pushButton_assetAction.setText('assetActionMenu')
        self.pushButton_assetAction.setEnabled(False)
        self.assetActionMenu = QMenu(self.pushButton_assetAction)
        self.assetTaskTypeAction = QAction('Task Type', self)
        self.assetAction1 = QAction('Edit Asset Task', self)
        self.assetAction3 = QAction('RV Build & Review Latest ver', self)
        self.assetAction4 = QAction('RV Review Previous ver', self)
        self.assetActionMenu.addAction(self.assetTaskTypeAction)
        self.assetActionMenu.addSeparator()
        self.assetActionMenu.addAction(self.assetAction1)
        self.assetActionMenu.addAction(self.assetAction3)
        self.assetActionMenu.addAction(self.assetAction4)
        self.pushButton_assetAction.setMenu(self.assetActionMenu)
        self.assetActionMenu.aboutToShow.connect(lambda : self.taskTypeMenuRefresh('typeLib'))
        self.assetTaskTypeAction.triggered.connect(lambda : self.taskTypeChangeAction('typeLib'))
        self.assetAction1.triggered.connect(lambda : self.editTaskAction('typeLib'))
        self.assetAction3.triggered.connect(lambda : self.rvReviewAction('typeLib', None))
        self.assetAction4.triggered.connect(lambda : self.rvPreviousVersionShow('typeLib'))

        # set the only active tab in related software.
        tabCount = self.tabWidget_2.count()
        println('\n\n\n\n\n\tabCount : \n\n\n\n\n\n\n')
        println(tabCount)
        for i in range(0, tabCount):
            self.tabWidget_2.setTabEnabled(i, False)

        self.tabWidget_2.setTabEnabled(6, True)

        if sys.version_info.major >= 3:
            self.tabWidget_2.setTabEnabled(5, True)

        if in_maya:
            self.tabWidget_2.setTabEnabled(0, True)
            self.tabWidget_2.setCurrentIndex(0)
        elif in_nuke:
            self.tabWidget_2.setTabEnabled(1, True)
            self.tabWidget_2.setTabEnabled(4, True)
            self.tabWidget_2.setCurrentIndex(1)
        elif in_houdini:
            self.tabWidget_2.setTabEnabled(2, True)
            self.tabWidget_2.setCurrentIndex(2)
        elif in_blender:
            self.tabWidget_2.setTabEnabled(3, True)
            self.tabWidget_2.setCurrentIndex(3)
        elif in_python:
            self.tabWidget_2.setTabEnabled(4, True)
            self.tabWidget_2.setCurrentIndex(5)


        if in_python == False and in_blender == False:
            # to avoid "hard to find it back after minimize", workaroun is to disable the minimize
            self.setWindowFlags(Qt.WindowCloseButtonHint)



        # This to a temp. and bad way to parenet on the working software and on-top. Current can't find correct way to do so.
        if in_blender:
            self.setWindowFlags(Qt.WindowStaysOnTopHint)



        if in_houdini:
            # ref: https://www.sidefx.com/docs/houdini/hom/hou/qt/styleSheet.html
            self.setStyleSheet(hou.qt.styleSheet())

        self.initDummy()

    def initDummy(self):
        '''
        #self.pushButton_childUi.clicked.connect(self.myAction4)
        #self.pushButton_num3.clicked.connect(lambda: self.cleanUpCheckFolderSize(self.selProjScnPath))
        #self.pushButton_num3.clicked.connect(lambda: self.cleanUpCheckFolderSize(self.selProjScnShotTaskPath))
        self.pushButton_num3.clicked.connect(lambda : self.nukeBornWriteNode('CompMasterToV'))
        self.pushButton_num3.setText('*Write to V:*')
        #self.pushButton_num3.clicked.connect(lambda: self.cleanUpCheckFolderSize(self.selProjScnShotTaskWIPPath))
        self.pushButton_num2.clicked.connect(lambda : self.prerendKeywordPresetShow())
        self.pushButton_num2.setText('*presetButton*')
        self.pushButton_num1.clicked.connect(lambda : self.listWidget_1_appear('typeScene'))
        self.pushButton_num1.setText('refresh seq')
        self.pushButton_num4.clicked.connect(lambda: self.envRead('NUKE', 'label'))
        self.pushButton_num4.setText('label')
        self.pushButton_num5.clicked.connect(self.launchSceneUpdate)
        self.pushButton_num5.setText('Scn Update')
        self.pushButton_num6.clicked.connect(lambda: self.nukeUpdateReadNodeVer())
        self.pushButton_num6.setText('UpReadVer')

        '''
        self.pushButton_num9.clicked.connect(lambda: self.compWriteNodePresetApplyToSelected())
        self.pushButton_num9.setText('WriteNode Preset')

        self.pushButton_num8.clicked.connect(lambda: self.cleanUpDelAction('moveAction'))
        self.pushButton_num8.setText('moveAction')

        #self.pushButton_num7.clicked.connect(lambda: self.listWidget_1_receivedListB())
        self.pushButton_num7.setText('listMulti')

    def printEchoUIFeedback(self):
        # No sys._getframe() here. This def is called by the valueChanged signal, so its
        # caller is Qt's C++ dispatch and f_back is None. println already prints the line
        # number of whichever line inside this def calls it.
        sliderValue = self.horizontalSlider_echoSwitch.value()

        if sliderValue == 0:
            println(' Echo Print is OFF')
        elif sliderValue == 1:
            println(' Developing Tab and Free LayerMask are unlocked. Echo Print is still OFF')
        else:
            println(' Echo Print is ON')

    def printEcho(self, inText):
        #println('\ndef >>>>> printEcho')
        # value = 0, echo off. developing tab hidden, Free LayerMask button disabled.
        # value = 1, developing tab and Free LayerMask button unlocked, echo still off.
        # value = 2, do printEcho
        #println(self.horizontalSlider_echoSwitch.value())

        if self.horizontalSlider_echoSwitch.value() > 1:
            println(inText)

    def echoSwitchOtherAction(self):
        #self.tabWidget.setTabVisible(2, self.horizontalSlider_echoSwitch.value())
        self.tabWidget.setTabVisible(3, self.horizontalSlider_echoSwitch.value())
        self.pushButton_genWriteFreeLayerMask.setEnabled(self.horizontalSlider_echoSwitch.value() > 0)
        self.pushButton_scnUpdate_2.setVisible(self.horizontalSlider_echoSwitch.value() > 0)


    '''def listWidget_1_receivedList(self, item):
        println('\ndef >>>>> listWidget_1_receivedList')
        println(item.text())
        #println(self.listWidget_1.)
        for i in self.listWidget_1.selectedItems():
            println(i.text())

    def listWidget_1_receivedListB(self):
        println('\ndef >>>>> listWidget_1_receivedListB')

        for i in self.listWidget_1.selectedItems():
            println(i.text())'''


    def deadlineCoreOverride(self):
        subprocess.call(r'python N:\bpPipeline\miscScriptTools\deadline_cmd\get_cmd_output_deadlineInfo_publish.py', shell=True)
        #os.system(r'N:\bpPipeline\miscScriptTools\deadline_cmd\get_cmd_output_deadlineInfo_publish.py')


    def deadlineCoreOverrideGPU(self):
        subprocess.call(r'python N:\bpPipeline\miscScriptTools\deadline_cmd\get_cmd_output_deadlineInfo_Gpu_publish.py', shell=True)



    def envRead(self, inSection, inKey):
        println('\ndef >>>>> envRead')

        try:
            def addLine(inStr):
                println('\n   def >>>>> addLine')
                seperator = r'\n'
                splitText = inStr.split(seperator)
                joinText = '\n'.join(splitText)

                return joinText

            config = configparser.ConfigParser()
            #config.read(r'./myConfigINI.py')
            config.read(pathOfEnvIni)

            theInfo = config[inSection]

            if inKey == 'label':
                return str(addLine(theInfo[inKey]))
            else:
                return theInfo[inKey]
        except:
            println('configparser fail, pass.')


    def vDrivePathRead(self, inPath, inSection, inKey):
        println('vDrivePathRead')

        config = configparser.ConfigParser()
        config.read(inPath)

        theInfo = config[inSection]

        return str(theInfo[inKey])




    def iconPathRead(self, inPath, inSection, inKey):
        println('\ndef >>>>> inconPathRead')

        config = configparser.ConfigParser()
        config.read(inPath)

        theInfo = config[inSection]

        return str(theInfo[inKey])


    def launchShotlist(self):
        println('\ndef >>>>> launchShotlist')

        getBigKInfo = bigKeeperInfoGlobal_published.bigKeepCLASS()
        println(os.path.join(self.subDict[self.selProjPath], 'bigPathsProject.ini'))

        shotlistUrl = self.iconPathRead(os.path.join(self.subDict[self.selProjPath], 'bigPathsProject.ini'), 'SHOTLIST', 'Path')

        self.openUrlInEdge(shotlistUrl)


    def launchShotlist(self):
        println('\ndef >>>>> launchShotlist')

        getBigKInfo = bigKeeperInfoGlobal_published.bigKeepCLASS()
        println(os.path.join(self.subDict[self.selProjPath], 'bigPathsProject.ini'))

        shotlistUrl = self.iconPathRead(os.path.join(self.subDict[self.selProjPath], 'bigPathsProject.ini'), 'SHOTLIST', 'Path')
        println('shotlist url ' + shotlistUrl)
        println('shotlist edge profile ' + edgeShotlistProfilePath)

        subprocess.Popen([edgePath,
                          '--user-data-dir=' + edgeShotlistProfilePath,
                          '--no-first-run',
                          '--no-default-browser-check',
                          shotlistUrl])


    def openUrlInEdge(self, inUrl):
        println('\ndef >>>>> openUrlInEdge')
        println('url ' + inUrl)

        if self.checkBox.isChecked():
            println('edge profile ' + edgeShotlistProfilePath)

            subprocess.Popen([edgePath,
                              '--user-data-dir=' + edgeShotlistProfilePath,
                              '--no-first-run',
                              '--no-default-browser-check',
                              inUrl])
        else:
            println('edge default profile')

            subprocess.Popen([edgePath, inUrl])


    def publicGmailCheckBoxAction(self):
        println('\ndef >>>>> publicGmailCheckBoxAction')

        isUsingPublicGmail = self.checkBox.isChecked()
        println('using bpuserpublic gmail : ' + str(isUsingPublicGmail))

        self.pushButton.setEnabled(isUsingPublicGmail)
        self.pushButton_3.setEnabled(isUsingPublicGmail)


    def copyPublicGmailLogin(self):
        println('\ndef >>>>> copyPublicGmailLogin')
        println(publicGmailLoginPath)

        with open(publicGmailLoginPath, 'r') as theFile:
            theText = theFile.read().strip()

        QApplication.clipboard().setText(theText)
        println('login copied to clipboard')


    def copyPublicGmailPassword(self):
        println('\ndef >>>>> copyPublicGmailPassword')
        println(publicGmailPasswordPath)

        with open(publicGmailPasswordPath, 'r') as theFile:
            theText = theFile.read().strip()

        QApplication.clipboard().setText(theText)
        println('password copied to clipboard')


    def launchCommentClient(self):
        println('\ndef >>>>> launchCommentClient')

        os.startfile(os.path.normpath(os.path.join(self.selProjRootPath, 'Comment')))


    def launchCommentInternal(self):
        println('\ndef >>>>> launchCommentInternal')

        # The internal comment folder sits in the RV storage tree on K:, where createRvFile writes
        # its comment shortcuts, so every office opens the same one. It is made on the first
        # press, the way the Daily folder is.
        commentPath = os.path.join(rvSessionStorageRootPath, self.selProj, 'comment')

        if not os.path.isdir(commentPath):
            os.makedirs(commentPath)
            QMessageBox.information(self, 'Comment Folder not found', 'No existing internal Comment folder.\nFolder is created: {}'.format(commentPath))

        os.startfile(commentPath)


    def launchRoughcut(self):
        println('\ndef >>>>> launchRoughcut')

        try:
            os.startfile(os.path.normpath(os.path.join(self.selProjRootPath, 'Roughcut', '__latestMov')))
        except:
            os.startfile(os.path.normpath(os.path.join(self.selProjRootPath, 'Roughcut')))


    def launchMiscCookbook(self):
        println('\ndef >>>>> launchMiscCookbook')
        println(self.iconPathRead(pathOfIconPathsStudio, 'LEARNING', 'Path'))

        os.startfile(self.iconPathRead(pathOfIconPathsStudio, 'LEARNING', 'Path'))



    def launchMiscLoginInfo(self):
        println('\ndef >>>>> launchMiscLoginInfo')
        println(self.iconPathRead(pathOfIconPathsStudio, 'LOGINS', 'Path'))

        os.startfile(self.iconPathRead(pathOfIconPathsStudio, 'LOGINS', 'Path'))



    def launchStaffContact(self):
        println('\ndef >>>>> launchStaffContact')
        println(self.iconPathRead(pathOfIconPathsStudio, 'STAFFCONTACT', 'Path'))

        os.startfile(self.iconPathRead(pathOfIconPathsStudio, 'STAFFCONTACT', 'Path'))


    def launchbigSyncSender(self):
        println('\ndef launchbigSyncSender')

        subprocess.call(r"N:\bpPipeline\bigSync\scripts\_senderUI.bat", shell=True)

    def launchbigSyncWatcher(self):
        println('\ndef launchbigSyncWatcher')

        subprocess.call(r"N:\bpPipeline\bigSync\scripts\_watcherUI.bat", shell=True)

    def launchStudioEnvMaya(self):
        #theCmd = 'start {}'.format(studioEnvMaya)
        theCmd = 'start {}'.format(os.path.join(self.envRead('MAYA', 'batPath'), 'studioEnv.bat'))
        println(theCmd)
        os.system(theCmd)

    def launchStudioEnvNuke(self):

        #theCmd = 'start {}'.format(studioEnvNuke)
        theCmd = 'start {}'.format(os.path.join(self.envRead('NUKE', 'batPath'), 'studioEnv.bat'))
        println(theCmd)
        os.system(theCmd)

    def launchStudioEnvNukeAssist(self):
        #theCmd = 'start {}'.format(studioEnvNukeAssist)
        theCmd = 'start {}'.format(os.path.join(self.envRead('NUKE', 'batPath'), 'studioEnvAssist.bat'))
        println(theCmd)
        os.system(theCmd)

    def launchStudioEnvNukeX(self):
        #theCmd = 'start {}'.format(studioEnvNukeX)
        theCmd = 'start {}'.format(os.path.join(self.envRead('NUKE', 'batPath'), 'studioEnvX.bat'))
        println(theCmd)
        os.system(theCmd)

    def launchStudioEnvNukeStudio(self):
        #theCmd = 'start {}'.format(studioEnvNukeStudio)
        theCmd = 'start {}'.format(os.path.join(self.envRead('NUKE', 'batPath'), 'studioEnvStudio.bat'))
        println(theCmd)
        os.system(theCmd)

    def launchStudioEnvNukeStudioHiero(self):
        theCmd = 'start {}'.format(os.path.join(self.envRead('HIERO', 'batPath'), 'nukeHieroPlayer.bat'))
        println(theCmd)
        os.system(theCmd)


    def launchStudioEnvHoudini(self):
        theCmd = 'start {}'.format(os.path.join(self.envRead('HOUDINI', 'batPath'), 'studioEnv.bat'))
        println(theCmd)
        os.system(theCmd)

    def launchStudioEnvRv(self, inFilePath):
        println('\ndef >>>>> launchStudioEnvRv')

        # Same studioEnv.bat layout as Maya and Nuke, so a special environment can be set in the
        # bat. The bat hands inFilePath, an .rv or a folder, on to rv.exe through %*.
        theBat = os.path.join(self.envRead('RV', 'batPath'), 'studioEnv.bat')
        println(theBat)
        subprocess.Popen([theBat, inFilePath])

    def launchMayaLegacySelection(self):
        theCmd = 'start {}'.format(os.path.join(self.envRead('MAYA', 'batPath'), 'studioEnv_LegacySelDisplay.bat'))
        println(theCmd)
        os.system(theCmd)

    def launchStudioEnvMayaFolder(self):
        theCmd = self.envRead('MAYA', 'batFolderPath')
        os.startfile(theCmd)

    def launchStudioEnvNukeFolder(self):
        theCmd = self.envRead('NUKE', 'batFolderPath')
        os.startfile(theCmd)

    def launchStudioEnvNukeStudioHieroOther(self):
        theCmd = self.envRead('HIERO', 'batFolderPath')
        os.startfile(theCmd)


    def launchStudioEnvHoudiniFolder(self):
        theCmd = self.envRead('HOUDINI', 'batFolderPath')
        os.startfile(theCmd)

    def launchDailyFolder(self):
        dailyPath = os.path.join(self.subDict[self.selProjPath], 'daily')

        if os.path.isdir(dailyPath):
            println('selProjPath is {}'.format(dailyPath))
        else:
            println('no daily fold exist, created now.')
            os.mkdir(dailyPath)
            QMessageBox.information(self, 'Daily Folder not found', 'No existing Daily folder.\nFolder is created: {}'.format(dailyPath))


        os.startfile(dailyPath)

    def launchProjExplorer(self):
        println(self.selProjRootPath)
        os.startfile(self.selProjRootPath)


    def launchSceneUpdate(self):
        println('\ndef >>>>> launchSceneUpdate')
        if in_maya:
            from daniel import sceneUpdate_maya as susu
        elif in_nuke:
            from daniel import sceneUpdatePySide6_nuke as susu
        else:
            from daniel import sceneUpdate as susu
        susu.run()


    def nukeUpdateReadNodeVer(self):
        println('\ndef >>>>> nukeUpdateReadNodeVer')

        allNodes = nuke.allNodes(filter = 'Read')
        println(allNodes)
        println(len(allNodes))
        println(type(allNodes))

        for i in allNodes:
            println(i.name())
            println(i.knob('file').getValue())
            filePath = i.knob('file').getValue()
            sepList = filePath.split('/')
            println(sepList)

            frameFullName = sepList[-1]
            frameFolder = sepList[-2]
            frameCurrentVer = sepList[-3]

            self.nukeReadNodeFindOtherVer(filePath, frameCurrentVer)



    def nukeReadNodeFindOtherVer(self, inFullPath, inSeperator):
        println('\ndef >>>>> nukeReadNodeFindOtherVer')

        sepList = inFullPath.split('')

    def openScheduleLink(self):
        println('\ndef >>>>> openScheduleLink')

        scheduleUrl = 'https://calendar.google.com/calendar/r'
        println('schedule url ' + scheduleUrl)
        println('schedule edge profile ' + edgeShotlistProfilePath)

        subprocess.Popen([edgePath,
                          '--user-data-dir=' + edgeShotlistProfilePath,
                          '--no-first-run',
                          '--no-default-browser-check',
                          scheduleUrl])

    def openScheduleFolder(self):
        println('\ndef >>>>> openScheduleFolder')
        thePath = r'N:\mnt\job\21044ChongFilm\Doc\Schedule\_publishPDF'
        os.startfile(thePath)

    def openTeam11Folder(self):
        println('\ndef >>>>> openTeam11Folder')
        thePath = r'N:\mnt\job\21044ChongFilm\Doc\Schedule\_publishPDF\team11'
        theLastPath = bigCodingAssistant_published.tool.findLatestFolderVer(thePath)
        println(theLastPath)
        os.startfile(os.path.join(thePath, theLastPath))

    def openTeam12Folder(self):
        println('\ndef >>>>> openTeam12Folder')
        thePath = r'N:\mnt\job\21044ChongFilm\Doc\Schedule\_publishPDF\team12'
        theLastPath = bigCodingAssistant_published.tool.findLatestFolderVer(thePath)
        println(theLastPath)
        os.startfile(os.path.join(thePath, theLastPath))


    def activateCurrentTab(self):
        println('\ndef >>>>> activateCurrentTab')
        self.tabWidget.setCurrentIndex(0)
        self.updateCurrentOpeningLocationPath()


    def initializeMainWindow(self):
        pass

    def listTypeConvert(self, inType):
        println('\ndef >>>>> listTypeConvert')

        if inType == 'typeScene':
            listLevel = (self.selProj, self.selProjScnPath)
        elif inType == 'typeLib':
            listLevel = (self.selProj, self.selProjLibPath)

        return listLevel


    def taskLevelConvert(self, inType):
        println('\ndef >>>>> taskLevelConvert')

        # The task level of whichever tab is asking : the shot's or asset's components folder,
        # the shot or asset name, and the task name. Same shape as listTypeConvert, a plain
        # tuple unpacked at the call site. It exists because selProjScnShotTaskPath, selShot
        # and selTask used to be one set shared by both tabs, so pressing a Shot tab button
        # after clicking around the Asset tab acted on the asset's folder.
        if inType == 'typeScene':
            taskLevel = (self.selProjScnShotTaskPath, self.selShot, self.selTask)
        elif inType == 'typeLib':
            taskLevel = (self.selProjAssetTypeAssetTaskPath, self.selProjAssetTypeAssetName, self.selProjAssetTypeAssetTaskName)

        return taskLevel


    def listWidget_1_appear(self, inType):
        println('\ndef >>>>> listWidget_1_appear')
        self.printEcho(inType)
        #self.printEcho(self.listTypeConvert(inType))

        cnvtSelProj, cnvtSelProjScnPath = self.listTypeConvert(inType)

        self.printEcho(f'converted SelProj        (cnvtSelProj)        : {cnvtSelProj}')
        self.printEcho(f'converted SelProjScnPath (cnvtSelProjScnPath) : {cnvtSelProjScnPath}')
        #folderList = os.listdir(self.selProjScnPath)
        folderList = os.listdir(cnvtSelProjScnPath)
        listSeq = []
        for i in folderList:
            #if os.path.isdir(os.path.join(self.selProjScnPath, i)):
            if os.path.isdir(os.path.join(cnvtSelProjScnPath, i)):
                listSeq.append(i)
        listSeq.sort()
        self.printEcho('listSeq is :')
        self.printEcho(listSeq) # eg. ['animaticSeq', 'balloonSeq', 'edits', 'socialSeq', 'testSeq', 'turnTableSeq', 'tvcSeq']

        # Decided to code seperately, Asset Tab and Shot Tab do not have to be the same layout
        if inType == 'typeScene':
            self.list1Entries = []
            self.list1Entries = listSeq
            self.listWidget_1.clear()
            self.listWidget_2.clear()
            self.listWidget_3.clear()
            self.listWidget_1.addItems(self.list1Entries)
            self.pushButton_newSeq.setEnabled(True)
            self.pushButton_newShot.setEnabled(False)
            self.pushButton_newShotBatch.setEnabled(False)
            self.pushButton_CompLatestRv.setEnabled(False)
            self.pushButton_shotAction.setEnabled(False)
            self.pushButton_shotAction2.setEnabled(False)
            self.pushButton_shotAction3.setEnabled(False)
            self.pushButton_newScnTask.setDisabled(True)

            # cnvtSelProjScnPath is selProjScnPath here. The three lists were just cleared, so the
            # location line and the < explore > button go back to the scenes root along with them,
            # on the first load and on every Refresh.
            self.sceneLocationPath = cnvtSelProjScnPath
            self.lineEdit_sceneLocation.setText(self.sceneLocationPath)

        elif inType == 'typeLib':
            self.list1Entries = []
            self.list1Entries = listSeq
            self.listWidget_AssetType.clear()
            self.listWidget_Asset.clear()
            self.listWidget_AssetTask.clear()
            self.listWidget_AssetType.addItems(self.list1Entries)
            self.pushButton_newType.setEnabled(True)
            self.pushButton_newAsset.setEnabled(False)
            self.pushButton_newAssetBatch.setEnabled(False)
            #self.pushButton_CompLatestRv.setEnabled(False)
            self.pushButton_assetAction.setEnabled(False)
            self.pushButton_assetAction2.setEnabled(False)
            self.pushButton_assetAction3.setEnabled(False)
            self.pushButton_newAssetTask.setDisabled(True)

            # cnvtSelProjScnPath is selProjLibPath here.
            self.assetLocationPath = cnvtSelProjScnPath
            self.lineEdit_assetLocation.setText(self.assetLocationPath)

        # A board or a session made at another office arrives through K:'s sync, but its
        # shortcut on this office's job drive does not. Every click puts back what is missing.
        self.storageShortcutRefresh(inType)



    def comboBoxAction2(self, item):
        if item != " ":
            # to fix : PySide2 as String, PySide6 as Int
            # if item is from QCombox will be (int), if item from previous proj cache will be (str).
            if type(item) == int:
                # convert item (int) to item (str)
                item = self.comboBoxEntries[item]

            self.comboBoxAction1ReceiveItem = item
            println('\ndef >>>>> comboBoxAction2')
            self.selProj = item
            self.selProjName = 'name'
            self.selProjPath = 'path'
            self.selProjLibCode = 'libraryfolder'
            self.selProjScnCode = 'scenesfolder'
            self.selProjWipCode = 'workshopname'
            self.selProjPublishCode = 'mastername'
            self.subDict = self.dictProj[self.selProj]

            # generating project Root path by split the path that read from xml information
            splitPath = os.path.splitdrive(os.path.normpath(self.subDict[self.selProjPath]))
            splitDrive = splitPath[0]
            splitTail = splitPath[1].split(os.path.sep)
            self.printEcho('splitPath : {}'.format(splitPath))
            self.printEcho('splitDrive : {}'.format(splitDrive))
            self.printEcho('splitTail : {}'.format(splitTail))
            self.selProjRootPath = os.path.normpath(os.path.join(splitDrive, os.path.sep, splitTail[1], splitTail[2], splitTail[3]))
            self.printEcho('self.selProjRootPath : {}'.format(self.selProjRootPath))

            # Decided to code seperately, Asset Tab and Shot Tab do not have to be the same layout
            #===== typeScene Section =====
            self.listWidget_3.clear()
            self.listWidget_2.clear()
            self.listWidget_1.clear()

            self.printEcho('self.subDict[self.selProjName]:' + self.subDict[self.selProjName]) # eg. kfcPoke
            self.printEcho('self.subDict[self.selProjPath]:' + self.subDict[self.selProjPath]) # eg. N:/mnt/job/19005kfcPoke/WorkingFile/kfcPoke/

            self.selProjLibPath = os.path.normpath(os.path.join(self.subDict[self.selProjPath], self.subDict[self.selProjLibCode]))
            self.selProjScnPath = os.path.normpath(os.path.join(self.subDict[self.selProjPath], self.subDict[self.selProjScnCode]))

            self.printEcho('self.selProjScnPath:' + self.selProjScnPath) # eg. N:/mnt/job/19005kfcPoke/WorkingFile/kfcPoke/scenes
            self.printEcho('self.subDict[self.selProjWipCode]:' + self.subDict[self.selProjWipCode]) # eg. wip
            self.printEcho('self.subDict[self.selProjPublishCode]:' + self.subDict[self.selProjPublishCode]) # eg. published

            # The location line and the < explore > button are set inside listWidget_1_appear,
            # so the Refresh buttons land on the same path this first load does.
            self.listWidget_1_appear('typeScene')
            #===== end of typeScene Section =====

            # Decided to code seperately, Asset Tab and Shot Tab do not have to be the same layout
            #===== typeLib Section =====
            self.listWidget_AssetTask.clear()
            self.listWidget_Asset.clear()
            self.listWidget_AssetType.clear()

            self.printEcho('self.subDict[self.selProjName]:' + self.subDict[self.selProjName]) # eg. kfcPoke
            self.printEcho('self.subDict[self.selProjPath]:' + self.subDict[self.selProjPath]) # eg. N:/mnt/job/19005kfcPoke/WorkingFile/kfcPoke/

            self.selProjLibPath = os.path.normpath(os.path.join(self.subDict[self.selProjPath], self.subDict[self.selProjLibCode]))
            self.selProjScnPath = os.path.normpath(os.path.join(self.subDict[self.selProjPath], self.subDict[self.selProjScnCode]))

            self.printEcho('self.selProjScnPath:' + self.selProjScnPath) # eg. N:/mnt/job/19005kfcPoke/WorkingFile/kfcPoke/scenes
            self.printEcho('self.subDict[self.selProjWipCode]:' + self.subDict[self.selProjWipCode]) # eg. wip
            self.printEcho('self.subDict[self.selProjPublishCode]:' + self.subDict[self.selProjPublishCode]) # eg. published

            self.listWidget_1_appear('typeLib')
            #===== end of typeLib Section =====

            self.writeProjCache(self.selProj)


    def writeProjCache(self, item):
        thepath = os.path.join(bigKeeperCacheFolderPath, cacheProjName)
        f = open(thepath, 'w')
        cacheProj = (item)
        f.write(cacheProj)
        f.close()


    def readProjCache(self):
        try:
            thepath = os.path.join(bigKeeperCacheFolderPath, cacheProjName)
            f = open(thepath, 'r')
            readAllLines = f.readlines()
            f.close()
            return readAllLines
        except:
            return str(" ")




    def listWidget_2_appear2(self, item2, inType):
        println('listWidget_2_appear2')
        self.printEcho(inType)
        #self.printEcho(self.listTypeConvert(inType))

        cnvtSelProj, cnvtSelProjScnPath = self.listTypeConvert(inType)

        # some self.Variable share the same name, for now. See if it might benefit for easier maintain coding. If not, change it later.
        if inType == 'typeScene':
            self.listWidget_3.clear()
            self.printEcho(item2)
            self.selProjScnItem = item2
            self.selProjScnName = item2.text()
            self.selProjScnShotPath = os.path.join(cnvtSelProjScnPath, item2.text())
            folderList = os.listdir(self.selProjScnShotPath)
            self.listShot = []
            for i in folderList:
                if os.path.isdir(os.path.join(self.selProjScnShotPath, i)):
                    self.listShot.append(str(i))
            self.printEcho(self.selProjScnShotPath)
            self.printEcho(self.listShot)
            self.listShot.sort()
            self.listWidget_2.clear()
            self.listWidget_2.addItems(self.listShot)
            self.sceneLocationPath = os.path.join(cnvtSelProjScnPath, item2.text())
            self.lineEdit_sceneLocation.setText(self.sceneLocationPath)
            self.pushButton_newScnTask.setDisabled(True)
            self.pushButton_newShot.setEnabled(True)
            self.pushButton_newShotBatch.setEnabled(True)
            self.pushButton_sortoutfile.setEnabled(True)
            self.pushButton_CompLatestRv.setEnabled(False)
            self.pushButton_shotAction.setEnabled(False)
            self.pushButton_shotAction2.setEnabled(False)
            self.pushButton_shotAction3.setEnabled(False)
        elif inType == 'typeLib':
            self.listWidget_AssetTask.clear()
            self.printEcho(item2)
            self.selProjScnItem = item2
            self.selProjScnName = item2.text()
            self.selProjAssetTypeAssetPath = os.path.join(cnvtSelProjScnPath, item2.text())
            folderList = os.listdir(self.selProjAssetTypeAssetPath)
            self.listShot = []
            for i in folderList:
                if os.path.isdir(os.path.join(self.selProjAssetTypeAssetPath, i)):
                    self.listShot.append(str(i))
            self.printEcho(self.selProjAssetTypeAssetPath)
            self.printEcho(self.listShot)
            self.listShot.sort()
            self.listWidget_Asset.clear()
            self.listWidget_Asset.addItems(self.listShot)
            self.assetLocationPath = os.path.join(cnvtSelProjScnPath, item2.text())
            self.lineEdit_assetLocation.setText(self.assetLocationPath)

            self.pushButton_newAssetTask.setDisabled(True)
            self.pushButton_newAsset.setEnabled(True)
            self.pushButton_newAssetBatch.setEnabled(True)
            #self.pushButton_sortoutfile.setEnabled(True)
            #self.pushButton_CompLatestRv.setEnabled(False)
            self.pushButton_assetAction.setEnabled(False)
            self.pushButton_assetAction2.setEnabled(False)
            self.pushButton_assetAction3.setEnabled(False)

        # A board or a session made at another office arrives through K:'s sync, but its
        # shortcut on this office's job drive does not. Every click puts back what is missing.
        self.storageShortcutRefresh(inType)




    def listWidget_3_appear(self, item3, inType):
        println('\ndef >>>>> listWidget_3_appear')
        self.printEcho(inType)
        #self.printEcho(self.listTypeConvert(inType))

        #this def not needed for now
        #cnvtSelProj, cnvtSelProjScnPath = self.listTypeConvert(inType)

        if inType == 'typeScene':
            self.printEcho(item3.text())
            self.selShot = item3.text()
            self.selProjScnShotTaskPath = os.path.join(self.selProjScnShotPath, item3.text(), "components")
            folderList = os.listdir(self.selProjScnShotTaskPath)
            listTask = []
            for i in folderList:
                if os.path.isdir(os.path.join(self.selProjScnShotTaskPath, i)):
                    listTask.append(str(i))
            self.printEcho(listTask)
            listTask.sort()
            self.listWidget_3.clear()
            self.listWidget_3.addItems(listTask)
            self.sceneLocationPath = os.path.join(self.selProjScnShotPath, item3.text())
            self.lineEdit_sceneLocation.setText(self.sceneLocationPath)
            self.pushButton_newScnTask.setDisabled(False)
            self.pushButton_CompLatestRv.setEnabled(False)
            self.pushButton_shotAction.setEnabled(False)
            self.pushButton_shotAction2.setEnabled(False)
            self.pushButton_shotAction3.setEnabled(False)
        elif inType == 'typeLib':
            self.printEcho(item3.text())
            self.selProjAssetTypeAssetName = item3.text()
            self.selProjAssetTypeAssetTaskPath = os.path.join(self.selProjAssetTypeAssetPath, item3.text(), "components")
            folderList = os.listdir(self.selProjAssetTypeAssetTaskPath)
            listTask = []
            for i in folderList:
                if os.path.isdir(os.path.join(self.selProjAssetTypeAssetTaskPath, i)):
                    listTask.append(str(i))
            self.printEcho(listTask)
            listTask.sort()
            self.listWidget_AssetTask.clear()
            self.listWidget_AssetTask.addItems(listTask)

            self.assetLocationPath = os.path.join(self.selProjAssetTypeAssetPath, item3.text())
            self.lineEdit_assetLocation.setText(self.assetLocationPath)
            self.pushButton_newAssetTask.setDisabled(False)
            #self.pushButton_CompLatestRv.setEnabled(False)
            self.pushButton_assetAction.setEnabled(False)
            self.pushButton_assetAction2.setEnabled(False)
            self.pushButton_assetAction3.setEnabled(False)

        # A board or a session made at another office arrives through K:'s sync, but its
        # shortcut on this office's job drive does not. Every click puts back what is missing.
        self.storageShortcutRefresh(inType)


    def listWidget_3C_action(self, item, inType):
        println('\ndef >>>>> listWidget_3C_action')
        try:
            theItem = item.text()
        except:
            theItem = item

        # Each tab keeps its own browse state now, so the components folder is read back through
        # inType. It used to read the shared selProjScnShotTaskPath, which pointed at whichever
        # tab was drilled into last.
        taskParentPath, shotName, taskName = self.taskLevelConvert(inType)

        self.selProjScnShotTaskWIPPath = os.path.join(taskParentPath, theItem, self.subDict[self.selProjWipCode])
        self.printEcho(self.selProjScnShotTaskWIPPath)
        self.printEcho(theItem)

        if inType == 'typeScene':
            self.selTask = theItem
        elif inType == 'typeLib':
            self.selProjAssetTypeAssetTaskName = theItem

        # The New WIP dialog below is one shared instance whose two buttons are connected once
        # at startup in initializeNewWIPDialogWindow, so createNewWIP2 and useCurrentWIP cannot
        # be given the tag by lambda. This is the only def that opens the dialog, so it is
        # stashed here, the same way newTaskKeywordShow stashes newTaskKeywordInType.
        self.newWipInType = inType

        #checkResult = self.createNewWIP(item)
        #println('checkResult is :')
        #println(checkResult)

        checkResult = 'yes'

        if checkResult != 'no' :
            self.listFile = self.listOutFilesInFolder()
            self.printEcho(len(self.listFile))
            #fileCount = len(listFile)

            if in_nuke or in_houdini:
                if len(self.listFile) == 0:
                    self.myDialogShow2(r'Create New WIP?', r'You are about to edit a WIP for the 1st time. Would you like to start with an empty new WIP, or with the currently open WIP?')

                    #fileCount + 1
                else:
                    self.openLastestWIP()

            else:
                QMessageBox.information(self, 'message', 'Double-click to open\nis currently activate in Houdini and Nuke only.')

    def openLastestWIP(self):
        println('\ndef >>>>> openLastestWIP')


        self.listFile = self.listOutFilesInFolder()
        self.listFile.sort()


        #self.printEcho(self.listFile[-1])
        self.wrongFormatUi.listWidget.clear()
        if self.selProj in nukeWrongFormatProj:
            self.printEcho('WRONG WRONG WRONG')
            #self.childUi.show()
            self.wrongFormatUi.listWidget.addItems(self.listFile)
            #self.wrongFormatUi.listWidget.itemDoubleClicked.connect(self.listWidget_A_action)
            #self.wrongFormatUi.listWidget.itemDoubleClicked.connect(self.listWidget_A_action)
            self.wrongFormatUi.show()

        else:
            if in_nuke:

                '''
                existingLargestWipFileFullPath = os.path.join(self.selProjScnShotTaskWIPPath, self.listFile[-1])
                self.printEcho('existingLargestWipFileFullPath : {}'.format(existingLargestWipFileFullPath))
                if os.path.getsize(existingLargestWipFileFullPath) == 0 and existingLargestWipFileFullPath.endswith('_v0000.nk'):
                    #os.remove(existingLargestWipFileFullPath)
                    noNeedSceneUpdateToken = True
                    self.printEcho('Deleted : {}'.format(existingLargestWipFileFullPath))
                '''


                self.tabWidget.setCurrentIndex(0)
                if nuke.Root().modified() == True:
                    self.printEcho('current changes have not yet been saved!')
                    nuke.scriptClose() ### pop a dialog instead of close.
                    if nuke.Root().modified() == False:
                        if self.nukeScriptOpenTolerant(os.path.join(self.selProjScnShotTaskWIPPath, self.listFile[-1])):

                            try:
                                nuke.onScriptLoad(self.nukeFileKnobFreezeScriptLoad())
                            except:
                                self.printEcho('PASS "nuke.onScriptLoad(self.nukeFileKnobFreezeScriptLoad())"')
                                pass

                            self.activateCurrentTab()

                else:

                    nuke.scriptClose()
                    if self.nukeScriptOpenTolerant(os.path.join(self.selProjScnShotTaskWIPPath, self.listFile[-1])):
                        #nuke.onScriptLoad(self.nukeFileKnobFreezeScriptLoad())

                        try:
                            nuke.onScriptLoad(self.nukeFileKnobFreezeScriptLoad())
                        except:
                            self.printEcho('PASS "nuke.onScriptLoad(self.nukeFileKnobFreezeScriptLoad())"')
                            pass

                        # To avoid error message when launchSceneUpdate on a v0000
                        #if noNeedSceneUpdateToken:
                        try:
                            #disabled this upon Apple and Sally request for a heavy shot.
                            #nuke.onScriptLoad(self.launchSceneUpdate())
                            nuke.onScriptLoad(self.openSceneUpdate())
                            #QMessageBox.information(self, 'Auto Scene Update', 'Check if Scene Update is needed ?')
                        except:
                            self.printEcho('PASS "nuke.onScriptLoad(self.launchSceneUpdate())"')
                            pass

                        self.activateCurrentTab()
                        #window.close()

            elif in_houdini:
                    hou.hipFile.load(os.path.join(self.selProjScnShotTaskWIPPath, self.listFile[-1]))
                    self.activateCurrentTab()


            else:
                self.printEcho('will open:', os.path.join(self.selProjScnShotTaskWIPPath, self.listFile[-1]))
                #subprocess.Popen([r'C:/Program Files/Nuke11.3v3/Nuke11.3.exe', os.path.join(self.selProjScnShotTaskWIPPath, listFile[-1])])
                #window.close()

        self.updateCurrentOpeningLocationPath()


    def openSceneUpdate(self):
        println('\ndef >>>>> openSceneUpdate')

        def initializeUi():
            self.sceneUpdateUi.pushButton_exec_1.setText('Update All')
            self.sceneUpdateUi.pushButton_exec_1.clicked.connect(updateAllAction)

            self.sceneUpdateUi.pushButton_exec_2.setText('Update Selected')
            self.sceneUpdateUi.pushButton_exec_2.clicked.connect(updateSelectedAction)

            self.sceneUpdateUi.pushButton_exec_3.setText('Select All')
            self.sceneUpdateUi.pushButton_exec_3.clicked.connect(lambda: selectDeselectAllAction('selectAll'))

            self.sceneUpdateUi.pushButton_exec_4.setText('De-select All')
            self.sceneUpdateUi.pushButton_exec_4.clicked.connect(lambda: selectDeselectAllAction('deSelectAll'))

            self.sceneUpdateUi.pushButton_exec_5.setText('Toggle All')
            self.sceneUpdateUi.pushButton_exec_5.clicked.connect(toggleAllAction)

            self.sceneUpdateUi.checkBox_1.setText('Out Dated')
            self.sceneUpdateUi.checkBox_1.setChecked(True)
            self.sceneUpdateUi.checkBox_1.stateChanged.connect(apply_filter)

            self.sceneUpdateUi.checkBox_2.setText('Up-To-Date')
            self.sceneUpdateUi.checkBox_2.setChecked(False)
            self.sceneUpdateUi.checkBox_2.stateChanged.connect(apply_filter)

            self.sceneUpdateUi.listWidget.itemClicked.connect(itemClickedAction)
            #self.sceneUpdateUi.listWidget.itemDoubleClicked.connect(itemDoublClickedAction)


            self.sceneUpdateUi.pushButton_exec_1.setVisible(False)
            self.sceneUpdateUi.pushButton_exec_5.setVisible(False)

            self.sceneUpdateUi.TextLabel_2.setText('Click ::: Zoom to the node\n< Explore > Button ::: Open footage folder in explorer.\n\n ')
            self.sceneUpdateUi.TextLabel_3.setText('Color Code\nRed    ::: Out Dated\nGreen ::: Up-to-date\nBlue    ::: Freeze\nYellow ::: Path Not Found\n')
            self.sceneUpdateUi.lineEdit.setText('--- click on the above row to show the path here ---')

            self.sceneUpdateUi.pushButton.clicked.connect(openClickedItemLocationPath)
            self.sceneUpdateUi.pushButton.setText('explore...')

            self.sceneUpdateUi.pushButton_exec_6.clicked.connect(refreshSceneUpdateUI)
            self.sceneUpdateUi.pushButton_exec_6.setText('refresh')


            filterUiFontObject = QFont()
            filterUiFontObject.setBold(True)

        def refreshSceneUpdateUI():
            self.printEcho('\ndef >>>>> refreshSceneUpdateUI')
            self.sceneUpdateUi.close()
            self.openSceneUpdate()

        def updateAllAction():
            self.printEcho(self.sceneUpdateUi.listWidget.count())

        def updateSelectedAction():
            selectedItem = []
            itemsToBeTakenAway = []
            for i in range(self.sceneUpdateUi.listWidget.count()):
                listedEachItem = self.sceneUpdateUi.listWidget.item(i)
                if listedEachItem.checkState() == Qt.Checked:

                    currentNodeName     = self.sceneUpdateUi.listWidget.item(i).data(role1Nodename)
                    currentLongwithTail = self.sceneUpdateUi.listWidget.item(i).data(role3CurrentLongWithTail)
                    newLongwithTail     = self.sceneUpdateUi.listWidget.item(i).data(role5LatestLongWithTail)
                    self.printEcho(currentNodeName)
                    self.printEcho(currentLongwithTail)
                    self.printEcho(newLongwithTail)


                    if perSelectedAction(currentNodeName, currentLongwithTail, newLongwithTail):
                        itemsToBeTakenAway.append(i)

            print('{} Nodes updated.'.format(len(itemsToBeTakenAway)))

            for j in sorted(itemsToBeTakenAway, reverse=True):
                print(j)
                #self.sceneUpdateUi.listWidget.takeItem(j)
                self.sceneUpdateUi.listWidget.item(j).setData(roleStatus, "up-to-date")
                self.sceneUpdateUi.listWidget.item(j).setData(role2CurrentBasename, self.sceneUpdateUi.listWidget.item(j).data(role4LatestBasename))
                self.sceneUpdateUi.listWidget.item(j).setData(role3CurrentLongWithTail, self.sceneUpdateUi.listWidget.item(j).data(role5LatestLongWithTail))
            print('{} Row of listwidget removed.'.format(len(itemsToBeTakenAway)))

            apply_filter()


            #self.printEcho(selectedItem)


        def perSelectedAction(inNodeName, inCurrent, inNew):
            # Final Original file path
            theNode = nuke.toNode(inNodeName)
            theNodeName = theNode.knob('name').value()
            theNodeFilepath = theNode.knob('file').value()

            self.printEcho('perSelectedAction :')
            self.printEcho(inNodeName)
            self.printEcho(theNodeFilepath)
            self.printEcho(inCurrent)
            self.printEcho(inNew)

            updatedContent = theNodeFilepath.replace(inCurrent, inNew)
            theNode.knob('file').setValue(updatedContent)

            if theNode.knob('file').value() == updatedContent:
                self.printEcho('checked, < {} > is updated.'.format(inNodeName))
                return True
            else:
                self.printEcho('*** check fail, < {} > update F A I L ! ! ! ***'.format(inNodeName))
                return False


        def selectDeselectAllAction(inMode):
            for i in range(self.sceneUpdateUi.listWidget.count()):
                listedEachItem = self.sceneUpdateUi.listWidget.item(i)
                if inMode == 'selectAll':
                    if listedEachItem.flags() & Qt.ItemIsUserCheckable:
                        listedEachItem.setCheckState(Qt.Checked)
                elif inMode == 'deSelectAll':
                    listedEachItem.setCheckState(Qt.Unchecked)
        '''
        def deSelectAllAction():
            for i in range(self.sceneUpdateUi.listWidget.count()):
                listedEachItem = self.sceneUpdateUi.listWidget.item(i)
                listedEachItem.setCheckState(Qt.Unchecked)
        '''

        def toggleAllAction():
            for i in range(self.sceneUpdateUi.listWidget.count()):
                listedEachItem = self.sceneUpdateUi.listWidget.item(i)
                if listedEachItem.data(roleStatus) != "separatorItem":
                    if listedEachItem.checkState() == Qt.Checked:
                        listedEachItem.setCheckState(Qt.Unchecked)
                    else:
                        listedEachItem.setCheckState(Qt.Checked)

        def itemClickedAction(inItem):
            self.printEcho('inItem : {}'.format(inItem))
            self.printEcho('inItem.text() Clicked               : {}'.format(inItem.text()))
            self.printEcho('value in roleStatus                 : {}'.format(inItem.data(roleStatus)))
            self.printEcho('value in role1Nodename              : {}'.format(inItem.data(role1Nodename)))
            self.printEcho('value in role2CurrentBasename       : {}'.format(inItem.data(role2CurrentBasename)))
            self.printEcho('value in role3CurrentLongWithTail   : {}'.format(inItem.data(role3CurrentLongWithTail)))
            self.printEcho('value in role4LatestBasename        : {}'.format(inItem.data(role4LatestBasename)))
            self.printEcho('value in role5LatestLongWithTail    : {}'.format(inItem.data(role5LatestLongWithTail)))
            self.printEcho('value in role6NodeClass             : {}'.format(inItem.data(role6NodeClass)))
            self.printEcho('value in role7NodeIsNotFreeze       : {}'.format(inItem.data(role7NodeIsNotFreeze)))
            self.printEcho('value in role11DisplayText          : {}'.format(inItem.data(role11DisplayText)))

            # To unselect nodes, yet to find "select nothing" function
            nuke.selectAll()
            nuke.invertSelection()

            theNode = nuke.toNode(inItem.data(role1Nodename))
            theNode.setSelected(True)
            # ref: https://learn.foundry.com/nuke/developers/63/pythondevguide/dag.html
            nuke.zoom( 1, [ theNode.xpos(), theNode.ypos() ])

            splitParts = str(inItem.data(role3CurrentLongWithTail)).split(inItem.data(role2CurrentBasename))
            self.sceneUpdateUi.lineEdit.setText(splitParts[0])


        def itemDoublClickedAction(inItem):
                print(inItem.data(role3CurrentLongWithTail))
                print(inItem.data(role2CurrentBasename))
                splitParts = str(inItem.data(role3CurrentLongWithTail)).split(inItem.data(role2CurrentBasename))
                print(splitParts)

                os.startfile(splitParts[0])

        def openClickedItemLocationPath():
                os.startfile(self.sceneUpdateUi.lineEdit.text())


        def findNodeWithFileKnob():
            """
            Finds all nodes in the Nuke script that are of a specified type :
                 (include: Read, DeepRead, AudioRead /
                  exclude: ReadGeo, Camera)
            and prints their name and the value of their 'file' knob.
            """
            # 1. A tuple to store the target node classes.
            # Using a tuple for performance as it's immutable.
            # do not include node type because it collapse when update without open Nuke script: 'Camera3', ''ReadGeo2', 'Axis3', 'Axis4', 'Light3')
            target_node_classes = ('Read', 'DeepRead', 'AudioRead')

            # 2. Find all nodes in the script, including those inside groups.
            all_nodes = nuke.allNodes(recurseGroups=True)

            self.printEcho("--- Finding ('Read', 'DeepRead', 'AudioRead') Node Classes ---")

            # A counter for found nodes.
            found_nodes_count = 0

            # A list storing the node names with 'file' knob
            storeNodeNamesList = []

            # 3. Iterate through all nodes and filter for the target classes.
            for node in all_nodes:
                if node.Class() in target_node_classes:
                    try:
                        # 4. Get the node name and the value of the 'file' knob.
                        node_name = node.name()
                        file_path = node['file'].value()

                        found_nodes_count += 1
                        storeNodeNamesList.append(node_name)
                    except NameError:
                        pass

            if found_nodes_count == 0:
                self.printEcho("No nodes of the target types were found in the script.")
            else:
                self.printEcho(f"\nFound a total of {found_nodes_count} matching nodes.")

            return storeNodeNamesList

        def CheckVerPath(inPath):
            """
            This function looks at a file path and finds any folder names that look
            like version numbers (e.g., "v01", "v10005").

            It checks for two kinds of version folders:
            1. Folders that start with 'v' and numbers (like "v005_shot_name").
            2. Folders that end with 'v' and numbers (like "shot_name_v005").

            The function takes one argument:
              inPath: A string containing the full path to a file.

            It returns:
              A list of all the unique version strings it found.
            """

            # Step 1: Create a Path object from the file path string.
            # A Path object has useful attributes for getting parts of the path.
            pathObj = pathlib.Path(inPath)

            found_version = None
            found_version_basename = None
            found_version_longpath = None
            found_version_fullpath = None
            found_version_filename = None
            found_version_fullparent = None


            for path in pathObj.parents:
                #print()
                #print('path : {}'.format(path))
                #print('base name : {}'.format(os.path.basename(path)))

                pathBasename = os.path.basename(path)
                fullpath = pathObj.parent

                first_v_postion = pathBasename.lower().startswith('v')
                last_v_position = pathBasename.lower().rfind('v')

                # We only proceed if a 'v' was found (position is not -1)
                # and it's not the very last character of the folder name.
                if first_v_postion == False and last_v_position != -1 and last_v_position < len(pathBasename) - 1:

                    # Get the part of the string that comes AFTER the last 'v'.
                    # This is called a "slice".
                    suffix = pathBasename[last_v_position + 1:]

                    # Check if this suffix contains ONLY numbers.
                    if suffix.isdigit():
                        # If it's all numbers, then the part from 'v' to the end is our version.
                        version_string = pathBasename[last_v_position:]
                        found_version = version_string
                        found_version_basename = pathBasename
                        found_version_longpath = path
                        found_version_fullpath = fullpath
                        # If we found a version pattern, break the for-loop.

                        break # Stop the loop.

                else:

                    if pathBasename.lower().startswith('v'):
                        self.printEcho('{} - startswith v'.format(pathBasename.lower()))
                        if len(pathBasename) > 1 and pathBasename[1].isdigit():

                            version_part = 'v'
                            for character in pathBasename[1:]: # Loop starting from the second character.
                                if character.isdigit():
                                    version_part += character
                                else:
                                    # If we find a non-number, the version part has ended.

                                    break # Stop the loop.

                            found_version = version_part
                            found_version_basename = pathBasename
                            found_version_longpath = path
                            found_version_fullpath = fullpath
                            found_version_filename = os.path.basename(fullpath)
                            found_version_fullparent = os.path.dirname(fullpath)

                            # If we found a version pattern, break the for-loop.

                            break # Stop the loop.
                    else:
                        self.printEcho('{} - Not startswith v'.format(pathBasename.lower()))

            return found_version, found_version_basename, found_version_longpath, found_version_fullpath, found_version_filename, found_version_fullparent

        def isNumPadPattern(inString):
            #self.printEcho('\ndef >>>>> isNumPadPattern')
            # all number
            # all @
            # all #
            # %04D

            loopToken = True
            while loopToken == True:
                # all number
                if inString.isdigit():
                    loopToken = False
                    #print('all number')
                    break
                else:

                    #all "@"
                    if inString.count('@') == len(inString):
                        loopToken = False
                        #print('all @')
                        break
                    else:

                        #all "#"
                        if inString.count('#') == len(inString):
                            loopToken = False
                            #print('all #')
                            break

                        else:

                            # %04d, %xxxxd
                            if inString[0] == '%' and inString[-1] == 'd' and inString[1:-1:1].isdigit():
                                loopToken = False
                                inString[1:-1:1]
                                #print('%04d, %xxxxd')
                                break
                            else:
                                break


            loopToken = not loopToken

            return loopToken

        def nameStemPattern(inString):
            #self.printEcho('\ndef >>>>> nameStemPattern')

            #self.printEcho('inString : {}'.format(inString))
            splitedString = inString.split('.')
            splitedString.reverse()
            outputStringList = []
            foundIsDigit = False
            for i in splitedString:
                #print('check : ' + i)
                #print(foundIsDigit)
                #print(isNumPadPattern(i))
                if foundIsDigit == False:
                    if isNumPadPattern(i):
                        foundIsDigit = True
                    else:
                        foundIsDigit = False
                elif foundIsDigit == True:

                    #print( 'APPEND' )
                    outputStringList.append(i)


                #print(outputStringList)

            outputStringList.reverse()
            outputString = ''

            for i in outputStringList:
                outputString = outputString + '.' + i

            #print('outputString[1::] >>> {}'.format( outputString[1::]))

            return outputString[1::]

        def isVersionPattern(inString):
            self.printEcho('\ndef >>>>> isVersionPattern')

            if inString.startswith('v') or inString.startswith('V'):
                self.printEcho('inString : {} is startswith "v" or "V".'.format(inString))
                if inString[1::].isdigit:
                    self.printEcho('inString : {} is startswith "v" or "V" and the rest are isdigit. it is a version pattern.'.format(inString))
                    returnValue = True
                else:
                    self.printEcho('inString : {} is startswith "v" or "V" and the rest are NOT isdigit. NOT version pattern.'.format(inString))
                    returnValue = False
            else:
                self.printEcho('inString : {} is not startswith "v" or "V". NOT version pattern'.format(inString))
                returnValue = False

            return returnValue

        def versionPatternFrontOrEnd(inStringA, inStringB):
            self.printEcho('\ndef >>>>> versionPatternFrontOrEnd')

            if inStringA.endswith(inStringB):
                return 'End'
            elif inStringA.startswith(inStringB):
                return 'Front'
            else:
                return 'NoMatch'


        def isLatestVersion(inNodeName, inVer, inVerBasename, inVerLongpath, inVerFullpath):
            println('\ndef >>>>> isLatestVersion')
            println('\n\n\n\n\ninNodeName : {}\ninVer: {}\ninVerBasename : {}\ninVerLongpath : {}\ninVerFullpath : {}\n---'.format(inNodeName, inVer, inVerBasename, inVerLongpath, inVerFullpath))

            ''' Result example:
            ---
            inNodeName : Read1
            inVer: v0006
            inVerBasename : v0006
            inVerLongpath : N:\mnt\job\24068PantenePokemon\WorkingFile\PantenePokemon\scenes\zzzToliet\bensonPipelineTest\components\light\images\v0006
            inVerFullpath : N:\mnt\job\24068PantenePokemon\WorkingFile\PantenePokemon\scenes\zzzToliet\bensonPipelineTest\components\light\images\v0006\pearlA_rlyr\pearlA_rlyr.%04d.exr
                                                                                                                                                  |---| Ver
                                                                                                                                                  |---| verBaseName
                            |-------------------------------------------------------------------------------------------------------------------------| verLongpath
                            |----------------------------------------------------------------------------------------------------------------------------------------------------------| verFullPath
            ---


            ---
            inNodeName : Read2
            inVer: v0008
            inVerBasename : v0008_LayerMask
            inVerLongpath : N:\mnt\job\24068PantenePokemon\WorkingFile\PantenePokemon\scenes\zzzToliet\bensonPipelineTest\components\compB\output\v0008_LayerMask
            inVerFullpath : N:\mnt\job\24068PantenePokemon\WorkingFile\PantenePokemon\scenes\zzzToliet\bensonPipelineTest\components\compB\output\v0008_LayerMask\pearl\five0010_pearl.%04d.exr
                                                                                                                                                  |---| Ver
                                                                                                                                                  |-------------| verBaseName
                            |-----------------------------------------------------------------------------------------------------------------------------------| verLongpath
                            |----------------------------------------------------------------------------------------------------------------------------------------------------------| verFullPath
            ---




            '''
            inVerPathObjLong = pathlib.Path(inVerLongpath)
            inVerLongpath_tail = inVerFullpath[len(str(inVerLongpath))::]
            inVerFullpath_name = os.path.basename(inVerFullpath)
            inVerFullpath_stem = os.path.basename(inVerFullpath).split('.')[0]



            # use parent path to find all versions
            # A Read node points at a folder that is not on disk any more often enough : the shot
            # was renamed, the footage tree was moved, an outside vendor path was never on this
            # network, the drive is not mapped. os.listdir raised FileNotFoundError on it and
            # killed the caller's whole loop, so the dialog never opened for any node.
            # < None, None > means < cannot be judged >. The caller lists such a node as
            # pathNotFound rather than guessing a version for it.
            if not os.path.isdir(inVerPathObjLong.parent):
                println('Version parent folder is not there : {}'.format(inVerPathObjLong.parent))
                return None, None

            listFolders = os.listdir(inVerPathObjLong.parent)
            listFolders.sort()
            self.printEcho(listFolders)



            inVerBasenameNoVersion = inVerBasename.removesuffix(inVer)
            if inVerBasenameNoVersion != inVerBasename:
                versionIsSuffix = True
            else:
                inVerBasenameNoVersion = inVerBasename.removeprefix(inVer)
                versionIsSuffix = False
            self.printEcho('inVerBasenameNoVersion : {}'.format(inVerBasenameNoVersion))
            self.printEcho('\n')


            latestVerPathPattern = None

            # latestVerBaseName is assigned at the top of every pass of the for-loop below. An
            # empty version folder never enters that loop, so it is set here as well.
            latestVerBaseName = None

            # Reverse the List to start backward from the highest version
            listFolders.sort(reverse = True)
            for i in listFolders:
                println('\ni : <folder> ' + i)
                compareBaseName = i
                latestVerBaseName = None








                self.printEcho('check if-condition 1 of 6')
                '''
                check the < number of Digit > of the VerBasename:
                                        v#### == v####
                                  V####_layer == v####_layer
                five0010_lightPearl_wip_v#### == five0010_lightPearl_wip_v####
                '''
                if len(compareBaseName) == len(inVerBasename):


                    if versionPatternFrontOrEnd(inVerBasename, inVer) == 'End':
                        compareBaseNameSplit_noVersion = compareBaseName.removesuffix(compareBaseName[len(inVer) * -1::])
                    elif versionPatternFrontOrEnd(inVerBasename, inVer) == 'Front':
                        compareBaseNameSplit_noVersion = compareBaseName.removeprefix(compareBaseName[0:len(inVer):])








                    self.printEcho('check if-condition 2 of 6')
                    '''
                    check basename without Version :
                                          <Empty> == <Empty> (eg. v####)
                                           _layer == _layer
                         five0010_lightPearl_wip_ == five0010_lightPearl_wip_

                    '''
                    if compareBaseNameSplit_noVersion == inVerBasenameNoVersion:

                        if versionPatternFrontOrEnd(inVerBasename, inVer) == 'End':
                            compareBaseNameSplit_AfterInVer = compareBaseName.removeprefix(compareBaseNameSplit_noVersion)

                        elif versionPatternFrontOrEnd(inVerBasename, inVer) == 'Front':
                            compareBaseNameSplit_AfterInVer = compareBaseName.removesuffix(compareBaseNameSplit_noVersion)

                        self.printEcho('compareBaseNameSplit_AfterInVer : {}'.format(compareBaseNameSplit_AfterInVer))








                        self.printEcho('check if-condition 3 of 6')
                        '''
                        check version pattern starts with "v" or "V"
                                        v???? == v????
                                        V???? == V????

                        '''
                        if compareBaseNameSplit_AfterInVer.startswith('v') or compareBaseNameSplit_AfterInVer.startswith('V'):
                            #print('have v or V.')








                            self.printEcho('check if-condition 4 of 6')
                            '''
                            check version pattern starts with "v" or "V"
                                            ?#### == ?####
                            '''
                            # To compare if the folder contain the same image sequence
                            if compareBaseNameSplit_AfterInVer[1::].isdigit():


                                inVerPathPattern      =os.path.normpath( os.path.join(inVerPathObjLong.parent, inVerBasename,   inVerLongpath_tail.rstrip(inVerFullpath_name)[1:-1]) )
                                compareVerPathPattern =os.path.normpath( os.path.join(inVerPathObjLong.parent, compareBaseName, inVerLongpath_tail.rstrip(inVerFullpath_name)[1:-1]) )
                                self.printEcho('\ninVerBasename         : {}'.format(inVerBasename))
                                self.printEcho('inVerPathPattern      : {}'.format(inVerPathPattern))
                                self.printEcho('compareBaseName       : {}'.format(compareBaseName))
                                self.printEcho('compareVerPathPattern : {}\n'.format(compareVerPathPattern))



                                self.printEcho('check if-condition 5 of 6')
                                '''
                                check if compareVerPathPattern exist?

                                '''
                                if os.path.isdir(compareVerPathPattern):
                                    # check the compare Paths
                                    listFiles = os.listdir(compareVerPathPattern)
                                    #print(listFiles)


                                    for listedfile in listFiles:

                                        #print('nameStemPattern : {}'.format(nameStemPattern(listedfile)))

                                        '''
                                        print('{} vs {}'.format(listedfile, inVerFullpath_stem + '.'))
                                        if listedfile.startswith(inVerFullpath_stem + '.'):
                                            print('                         : {}'.format(inVerFullpath_stem))
                                            print('Matched pattern filename : {}'.format(listedfile))
                                            break
                                            '''

                                        #print('{} vs {}'.format(nameStemPattern(listedfile) + '.',     inVerFullpath_stem + '.'))
                                        #if (nameStemPattern(listedfile) + '.') == (inVerFullpath_stem + '.'):
                                        #print('{} vs {}'.format(nameStemPattern(listedfile) + '.',     nameStemPattern(inVerFullpath_name) + '.'))








                                        self.printEcho('check if-condition 6 of 6')
                                        if (nameStemPattern(listedfile) + '.') == (nameStemPattern(inVerFullpath_name) + '.'):
                                            #print('                         : {}'.format(nameStemPattern(listedfile) + '.'))
                                            #print('Matched pattern filename : {}'.format(listedfile))

                                            latestVerPathPattern = compareVerPathPattern
                                            latestVerBaseName = compareBaseName

                                            self.printEcho('<><>'*20 + '\n' + latestVerPathPattern +'\n' + '<><>'*20)
                                            self.printEcho('latestVerBaseName FOUND :' + latestVerBaseName)
                                            break
                                        else:
                                            #print('No Match pattern filename : x x x')

                                            pass


                                    if latestVerBaseName != None:
                                        #print('269 break')
                                        break
                                else:
                                    println('Failed after check if-condition 5 of 6')
                            else:
                                println('Failed after check if-condition 4 of 6')
                        else:
                            println('Failed after check if-condition 3 of 6')
                    else:
                        println('Failed after check if-condition 2 of 6')
                else:
                    println('Failed after check if-condition 1 of 6')


            self.printEcho('Latest WIP folder :')
            self.printEcho(latestVerPathPattern)
            self.printEcho(latestVerBaseName)
            # Not str(latestVerBaseName) any more : the caller needs a real None to tell
            # < nothing matched > apart from a folder that is really called 'None'.
            return latestVerPathPattern, latestVerBaseName

        def apply_filter():
            '''
            This is the core filtering logic. It loops through all items in the list
            and hides or shows them based on the filter checkboxes.
            '''
            show_outdated = self.sceneUpdateUi.checkBox_1.isChecked()
            show_up_to_date = self.sceneUpdateUi.checkBox_2.isChecked()

            self.printEcho('show_outdated value   : {}'.format(show_outdated))
            self.printEcho('show_up_to_date value : {}'.format(show_up_to_date))

            # Loop through every single row in the QListWidget
            self.printEcho('self.sceneUpdateUi.listWidget.count() :: {}'.format(self.sceneUpdateUi.listWidget.count()))

            outdatedCounter = 0
            FreezedCounter = 0
            pathNotFoundCounter = 0

            for i in range(self.sceneUpdateUi.listWidget.count()):

                item = self.sceneUpdateUi.listWidget.item(i)

                status = item.data(roleStatus) # Get the status we stored earlier
                #self.printEcho('item   : {}'.format(item))
                #self.printEcho('status : {}'.format(status))

                # We handle separators with their preceding item, so we skip them here.
                if status == "separatorItem":
                    continue

                # Default to hidden, then show if it matches a checked filter
                is_visible = False
                if status == "OutDated" and show_outdated:
                    is_visible = True
                    outdatedCounter += 1
                elif status == "up-to-date" and show_up_to_date:
                    is_visible = True
                    FontObject = QFont()
                    FontObject.setBold(False)
                    item.setBackground(QColor(20, 250, 20, 20)) #RGBA 0-255
                    #item.setTextColor(QColor(20, 255, 20, 255)) #RGBA 0-255
                    item.setFont(FontObject)
                    item.setCheckState(Qt.Unchecked)
                    item.setFlags(Qt.NoItemFlags)

                elif status == "pathNotFound":
                    # Neither of the two filters describes this row, and hiding a footage that
                    # is not on disk any more would be one more way of < Scene Update is not
                    # working >. It stays on screen whatever the checkboxes say.
                    is_visible = True
                    item.setBackground(QColor(255, 200, 0, 90)) #RGBA 0-255
                    item.setData(Qt.CheckStateRole, None)
                    item.setFlags(Qt.NoItemFlags)
                    pathNotFoundCounter += 1

                # A missing path is worth more than a freeze mark, so the yellow row keeps its
                # colour and keeps its checkbox away.
                isNotFreezeStatus = item.data(role7NodeIsNotFreeze)
                if isNotFreezeStatus == 'Freeze' and status != "pathNotFound":
                    item.setBackground(QColor(0, 150, 200, 75)) #RGBA 0-255
                    item.setCheckState(Qt.Unchecked)
                    item.setFlags(Qt.NoItemFlags)
                    FreezedCounter += 1

                    showText = (f'\n'
                                f'< {item.data(role1Nodename)} >               [{item.data(role6NodeClass)}]               --{item.data(role7NodeIsNotFreeze)}--          {item.data(role8CurrentPathMissing)}\n'
                                f'{item.data(role2CurrentBasename)}     :::     {item.data(role4LatestBasename)}\n'
                                f'\n'
                                f'Latest path : {item.data(role5LatestLongWithTail)}'
                                f'\n')
                else:
                    showText = (f'\n'
                                f'< {item.data(role1Nodename)} >               [{item.data(role6NodeClass)}]          {item.data(role8CurrentPathMissing)}\n'
                                f'{item.data(role2CurrentBasename)}     :::     {item.data(role4LatestBasename)}\n'
                                f'\n'
                                f'Latest path : {item.data(role5LatestLongWithTail)}'
                                f'\n')


                self.printEcho(item.data(role2CurrentBasename))
                self.printEcho('Updated showText :')
                self.printEcho(showText)
                item.setText(showText)


                # Set the item's visibility based on the logic above
                item.setHidden(not is_visible)

                # Now, handle the separator that follows the item.
                # Check if there is a next item and if it's our separator.
                if (i + 1) < self.sceneUpdateUi.listWidget.count():
                    separator_item = self.sceneUpdateUi.listWidget.item(i + 1)
                    if separator_item.data(roleStatus) == "separatorItem":
                        # Hide or show the separator to match the item above it
                        separator_item.setHidden(not is_visible)

            self.sceneUpdateUi.TextLabel.setText('Number of Out Dated Node : {}   (included {} freezed))   Path Not Found : {}'.format(outdatedCounter, FreezedCounter, pathNotFoundCounter))

        # Body ============================

        initializeUi()

        dictFoundVersionNodes = {}

        foundNodeNamesWithFileKnob = (findNodeWithFileKnob())
        foundNodeNamesWithFileKnob.sort()

        self.printEcho('foundNodeNamesWithFileKnob : {}'.format(foundNodeNamesWithFileKnob))

        if not foundNodeNamesWithFileKnob:
            self.printEcho("\nNo nodes of the target types were found in the script.")
        else:
            self.printEcho(f"\nFound a total of {len(foundNodeNamesWithFileKnob)} matching nodes. Details below:")
            self.printEcho("=" * 40)

            # Loop through the dictionary and print the contents.
            # .items() gives us both the key (nodeName) and value (filePath) for each entry.
            for nodeName in foundNodeNamesWithFileKnob:
                theNode = nuke.toNode(nodeName)
                theNodeClass = theNode.Class()
                theNodeName = theNode.knob('name').value()
                theNodeFilepath = theNode.knob('file').value()
                if theNode.knob('file').enabled():
                    theNodeIsNotFreeze = 'NotFreeze'
                else:
                    theNodeIsNotFreeze = 'Freeze'

                self.printEcho(f"Node Name: {theNodeName}")
                self.printEcho(f"Node Class : {theNodeClass}")
                self.printEcho(f"File Path: {theNodeFilepath}")


                versionPathInfo = CheckVerPath(theNodeFilepath)
                self.printEcho('versionPathInfo :')
                self.printEcho(f'versionPathInfo[0] : {versionPathInfo[0]}')
                self.printEcho(f'versionPathInfo[1] : {versionPathInfo[1]}')
                self.printEcho(f'versionPathInfo[2] : {versionPathInfo[2]}')
                self.printEcho(f'versionPathInfo[3] : {versionPathInfo[3]}')
                self.printEcho(f'versionPathInfo[4] : {versionPathInfo[4]}')
                self.printEcho(f'versionPathInfo[5] : {versionPathInfo[5]}')



                if versionPathInfo[0] != None:
                    dictFoundVersionNodes.update({nodeName : [versionPathInfo[0], versionPathInfo[1], versionPathInfo[2], os.path.normpath(theNodeFilepath), versionPathInfo[3], versionPathInfo[4], theNodeClass, theNodeIsNotFreeze]})

            self.printEcho("--- Search Complete ---")

        self.sceneUpdateUi.listWidget.clear()
        listFoundVersionNodeName = []

        #dictionary format :
        #           Key     : NodeName  > Read6
        #           Value   : Use a List to Store [
        #                                           0 currentNode Version                       > v0011
        #                                           1 currentVersion Basename                   > five0010_lightPearl_wip_v0011
        #                                           2 currentVersion Basename Longpath          > N:\mnt\job\24068PantenePokemon\WorkingFile\PantenePokemon\scenes\zzzToliet\bensonPipelineTest\components\lightPearl\images\five0010_lightPearl_wip_v0011
        #                                           3 currentVersion Basename Longpath with tail> N:\mnt\job\24068PantenePokemon\WorkingFile\PantenePokemon\scenes\zzzToliet\bensonPipelineTest\components\lightPearl\images\five0010_lightPearl_wip_v0011\pearlA_rlyr\pearlA_rlyr.Cryptomatte.%04d.exr
        #                                           4 currentVersion Fullpath                   > N:\mnt\job\24068PantenePokemon\WorkingFile\PantenePokemon\scenes\zzzToliet\bensonPipelineTest\components\lightPearl\images\five0010_lightPearl_wip_v0011\pearlA_rlyr
        #                                           5 currentVersion filename                   > None
        #                                           6 Node Class                                > Read
        #                                           7 currentNode theNodeIsNotFreeze            > True
        #                                           ===== the following will be added later =====
        #                                           8 LatestVersion Fullpath                    > N:\mnt\job\24068PantenePokemon\WorkingFile\PantenePokemon\scenes\zzzToliet\bensonPipelineTest\components\lightPearl\images\five0010_lightPearl_wip_v0021\pearlA_rlyr
        #                                           9 LatestVersion Basename                    > five0010_lightPearl_wip_v0021
        #
        #                                             8 and 9 are both None when isLatestVersion
        #                                             could not judge the node : the footage
        #                                             folder is gone, or nothing in it matches.
        #
        #                                           ]


        for key in dictFoundVersionNodes:
            #print('{} --- {} {} {} {} {} {}'.format(key, dictFoundVersionNodes.get(key)[0], dictFoundVersionNodes.get(key)[1], dictFoundVersionNodes.get(key)[2],  dictFoundVersionNodes.get(key)[3], dictFoundVersionNodes.get(key)[4], dictFoundVersionNodes.get(key)[5]))

            # for compatible in python 3.6 or before, dictionary is unordered. Use another sorted list to drive dictionary order.
            listFoundVersionNodeName.append(key)



        listFoundVersionNodeName.sort()
        # remark : After sorted the order is like < Read1 -> Read18 -> Read2 -> Read3)

        counter = 0

        # Every row that is wrong in a way the artist should know about writes two lines in here,
        # and they are shown in one warning box after the dialog is up. The list dialog reports
        # versions, this box reports footage that is simply not on disk.
        warningLines = []

        roleStatus                  = Qt.UserRole
        role1Nodename               = Qt.UserRole + 1
        role2CurrentBasename        = Qt.UserRole + 2
        role3CurrentLongWithTail    = Qt.UserRole + 3
        role4LatestBasename         = Qt.UserRole + 4
        role5LatestLongWithTail     = Qt.UserRole + 5
        role6NodeClass              = Qt.UserRole + 6
        role7NodeIsNotFreeze        = Qt.UserRole + 7
        role8CurrentPathMissing     = Qt.UserRole + 8
        role11DisplayText           = Qt.UserRole + 11


        for keyNodeName in listFoundVersionNodeName:
            #println('\nisLatestVersion(keyNodeName, dictFoundVersionNodes.get(keyNodeName)[0], dictFoundVersionNodes.get(keyNodeName)[1], dictFoundVersionNodes.get(keyNodeName)[2], dictFoundVersionNodes.get(keyNodeName)[3])')
            #print(dictFoundVersionNodes.get(keyNodeName)[2])
            #print(os.path.normpath(dictFoundVersionNodes.get(keyNodeName)[2]))

            # isLatestVersion reads the disk, so it meets whatever the artist left behind. The
            # two known cases return < None, None > on their own, this try is for the rest :
            # a permission error, a path that is a file where a folder is expected, a footage
            # tree nobody expected. Before it, one bad node raised and killed this whole loop,
            # and since self.sceneUpdateUi.show() sits after the loop the dialog never appeared
            # at all - which is what the artists reported as < Scene Update is not working >.
            theCannotJudgeReason = ''

            try:
                latestVersionPath = isLatestVersion(keyNodeName, dictFoundVersionNodes.get(keyNodeName)[0], dictFoundVersionNodes.get(keyNodeName)[1],dictFoundVersionNodes.get(keyNodeName)[2], dictFoundVersionNodes.get(keyNodeName)[3])
            except Exception as theError:
                theCannotJudgeReason = '{} : {}'.format(type(theError).__name__, theError)
                println('< {} > cannot be judged : {}'.format(keyNodeName, theCannotJudgeReason))
                latestVersionPath = None, None


            dictFoundVersionNodes[keyNodeName].append(latestVersionPath[0])
            dictFoundVersionNodes[keyNodeName].append(latestVersionPath[1])

            '''
            counterFor = 0
            for dictValueListItem in dictFoundVersionNodes[keyNodeName]:
                print(counterFor)
                print(type(dictValueListItem))
                print(dictValueListItem)
                counterFor += 1
            print()
            '''

            counter += 1
            item = QListWidgetItem()
            item.setFlags(item.flags() | Qt.ItemIsUserCheckable)
            item.setFlags(item.flags() & ~Qt.ItemIsSelectable)
            item.setCheckState(Qt.Checked)
            '''
            Explanation:

            item.flags(): This gets the current flags of the item.

            &: This is the bitwise AND operator.

            ~: This is the bitwise NOT operator.

            ~Qt.ItemIsSelectable: This creates a bitmask where all bits are 1 except for the one corresponding to Qt.ItemIsSelectable.

            item.flags() & ~Qt.ItemIsSelectable: This operation keeps all the flags that were already set, except for Qt.ItemIsSelectable, which is effectively turned off.
            '''

            showCurrentLongWithTail = str(dictFoundVersionNodes.get(keyNodeName)[4]).replace(os.sep, '/')

            # [8] is None when isLatestVersion could not judge this node. It used to become the
            # string 'None' here, which read as OutDated, arrived checked, and let
            # < Update Selected > write the word None into the file knob. It gets its own
            # status, its own colour and no checkbox instead.
            # role5 is fed the current path, not a message : if the row ever does get checked,
            # perSelectedAction then replaces the path with itself and changes nothing.
            if dictFoundVersionNodes.get(keyNodeName)[8] is None:
                showNewLongWithTail = showCurrentLongWithTail
                showLatestBasename  = '--- path not found ---'
                showStatus = "pathNotFound"
                item.setBackground(QColor(255, 200, 0, 90)) #RGBA 0-255
                item.setData(Qt.CheckStateRole, None)
                item.setFlags(Qt.NoItemFlags)

                # The row already says < path not found > in the compare line, so it carries no
                # extra marker. There is no version to offer, which is what the wording says.
                showCurrentPathMissing = ''

                if theCannotJudgeReason == '':
                    warningLines.append('< {} >   No version folder can be compared. There is nothing to update to.'.format(keyNodeName))
                else:
                    warningLines.append('< {} >   {}'.format(keyNodeName, theCannotJudgeReason))

                warningLines.append('     {}\n'.format(showCurrentLongWithTail))

            else:
                showNewLongWithTail = str(dictFoundVersionNodes.get(keyNodeName)[8]).replace(os.sep, '/')
                showLatestBasename  = dictFoundVersionNodes.get(keyNodeName)[9]

                # [4] is the folder that holds the frames, the same one the up-to-date test
                # compares. A version folder that was deleted while a newer one sits beside it
                # reads as a plain OutDated row, with nothing saying the footage in the script
                # is already gone. The colour still describes the version, this marker describes
                # existence, and the row stays checkable because updating is exactly the fix.
                if os.path.isdir(dictFoundVersionNodes.get(keyNodeName)[4]):
                    showCurrentPathMissing = ''
                else:
                    showCurrentPathMissing = '[Current Path Missing !!! ? User can still update to latest ver]'
                    warningLines.append('< {} >   Current path is missing. It can still be updated to < {} >.'.format(keyNodeName, showLatestBasename))
                    warningLines.append('     {}\n'.format(showCurrentLongWithTail))

                if showCurrentLongWithTail == showNewLongWithTail:
                    #upToDateFont = QFont()
                    #upToDateFont.setBold(False)
                    showStatus = "up-to-date"
                    item.setBackground(QColor(20, 250, 20, 20)) #RGBA 0-255
                    #item.setTextColor(QColor(20, 255, 20, 255)) #RGBA 0-255
                    #item.setFont(upToDateFont)


                else:
                    outDatedFont = QFont()
                    outDatedFont.setBold(True)
                    showStatus = "OutDated"
                    item.setBackground(QColor(255, 10, 10, 125)) #RGBA 0-255
                    #item.setTextColor(QColor(250, 20, 20, 255)) #RGBA 0-255
                    item.setFont(outDatedFont)

            item.setData(roleStatus                 , showStatus)
            item.setData(role1Nodename              , keyNodeName)
            item.setData(role2CurrentBasename       , dictFoundVersionNodes.get(keyNodeName)[1])
            item.setData(role3CurrentLongWithTail   , showCurrentLongWithTail)
            item.setData(role4LatestBasename        , showLatestBasename)
            item.setData(role5LatestLongWithTail    , showNewLongWithTail)
            item.setData(role6NodeClass             , dictFoundVersionNodes.get(keyNodeName)[6])
            item.setData(role7NodeIsNotFreeze       , dictFoundVersionNodes.get(keyNodeName)[7])
            item.setData(role8CurrentPathMissing    , showCurrentPathMissing)


            showText = (f'\n'
                        f'< {item.data(role1Nodename)} >               [{item.data(role6NodeClass)}]          -{item.data(role7NodeIsNotFreeze)}-          {item.data(role8CurrentPathMissing)}\n'
                        f'{item.data(role2CurrentBasename)}     :::     {item.data(role4LatestBasename)}\n'
                        f'\n'
                        f'Latest path : {item.data(role5LatestLongWithTail)}'
                        f'\n')

            item.setData(role11DisplayText           , showText)
            item.setText(item.data(role11DisplayText))




            self.sceneUpdateUi.listWidget.addItem(item)

            separator = QListWidgetItem()
            separator.setSizeHint(QSize(0, 1))
            #separator.setBackground(QColor("black"))
            separator.setBackground(QColor(50, 50, 50, 255)) #RGBA 0-255
            separator.setFlags(Qt.NoItemFlags)
            separator.setData(roleStatus                 , "separatorItem")
            self.sceneUpdateUi.listWidget.addItem(separator)

        self.sceneUpdateUi.show()
        apply_filter()

        # After show() and apply_filter(), so the list is already behind the box and the artist
        # can match the node names against the rows.
        if len(warningLines) > 0:
            QMessageBox.warning(self, 'Ooops!', 'Scene Update cannot follow these nodes :\n\n{}\nTheir < file > knob points at a path that is not on disk.'.format('\n'.join(warningLines)))



    def reviveAction(self):
        println('\ndef >>>>> reviveAction')
        bigKInfo = bigKeeperInfoGlobal_published.bigKeepCLASS()
        listFile = bigKInfo.listOutFilesInFolder()
        self.printEcho(listFile)

        self.reviveUi.listWidget.clear()
        self.reviveUi.listWidget.addItems(listFile)
        #self.reviveUi.listWidget.itemDoubleClicked.connect(self.reviveOpenAction)
        self.reviveUi.show()

    def reviveOpenAction(self, item):
        println('\ndef >>>>> reviveOpenAction')
        bigKInfo = bigKeeperInfoGlobal_published.bigKeepCLASS()

        self.reviveUi.close()
        if in_nuke:
            if nuke.Root().modified() == True:
                self.printEcho('current changes have not yet been saved!')
                nuke.scriptClose() ### pop a dialog instead of close.
                if nuke.Root().modified() == False:
                    if self.nukeScriptOpenTolerant(os.path.join(bigKInfo.currentPath(), item.text())):

                        try:
                            nuke.onScriptLoad(self.nukeFileKnobFreezeScriptLoad())
                        except:
                            self.printEcho('PASS "nuke.onScriptLoad(self.nukeFileKnobFreezeScriptLoad())"')
                            pass

                        try:
                            #disabled this upon Apple and Sally request for a heavy shot.
                            #nuke.onScriptLoad(self.launchSceneUpdate())
                            nuke.onScriptLoad(self.openSceneUpdate())
                            #QMessageBox.information(self, 'Auto Scene Update', 'Check if Scene Update is needed ?')
                        except:
                            self.printEcho('PASS "nuke.onScriptLoad(self.launchSceneUpdate())"')
                            pass

                        self.activateCurrentTab()

            else:
                nuke.scriptClose()
                if self.nukeScriptOpenTolerant(os.path.join(bigKInfo.currentPath(), item.text())):

                    try:
                        nuke.onScriptLoad(self.nukeFileKnobFreezeScriptLoad())
                    except:
                        self.printEcho('PASS "nuke.onScriptLoad(self.nukeFileKnobFreezeScriptLoad())"')
                        pass

                    try:
                        #disabled this upon Apple and Sally request for a heavy shot.
                        #nuke.onScriptLoad(self.launchSceneUpdate())
                        nuke.onScriptLoad(self.openSceneUpdate())
                        #QMessageBox.information(self, 'Auto Scene Update', 'Check if Scene Update is needed ?')
                    except:
                        self.printEcho('PASS "nuke.onScriptLoad(self.launchSceneUpdate())"')
                        pass

                    self.activateCurrentTab()


        elif in_houdini:
            hou.hipFile.load(os.path.join(bigKInfo.currentPath(), item.text()))
            self.activateCurrentTab()


    def listOutFilesInFolder(self, v0000Del = False):
        print ('\ndef >>>>> listOutFilesInFolder')

        # A task folder made by hand has no wip folder. Report it as no wip files instead of
        # raising, so the caller carries on and the New WIP dialog can offer to start one.
        if not os.path.isdir(self.selProjScnShotTaskWIPPath):
            self.printEcho('No wip folder : {}'.format(self.selProjScnShotTaskWIPPath))
            return []

        fileList = os.listdir(self.selProjScnShotTaskWIPPath)
        listFile = []
        for i in fileList:
            if i.find(self.subDict[self.selProjWipCode]) and os.path.isfile(os.path.join(self.selProjScnShotTaskWIPPath, i)):
                if i.endswith(wipExtension):
                    listFile.append(i)
        self.printEcho(r'listFile in listOutFilesInFolder:')
        self.printEcho(listFile)

        if len(listFile) > 0 and v0000Del == True:
            existingLargestWipFileFullPath = os.path.join(self.selProjScnShotTaskWIPPath, listFile[-1])
            self.printEcho('existingLargestWipFileFullPath : {}'.format(existingLargestWipFileFullPath))
            if os.path.getsize(existingLargestWipFileFullPath) == 0 and existingLargestWipFileFullPath.endswith('_v0000.nk'):
                os.remove(existingLargestWipFileFullPath)
                self.printEcho('Deleted : {}'.format(existingLargestWipFileFullPath))
                listFile.remove(listFile[-1])

        return listFile


    def listWidget_A_action(self, item):

        println('listWidget_A_action listWidget_A_action listWidget_A_action')
        self.printEcho(item.text())
        self.printEcho(os.path.join(self.selProjScnShotTaskWIPPath, item.text()))
        self.wrongFormatUi.close()
        if in_nuke:
            if nuke.Root().modified() == True:
                self.printEcho('current changes have not yet been saved!')
                nuke.scriptClose() ### pop a dialog instead of close.
                if nuke.Root().modified() == False:
                    if self.nukeScriptOpenTolerant(os.path.join(self.selProjScnShotTaskWIPPath, item.text())):

                        try:
                            nuke.onScriptLoad(self.nukeFileKnobFreezeScriptLoad())
                        except:
                            self.printEcho('PASS "nuke.onScriptLoad(self.nukeFileKnobFreezeScriptLoad())"')
                            pass

                        self.activateCurrentTab()


            else:
                nuke.scriptClose()
                if self.nukeScriptOpenTolerant(os.path.join(self.selProjScnShotTaskWIPPath, item.text())):

                    try:
                        nuke.onScriptLoad(self.nukeFileKnobFreezeScriptLoad())
                    except:
                        self.printEcho('PASS "nuke.onScriptLoad(self.nukeFileKnobFreezeScriptLoad())"')
                        pass

                    self.activateCurrentTab()

        elif in_houdini:
            hou.hipFile.load(os.path.join(self.selProjScnShotTaskWIPPath, self.listFile[-1]))


    def listWidget_shotTask_action(self, item, inType):
        println('\ndef >>>>> listWidget_shotTask_action')

        self.printEcho(inType)
        #self.printEcho(self.listTypeConvert(inType))

        #this def not needed for now
        #cnvtSelProj, cnvtSelProjScnPath = self.listTypeConvert(inType)

        if inType == 'typeScene':

            self.printEcho(self.selProjScnShotTaskPath)
            self.printEcho(item.text())
            self.printEcho(self.subDict[self.selProjWipCode])

            self.selProjScnShotTaskWIPPath = os.path.join(self.selProjScnShotTaskPath, item.text(), self.subDict[self.selProjWipCode])
            self.printEcho(self.selProjScnShotTaskWIPPath)

            self.sceneLocationPath = os.path.join(self.selProjScnShotTaskPath, item.text())
            self.printEcho(self.sceneLocationPath)
            self.lineEdit_sceneLocation.setText(self.sceneLocationPath)
            self.selTask = item.text()
            self.pushButton_CompLatestRv.setEnabled(True)
            self.pushButton_shotAction.setEnabled(True)
            self.pushButton_shotAction2.setEnabled(True)
            self.pushButton_shotAction3.setEnabled(True)

            self.listFile = self.listOutFilesInFolder(True)
            self.listFile.sort()

        elif inType == 'typeLib':

            self.printEcho(self.selProjAssetTypeAssetTaskPath)
            self.printEcho(item.text())
            self.printEcho(self.subDict[self.selProjWipCode])

            self.selProjScnShotTaskWIPPath = os.path.join(self.selProjAssetTypeAssetTaskPath, item.text(), self.subDict[self.selProjWipCode])
            self.printEcho(self.selProjScnShotTaskWIPPath)

            self.assetLocationPath = os.path.join(self.selProjAssetTypeAssetTaskPath, item.text())
            self.printEcho(self.assetLocationPath)
            self.lineEdit_assetLocation.setText(self.assetLocationPath)
            self.selProjAssetTypeAssetTaskName = item.text()
            #self.pushButton_CompLatestRv.setEnabled(True)
            self.pushButton_assetAction.setEnabled(True)
            self.pushButton_assetAction2.setEnabled(False)
            self.pushButton_assetAction3.setEnabled(False)

            self.listFile = self.listOutFilesInFolder(True)
            self.listFile.sort()

        # A board or a session made at another office arrives through K:'s sync, but its
        # shortcut on this office's job drive does not. Every click puts back what is missing.
        self.storageShortcutRefresh(inType)

        #return item

    def myAction1(self):
        println('\ndef >>>>> myAction1')

    def myAction2(self):
        println('\ndef >>>>> myAction2')
        subprocess.Popen([r'C:/Program Files/7-Zip/7zFM.exe'])

    def myAction3(self):
        println('\ndef >>>>> myAction3')
        #"C:/Program Files/Blender Foundation/Blender 2.81/blender.exe" "C:/Users/poonb/Documents/twoCube.blend" Suppose this works in cmd prompt, but not work in python.
        #So need to create a .bat and launch it.
        fullpath = r'I:/iCloud~com~omz-software~Pythonista3/learnpyqt/bookSample/2_Designing with Qt Creator/test/pyBlender.bat'
        #fullpath = ''
        println(fullpath)
        subprocess.Popen([fullpath])

    def myAction4(self):
        println('\ndef >>>>> myAction4')
        self.childUi.show()

    def assetShotExploreAction(self, inType):
        println('\ndef >>>>> assetShotExploreAction')

        if  inType == 'typeScene':
            os.startfile(self.sceneLocationPath)
        elif  inType == 'typeLib':
            os.startfile(self.assetLocationPath)

    def visualBoardAction(self, inType, inLevel):
        println('\ndef >>>>> visualBoardAction')
        self.printEcho(inType)
        self.printEcho(inLevel)

        # Each button owns one level and stays there, so the Seq row still opens the seq board
        # after the user has clicked all the way down to a task. The path is rebuilt from this
        # tab's own listWidgets because the state variables only carry the level last clicked,
        # and taskLevelConvert only reaches the task level.
        if inType == 'typeScene':
            visualBoardRootPath = self.selProjScnPath
            visualBoardRootName = self.subDict[self.selProjScnCode]
            listWidgetSequence = self.listWidget_1
            listWidgetShot = self.listWidget_2
            listWidgetTask = self.listWidget_3
        elif inType == 'typeLib':
            visualBoardRootPath = self.selProjLibPath
            visualBoardRootName = self.subDict[self.selProjLibCode]
            listWidgetSequence = self.listWidget_AssetType
            listWidgetShot = self.listWidget_Asset
            listWidgetTask = self.listWidget_AssetTask

        # The rows above the wanted level are always picked already : a shot list only holds rows
        # after a seq was clicked, and a task list only after a shot was. So the last one is the
        # only one that can be empty.
        if inLevel == 'levelRoot':
            selectedItems = []
        elif inLevel == 'levelSequence':
            selectedItems = [listWidgetSequence.currentItem()]
        elif inLevel == 'levelShot':
            selectedItems = [listWidgetSequence.currentItem(), listWidgetShot.currentItem()]
        elif inLevel == 'levelTask':
            selectedItems = [listWidgetSequence.currentItem(), listWidgetShot.currentItem(), listWidgetTask.currentItem()]

        if selectedItems != [] and selectedItems[-1] == None:
            QMessageBox.warning(self, 'Ooops!', 'Visual Board\n\nNothing is selected on this row yet.')
            return

        folderNames = [eachItem.text() for eachItem in selectedItems]

        # Every task folder sits under the shot's components folder.
        if inLevel == 'levelTask':
            folderNames.insert(2, 'components')

        # The board itself lives in the storage tree, which mirrors the project tree level for
        # level under its own project folder. The folder on the job drive only keeps a shortcut,
        # so one board is never open from two places at once.
        originalFolderPath = os.path.join(visualBoardRootPath, *folderNames)
        storageFolderPath = os.path.join(visualBoardStorageRootPath, self.selProj, visualBoardRootName, *folderNames)

        # The board is named after the folder it sits in : tvcSeq\tvcSeq.pur, sc010\sc010.pur,
        # comp\comp.pur, and at the top level scenes\scenes.pur or lib\lib.pur. Both trees end on
        # the same folder, so the name is the same on both sides.
        visualBoardName = os.path.basename(storageFolderPath) + visualBoardExtension
        storageFullPath = os.path.join(storageFolderPath, visualBoardName)
        originalFullPath = os.path.join(originalFolderPath, visualBoardName)

        # <name>.pur.lnk, so Explorer shows it as <name>.pur with file extensions hidden.
        shortcutFullPath = os.path.join(originalFolderPath, visualBoardName + '.lnk')
        self.printEcho(storageFullPath)

        if not os.path.isfile(storageFullPath):

            # A board made before the storage tree existed is copied there on the first press,
            # with no question asked : it is the same board, only somewhere else.
            boardToCopyPath = ''

            if os.path.isfile(originalFullPath):
                boardToCopyPath = originalFullPath
            else:
                answer = QMessageBox.question(self, 'Visual Board',
                                              'There is no Visual Board here yet :\n\n{}\n\nCreate < {} > ?'.format(
                                                  storageFolderPath, visualBoardName),
                                              QMessageBox.Yes | QMessageBox.No, QMessageBox.No)

                if answer == QMessageBox.No:
                    println('Visual Board is not created. Nothing is opened.')
                    return

            # The storage tree is built as it is used, so every level is made on its first press.
            if not os.path.isdir(storageFolderPath):
                os.makedirs(storageFolderPath)

            if boardToCopyPath != '':
                shutil.copy2(boardToCopyPath, storageFullPath)
                println('Visual Board copied : {}    >>>    {}'.format(boardToCopyPath, storageFullPath))
            else:
                open(storageFullPath, 'w').close()
                println('Visual Board created : {}'.format(storageFullPath))

        # The copy is in place by now, so the board on the job drive goes. One that is open in
        # PureRef, or held by the storage drive's sync, refuses to be deleted, so it is left where
        # it is and tried again on the next press instead of failing the whole button.
        if os.path.isfile(originalFullPath):
            try:
                os.remove(originalFullPath)
                println('Old Visual Board deleted : {}'.format(originalFullPath))
            except OSError as deleteProblem:
                QMessageBox.warning(self, 'Ooops!',
                                    'The old Visual Board could not be deleted :\n\n{}\n\n{}\n\nThe board opens from its new home anyway, and BigKeeper tries this again the next time you open it.'.format(
                                        originalFullPath, deleteProblem))

        # Rebuilt whenever it is missing, so a board moved by hand still gets one back.
        if not os.path.isfile(shortcutFullPath):
            self.shortcutCreate(shortcutFullPath, storageFullPath)

        # .pur opens through its Windows file association.
        os.startfile(storageFullPath)


    def shortcutCreate(self, inShortcutFullPath, inTargetFullPath):
        println('\ndef >>>>> shortcutCreate')

        # The one place a Windows shortcut is made : the Visual Board, the RV session, the RV
        # comment folder and storageShortcutFolderRefresh all come here. Both paths are
        # normalised, as the comment folder always did, because the RV paths arrive with forward
        # slashes. Shortcut.exe is a console program : CREATE_NO_WINDOW keeps its black window
        # from flashing, which matters now that a list click can make several shortcuts at once.
        # Shortcut.exe /f:"<the .lnk>" /a:c /t:"<what it points at>"
        shortcutExecutablePath = os.path.normpath(os.path.join(externalToolPath, 'shortCut', 'Shortcut.exe'))
        shortcutCommand = shortcutExecutablePath + ' /f:"' + os.path.normpath(inShortcutFullPath) + '" /a:c /t:"' + os.path.normpath(inTargetFullPath) + '"'
        self.printEcho('shortcutCommand :' + shortcutCommand)
        subprocess.run(shortcutCommand, creationflags = subprocess.CREATE_NO_WINDOW)

    def storageShortcutRefresh(self, inType):
        println('\ndef >>>>> storageShortcutRefresh')

        # Called at the end of every list click, on both tabs. taskLocationPathRead is the folder
        # just clicked : the scenes or lib root, a sequence, a shot, or a task. Its Visual Board
        # is checked at every level. At a task level whose Task Type rvReviewFolderPreset.txt
        # pairs with a folder, that review folder's RV sessions are checked too. A folder above
        # the task level has no taskType.txt, so taskTypeRead gives '' and the RV half is skipped.
        jobFolderPath = self.taskLocationPathRead(inType)
        self.storageShortcutFolderRefresh(jobFolderPath, visualBoardStorageRootPath, visualBoardExtension)

        taskType = self.taskTypeRead(jobFolderPath)

        if taskType != '':
            rvReviewFolder = self.rvReviewFolderRead(taskType)
            if rvReviewFolder != '':
                self.storageShortcutFolderRefresh(os.path.join(jobFolderPath, rvReviewFolder), rvSessionStorageRootPath, '.rv')

    def storageShortcutFolderRefresh(self, inJobFolderPath, inStorageRootPath, inExtension):
        println('\ndef >>>>> storageShortcutFolderRefresh')

        # The storage folder mirrors inJobFolderPath under its own project folder, the same rule
        # visualBoardAction and rvReviewAction use. Every inExtension file in it gets a
        # <name>.lnk in inJobFolderPath when that shortcut is missing, whatever the job folder
        # holds : a missing version folder is for the user to notice, not for this to judge.
        # Only a job folder that is not there at all is skipped, so no click ever creates a
        # folder on the job drive. An unmapped K: reads as no storage folder, nothing happens.
        storageFolderPath = os.path.join(inStorageRootPath, self.selProj, os.path.relpath(inJobFolderPath, self.subDict[self.selProjPath]))
        self.printEcho(storageFolderPath)

        if not os.path.isdir(storageFolderPath) or not os.path.isdir(inJobFolderPath):
            return

        for eachName in os.listdir(storageFolderPath):
            storageFullPath = os.path.join(storageFolderPath, eachName)
            shortcutFullPath = os.path.join(inJobFolderPath, eachName + '.lnk')

            if eachName.lower().endswith(inExtension) and os.path.isfile(storageFullPath) and not os.path.isfile(shortcutFullPath):
                self.shortcutCreate(shortcutFullPath, storageFullPath)
                println('Shortcut made : {}    >>>    {}'.format(shortcutFullPath, storageFullPath))

    def openCurrentOpeningLocationPath(self):
        println('\ndef >>>>> openCurrentOpeningLocationPath')

        # Read the variable, not the lineEdit. The lineEdit is a display that
        # updateCurrentOpeningLocationPath writes into, and it is not read-only, so anything
        # typed into it used to be handed straight to os.startfile. The two Asset / Shot tab
        # < explore > buttons already read their variable this way.
        if self.currentOpeningLocationPath == '-NONE-':
            QMessageBox.warning(self, 'Ooops!', 'Nothing is open, so there is no location to explore.')
            return

        os.startfile(self.currentOpeningLocationPath)

    def listBigKeeperProject(self):
        println('\ndef >>>>> listBigKeeperProject')

        #this def is to read infomation from bigKeeperMel xml file
        f = open(r'N:/bpPipeline/maya/plugins/BigKeeper/bigKeeper_projectDatabase/bigPicture_projects.xml', "r")
        startLineNo = 1
        xmlStr = str()
        for x in f:
            if startLineNo > 1:
                xmlStr += x
            startLineNo += 1
        xmlRoot = ET.fromstring(xmlStr)


        ''' # EXAMPLE for CODING : Then the xml detail is stored as a nested Dictionary structure, for example:
            self.dictProj{
                'BigPicture_TestProj':
                    {'name': 'BigPicture_TestProj', 'path': 'N:/mnt/job/17901BigPicture_TestProj/WorkingFile/BigPicture_TestProj/', 'libraryfolder': 'lib', 'scenesfolder': 'scenes', 'workshopname': 'wip', 'mastername': 'published'},
                'BigPicture18_TestProj':
                    {'name': 'BigPicture18_TestProj', 'path': 'N:/mnt/job/18901BigPicture_TestProj/WorkingFile/BigPicture18_TestProj/', 'libraryfolder': 'lib', 'scenesfolder': 'scenes', 'workshopname': 'wip', 'mastername': 'published'},
                'PoonFilm':
                    {'name': 'PoonFilm', 'path': 'N:/mnt/job/18035PoonFilm/WorkingFile/PoonFilm/', 'libraryfolder': 'lib', 'scenesfolder': 'scenes', 'workshopname': 'wip', 'mastername': 'published'},
                'WOF':
                    {'name': 'WOF', 'path': 'N:/mnt/job/18012WOF/WorkingFile/WOF/', 'libraryfolder': 'lib', 'scenesfolder': 'scenes', 'workshopname': 'wip', 'mastername': 'published'}
                }'''
        self.dictProj = {}
        for i in xmlRoot.findall("project"):
            if os.path.exists(i.find('path').text): # To filter out those Proj Folder not on N Drive
                j = i.find('name').text
                k = i.find('path').text
                l = i.find('libraryfolder').text
                m = i.find('scenesfolder').text
                n = i.find('workshopname').text
                o = i.find('mastername').text
                self.printEcho(j)
                dictDetail = {}
                dictDetail.update({"name" :j})
                dictDetail.update({"path":k})
                dictDetail.update({"libraryfolder" : l })
                dictDetail.update({"scenesfolder" : m})
                dictDetail.update({"workshopname" : n})
                dictDetail.update({"mastername" : o})
                self.dictProj.update({j : dictDetail})
                self.printEcho(self.dictProj[j])


        self.printEcho(self.dictProj)
        listdictProjKey = []
        for i in self.dictProj:
            listdictProjKey.append(i)
        self.printEcho(listdictProjKey)
        self.printEcho(type(listdictProjKey))

        return listdictProjKey


    def versionUpSaveWIP(self, inShowDoneMsgBox):
        println('\ndef >>>>> versionUpSaveWIP')
        if in_nuke:
            bigKInfo = bigKeeperInfoGlobal_published.bigKeepCLASS()
            thisWipVer = bigKInfo.currentThisWipVerNum()
            self.printEcho(thisWipVer)
            nukescripts.script.script_version_up()

            bigKInfo = bigKeeperInfoGlobal_published.bigKeepCLASS()
            self.printEcho(bigKInfo.currentThisWipVerNum())
            if thisWipVer != bigKInfo.currentThisWipVerNum():
                self.printEcho('another WIP ver.')
                self.nukeUpdateMetadataNodeFps()
                self.nukeUpdateWriteNodeVer()

                nuke.scriptSave()

                nukeEnv = nuke.env
                isAssist = nukeEnv['assist']
                println(nukeEnv['assist'])


                if isAssist:

                    if inShowDoneMsgBox == True:

                        theMessage = 'Be Careful !\nBe Careful !!\nBe Careful !!!\n' + 'Currently in < Nuke Assist >.\n\n' + 'Only <Nuke Script WIP version _v#### > and <fps metadata> are updated.\n\nNone of <Write Nodes> are updated. Therefore :\n\n'+ '     1) Do not render this nuke script verion.\n' + '     2) Before submit render, you must <Version Up> in Nuke or NukeX to align the write node version number.'
                        QMessageBox.information(self, 'WARNING !!! ', theMessage)

                else:

                    if inShowDoneMsgBox == True:

                        theMessage = 'WIP version up, Done.\n\nbigK_Write nodes --- version numbers aligned.\nbigK_ModifyMetadata nodes --- fps metadata aligned to Project Setting.'
                        QMessageBox.information(self, 'version up', theMessage)






        elif in_houdini:
            hou.hipFile.saveAndIncrementFileName()
            if inShowDoneMsgBox == True:
                hou.ui.displayMessage('Done.', buttons=('OK',), default_choice=0, close_choice=0)




    def myDialogShow2(self, inTitle = 'inTitle', inMessage = 'inMessage'):
        println('\ndef >>>>> myDialogShow2')

        self.dialogUi.setWindowTitle(inTitle)
        self.dialogUi.label.setText(inMessage)
        # other initialization in def >>> initializeNewWIPDialogWindow

        self.dialogUi.show()

    def initializeNewWIPDialogWindow(self):
        println('\ndef >>>>> initializeNewWIPDialogWindow')
        self.dialogUi.setWindowTitle('my inTitle')
        self.dialogUi.label.setText('my inMessage')
        self.dialogUi.label.setWordWrap(True)
        self.dialogUi.pushButton_new.setText('NEW Wip')
        self.dialogUi.pushButton_current.setText('Use Currently Open Wip')
        self.dialogUi.pushButton_current.setVisible(True)
        self.dialogUi.pushButton_cancel.setText('cancel')

        self.dialogUi.pushButton_new.clicked.connect(self.createNewWIP2)
        self.dialogUi.pushButton_current.clicked.connect(self.useCurrentWIP)

        self.dialogUi.pushButton_cancel.clicked.connect(self.dialogUi.close)

    def prerendKeywordShow(self):
        println('\ndef >>>>> prerendKeywordShow')

        getBigKInfo = bigKeeperInfoGlobal_published.bigKeepCLASS()
        self.printEcho(getBigKInfo.currentProjWorkPath())

        self.prerendKeywordUi.comboBox.clear()
        self.prerendKeywordUi.lineEdit.clear()

        with open(os.path.join(getBigKInfo.currentProjWorkPath(), 'compPrerendPreset.txt')) as file:
            contents = file.readlines()
        self.printEcho(contents)

        keywords = [""]

        for i in contents:
            keywords.append(i.replace('\n', ""))

        self.printEcho(keywords)
        #for PySide6
        self.prerendKeywordsContent = keywords

        self.prerendKeywordUi.label.setText('Input a sub-name for sub-folderName and sub-framename :')
        self.prerendKeywordUi.comboBox.addItems(keywords)

        self.prerendKeywordUi.show()

    def initializePrerendKeywordUi(self):
        println('\ndef >>>>> initializePrerendKeywordUi')

        self.prerendKeywordUi.setWindowTitle('Prerend Keyword')

        self.prerendKeywordUi.pushButton_2.setText('OK')
        self.prerendKeywordUi.pushButton_3.setText('Cancel')
        self.prerendKeywordUi.pushButton_2.clicked.connect(lambda : self.prerendOKButtonAction(self.prerendKeywordUi.lineEdit.text()))
        #self.prerendKeywordUi.pushButton_2.clicked.connect(lambda : self.nukeBornWriteNode('Prerend', self.prerendKeywordUi.lineEdit.text()))
        #self.prerendKeywordUi.pushButton_2.clicked.connect(lambda : self.prerendKeywordUi.close())
        self.prerendKeywordUi.pushButton_3.clicked.connect(lambda : self.prerendKeywordUi.close())

        # for PySide2 as str
        #self.prerendKeywordUi.comboBox.activated[str].connect(self.prerendKeywordAction)
        # for PySide6 as int
        self.prerendKeywordUi.comboBox.activated[int].connect(self.prerendKeywordAction)


    def prerendKeywordAction(self, item):
        println('\ndef >>>>> prerendKeywordAction')
        self.printEcho(item)

        # PySide6
        item = self.prerendKeywordsContent[item]

        self.prerendKeywordUi.lineEdit.setText(item)
        keywordLength = len(self.prerendKeywordUi.lineEdit.text())
        self.printEcho(len(self.prerendKeywordUi.lineEdit.text()))
        self.prerendKeywordUi.lineEdit.setFocus()
        self.prerendKeywordUi.lineEdit.setCursorPosition(int(keywordLength))

        #self.prerendKeywordUi.lineEdit.setCursorPosition(100)


    def prerendOKButtonAction(self, item):
        println('\ndef >>>>> prerendOKButtonAction')
        self.printEcho(item)

        if item != "":
            self.nukeBornWriteNode('Prerend', item)
            self.prerendKeywordUi.close()
        else:
            self.printEcho('empty is not accepted')
            self.prerendKeywordUi.lineEdit.setFocus()


    def taskTypePresetRead(self, inType):
        println('\ndef >>>>> taskTypePresetRead')

        # The single place that reads the per project Task Type preset. Returns the keywords in
        # file order with blank lines dropped, and an empty list when the file is not there.
        # taskTypeNotSelected is kept : New Task needs it as the nothing chosen placeholder.
        # The picker in taskTypeChangeAction drops it at its own call site.

        if inType == 'typeScene':
            taskTypePresetName = 'taskTypeShotPreset.txt'
        elif inType == 'typeLib':
            taskTypePresetName = 'taskTypeAssetPreset.txt'

        # The project that is selected in the comboBox, not bigKInfo.currentProjWorkPath().
        # currentProjWorkPath follows the scene that is open in the DCC, which is a different
        # project when the user browses around, and is meaningless in standalone python.
        taskTypePresetFullName = os.path.join(self.subDict[self.selProjPath], taskTypePresetName)
        self.printEcho(taskTypePresetFullName)

        if not os.path.isfile(taskTypePresetFullName):
            QMessageBox.warning(self, 'Ooops!', 'Task Type preset is missing :\n\n{}'.format(taskTypePresetFullName))
            return []

        with open(taskTypePresetFullName) as file:
            contents = file.readlines()

        keywords = []

        for eachLine in contents:
            eachKeyword = eachLine.replace('\n', "")
            if eachKeyword != '':
                keywords.append(eachKeyword)

        self.printEcho(keywords)

        return keywords


    def taskTypeRead(self, inTaskPath):
        println('\ndef >>>>> taskTypeRead')

        # The pipeline step written by newTaskCreateAction, or an empty string when the task was
        # made before taskType.txt existed. Every task template ships a notes folder, and so do
        # the tasks made by the older templates, so the folder is there even when the file is not.
        taskTypeFullName = os.path.join(inTaskPath, 'notes', 'taskType.txt')
        self.printEcho(taskTypeFullName)

        if not os.path.isfile(taskTypeFullName):
            return ''

        with open(taskTypeFullName) as file:
            taskType = file.read().strip()

        return taskType


    def taskLocationPathRead(self, inType):
        println('\ndef >>>>> taskLocationPathRead')

        # sceneLocationPath and assetLocationPath are each tab's own task folder. Reading them
        # instead of the shared selProjScnShotTaskPath keeps each menu on its own tab.
        if inType == 'typeScene':
            taskLocationPath = self.sceneLocationPath
        elif inType == 'typeLib':
            taskLocationPath = self.assetLocationPath

        return taskLocationPath


    def rvReviewFolderRead(self, inTaskType):
        println('\ndef >>>>> rvReviewFolderRead')

        # rvReviewFolderPreset.txt in the project work folder pairs a Task Type with the folder
        # under the task that RV reviews, one <taskType>|<folder> per line, e.g. comp|output.
        # An empty string means this Task Type has no RV review, and an older project without
        # the file reads the same way. Both leave the RV rows disabled.
        rvReviewFolderPresetFullName = os.path.join(self.subDict[self.selProjPath], 'rvReviewFolderPreset.txt')
        self.printEcho(rvReviewFolderPresetFullName)

        if not os.path.isfile(rvReviewFolderPresetFullName):
            return ''

        with open(rvReviewFolderPresetFullName) as file:
            contents = file.readlines()

        for eachLine in contents:
            eachPair = eachLine.replace('\n', "").split('|')
            if eachPair[0] == inTaskType:
                return eachPair[1]

        return ''


    def taskTypeMenuRefresh(self, inType):
        println('\ndef >>>>> taskTypeMenuRefresh')

        # Connected to the menu's aboutToShow, so the row is read from disk every time the menu
        # opens. The button carrying the menu stays disabled until a task is picked, so the
        # location path is always set by the time this runs.
        taskType = self.taskTypeRead(self.taskLocationPathRead(inType))

        if taskType == '':
            rowText = '== Create taskType=='
            rvReviewFolder = ''
        else:
            rowText = 'Task Type :  ' + taskType
            rvReviewFolder = self.rvReviewFolderRead(taskType)

        self.printEcho(rowText)

        # The two RV rows open only in standalone python, and only for a Task Type that
        # rvReviewFolderPreset.txt pairs with a folder. Decided here and nowhere else : this runs
        # before every showing, so a setting made once in __init__ would be overridden.
        # in_python is None outside standalone, hence == True rather than the bare name.
        rvEnabled = in_python == True and rvReviewFolder != ''

        if inType == 'typeScene':
            self.shotTaskTypeAction.setText(rowText)
            self.shotAction3.setEnabled(rvEnabled)
            self.shotAction4.setEnabled(rvEnabled)
        elif inType == 'typeLib':
            self.assetTaskTypeAction.setText(rowText)
            self.assetAction3.setEnabled(rvEnabled)
            self.assetAction4.setEnabled(rvEnabled)


    def taskTypeChangeAction(self, inType):
        println('\ndef >>>>> taskTypeChangeAction')

        keywords = self.taskTypePresetRead(inType)

        # taskTypeNotSelected is the New Task placeholder. QInputDialog.getItem has its own
        # Cancel, so keeping it here would only be a way to write '-----' into the file.
        keywords = [eachKeyword for eachKeyword in keywords if eachKeyword != taskTypeNotSelected]

        if keywords == []:
            println('No Task Type to choose from.')
            return

        taskLocationPath = self.taskLocationPathRead(inType)
        currentTaskType = self.taskTypeRead(taskLocationPath)

        # Pre-select what the task already holds, so an accidental click followed by OK lands
        # back on the same value and the early return below writes nothing. getItem can only
        # offer what is in the list, so a stored type that has since been dropped from the
        # preset falls back to the first row.
        if currentTaskType in keywords:
            currentRow = keywords.index(currentTaskType)
        else:
            currentRow = 0

        taskType, ok = QInputDialog.getItem(self, 'Task Type', 'Task Type :', keywords, currentRow, False)

        if not ok:
            self.printEcho('Cancelled. Task Type is not changed.')
            return

        if taskType == currentTaskType:
            self.printEcho('Same Task Type. Nothing is changed.')
            return

        # Changing the pipeline step of a task that already has one is not a casual edit, so it
        # is gated by typing the word. Setting one for the first time is not gated, there is no
        # value to lose. The word is case sensitive on purpose, the point of the gate is to make
        # the user stop and read. A wrong word just asks again with what was typed still in the
        # box. getText carries its own Cancel, which is the only way out of the loop.
        if currentTaskType != '':
            confirmLabel = 'Task  < {} >\n\nfrom  < {} >\nto      < {} >\n\nType "change" to confirm :'.format(
                os.path.basename(taskLocationPath), currentTaskType, taskType)

            confirmWord = ''

            while confirmWord.strip() != 'change':
                confirmWord, ok = QInputDialog.getText(self, 'Confirm Task Type "change"', confirmLabel, QLineEdit.Normal, confirmWord)
                self.printEcho(confirmWord)

                if not ok:
                    self.printEcho('Cancelled. Task Type is not changed.')
                    return

        taskTypeFullName = os.path.join(taskLocationPath, 'notes', 'taskType.txt')

        # A task folder made by hand has no notes folder. Where the file lives is an internal
        # detail, so build the folder without saying anything.
        os.makedirs(os.path.dirname(taskTypeFullName), exist_ok = True)

        with open(taskTypeFullName, 'w') as file:
            file.write(taskType)

        self.printEcho(taskTypeFullName)
        self.printEcho(taskType)


    def newTaskKeywordShow(self, inType):
        println('\ndef >>>>> newTaskKeywordShow')

        # The OK button of newTaskKeywordUi is connected once at startup in initializeNewTaskKeywordUi,
        # and the dialog is one shared instance for both tabs. So the tag cannot be passed by lambda,
        # it has to be kept here for newTaskOKButtonAction and newTaskCreateAction to read.
        self.newTaskKeywordInType = inType

        self.newTaskKeywordUi.comboBox.clear()
        self.newTaskKeywordUi.lineEdit.clear()

        if inType == 'typeScene':
            self.newTaskKeywordUi.setWindowTitle('New Shot Task')
        elif inType == 'typeLib':
            self.newTaskKeywordUi.setWindowTitle('New Asset Task')

        # taskTypePresetRead raises its own warning naming the missing file and returns an
        # empty list. taskTypeNotSelected stays in the list here, it is the nothing chosen
        # placeholder that newTaskOKButtonAction rejects.
        keywords = self.taskTypePresetRead(inType)

        if keywords == []:
            return

        self.newTaskKeywordUi.label.setText('Input task name')
        self.newTaskKeywordUi.label_2.setText('Task Type :')
        self.newTaskKeywordUi.comboBox.addItems(keywords)

        self.newTaskKeywordUi.lineEdit.setFocus()
        self.newTaskKeywordUi.show()



    def initializeNewTaskKeywordUi(self):
        println('\ndef >>>>> initializeNewTaskKeywordUi')

        self.newTaskKeywordUi.setWindowTitle('New Task Keyword')

        self.newTaskKeywordUi.pushButton_2.setText('OK')
        self.newTaskKeywordUi.pushButton_3.setText('Cancel')

        self.newTaskKeywordUi.pushButton_2.clicked.connect(lambda : self.newTaskOKButtonAction(self.newTaskKeywordUi.lineEdit.text()))
        self.newTaskKeywordUi.pushButton_3.clicked.connect(lambda : self.newTaskKeywordUi.close())

        # presetWindow_PySide6 is a QMainWindow skeleton, not a QDialog, so it has no default
        # button and Enter does nothing on its own. Every QInputDialog in this file accepts
        # Enter, so the name field is wired to the same def the OK button calls.
        self.newTaskKeywordUi.lineEdit.returnPressed.connect(lambda : self.newTaskOKButtonAction(self.newTaskKeywordUi.lineEdit.text()))


    '''def newTaskKeywordAction(self, item):
        println('\ndef >>>>> newTaskKeywordAction')
        self.printEcho(item)

        # for PySide6
        item = self.newTaskKeywordsContent[item]

        self.newTaskKeywordUi.lineEdit.setText(item)
        keywordLength = len(self.newTaskKeywordUi.lineEdit.text())
        self.printEcho(len(self.newTaskKeywordUi.lineEdit.text()))
        self.newTaskKeywordUi.lineEdit.setFocus()
        self.newTaskKeywordUi.lineEdit.setCursorPosition(int(keywordLength))

        #self.newTaskKeywordUi.lineEdit.setCursorPosition(100)'''


    def nameInputCheck(self, inName):
        println('def >>>>> nameInputCheck')

        # The single place where the naming rules live. Returns an empty string when the
        # name is fine, otherwise the reason to show the user. Text only, no disk access.

        allowedCharacters = 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789_'
        maximumLength = 28
        windowsReservedNames = ['CON', 'PRN', 'AUX', 'NUL',
            'COM1', 'COM2', 'COM3', 'COM4', 'COM5', 'COM6', 'COM7', 'COM8', 'COM9',
            'LPT1', 'LPT2', 'LPT3', 'LPT4', 'LPT5', 'LPT6', 'LPT7', 'LPT8', 'LPT9']

        if inName == '':
            return 'The name is empty.'

        if inName != inName.strip():
            return 'The name starts or ends with a space.'

        if len(inName) > maximumLength:
            return 'The name is {} characters long. Keep it to {} or fewer, the wip path underneath is already deep.'.format(len(inName), maximumLength)

        badCharacters = []
        for eachCharacter in inName:
            if eachCharacter not in allowedCharacters and eachCharacter not in badCharacters:
                badCharacters.append(eachCharacter)

        if badCharacters != []:
            return '\nNot allowed :  {}\nOnly <Alphabet>, <Number>,  <underscore _ > can be used.'.format(
                '  '.join(['"{}"'.format(eachCharacter) for eachCharacter in badCharacters]))

        if inName.upper() in windowsReservedNames:
            return 'The name is reserved by Windows and cannot be used as a folder name.'

        return ''


    def namesListCheck(self, inNamesList, inParentPath):
        println('def >>>>> namesListCheck')

        # Runs the naming rules over every name and also asks whether the folder is
        # already there. Returns an empty string when every name is good to create,
        # otherwise one report line per problem, ready to drop into a message box.

        problemLines = []

        for eachName in inNamesList:
            nameProblem = self.nameInputCheck(eachName)

            if nameProblem != '':
                problemLines.append('<{}>    >>>    {}'.format(eachName, nameProblem))
            elif os.path.isdir(os.path.join(inParentPath, eachName)):
                problemLines.append('<{}>    >>>    Already exists.'.format(eachName))

        for eachLine in problemLines:
            self.printEcho(eachLine)

        return '\n'.join(problemLines)


    def nameInputAsk(self, inDialogTitle, inDialogLabel, inParentPath):
        println('def >>>>> nameInputAsk')

        # Keeps asking until the name passes, and returns an empty string when the user
        # cancels. Replaces the passToken loop that used to sit in the two create defs.

        while True:
            inputName, ok = QInputDialog.getText(self, inDialogTitle, inDialogLabel, QLineEdit.Normal)
            self.printEcho(inputName)

            if not ok:
                self.printEcho('Cancelled. Nothing created.')
                return ''

            problemReport = self.namesListCheck([inputName], inParentPath)

            if problemReport == '':
                return inputName

            QMessageBox.warning(self, 'Ooops!', '{}\n\n{}'.format(inDialogTitle, problemReport))

    def newTaskOKButtonAction(self, item):
        println('\ndef >>>>> newTaskOKButtonAction')
        self.printEcho(item)

        inType = self.newTaskKeywordInType
        taskType = self.newTaskKeywordUi.comboBox.currentText()

        if taskType == taskTypeNotSelected:
            self.printEcho('task type is not selected')
            QMessageBox.warning(self, 'Ooops!', 'New Task\n\nPlease select a Task Type.')
            return

        # The components folder is what listWidget_3_appear already built for this tab, so it
        # is read back instead of being joined again out of the shared selShot.
        taskParentPath, shotName, taskName = self.taskLevelConvert(inType)
        newParentPath = taskParentPath

        problemReport = self.namesListCheck([item], newParentPath)

        if problemReport != '':
            self.printEcho(problemReport)
            QMessageBox.warning(self, 'Ooops!', 'New Task\n\n{}'.format(problemReport))
            self.newTaskKeywordUi.lineEdit.setFocus()
            return

        toBeCreatePath = os.path.join(newParentPath, item)
        self.printEcho(toBeCreatePath)

        self.newTaskCreateAction(item, toBeCreatePath, inType, taskType)
        self.newTaskKeywordUi.close()


    def createProgressExecute(self, inCommandPairs, inHeadingText, inTargetListWidget):
        println('def >>>>> createProgressExecute')

        startTime = time.time()
        totalCount = len(inCommandPairs)
        finishedCount = 0
        failedNames = []
        newItem = None

        progressBox = QMessageBox()
        progressBox.setStandardButtons(QMessageBox.NoButton)
        progressBox.setWindowTitle(inHeadingText)
        progressBox.show()
        QApplication.processEvents()

        for displayName, theCmd in inCommandPairs:
            self.printEcho(theCmd)

            # Popen instead of os.system, so the event loop keeps running while robocopy works
            # and the progress window does not go "not responding".
            theProcess = subprocess.Popen(theCmd, shell = True)
            while theProcess.poll() is None:
                progressBox.setText('Creating < {} of {} > :  {}\n\nremaining : {}\n\nelapsed : {} seconds'.format(
                    finishedCount + 1, totalCount, displayName,
                    totalCount - finishedCount, round(time.time() - startTime, 1)))
                QApplication.processEvents()
                time.sleep(0.1)

            finishedCount += 1

            # robocopy does NOT use the xcopy convention. Below 8 is success
            # (0 nothing to do, 1 copied, 2 extra, 4 mismatched), 8 and above is a real failure.
            # Without this check the listWidget shows a row for a folder that was never created.
            if theProcess.returncode < 8:
                newItem = QListWidgetItem(displayName)
                inTargetListWidget.addItem(newItem)
                QApplication.processEvents()
            else:
                self.printEcho('FAILED < {} > : robocopy returncode {}'.format(displayName, theProcess.returncode))
                failedNames.append(displayName)

        progressBox.close()

        endTime = time.time()
        createdCount = totalCount - len(failedNames)

        if failedNames == []:
            QMessageBox.information(self, 'message', '{}\n\n< {} of {} > created. ({} seconds)'.format(
                inHeadingText, createdCount, totalCount, round(endTime - startTime, 2)))
        else:
            QMessageBox.warning(self, 'message', '{}\n\n< {} of {} > created. ({} seconds)\n\nFAILED :\n{}'.format(
                inHeadingText, createdCount, totalCount, round(endTime - startTime, 2), '\n'.join(failedNames)))

        return newItem


    def newTaskCreateAction(self, inTask, inPath, inType, inTaskType):
        println('def >>>>> newTaskCreateAction')

        if inType == 'typeScene':
            theCmd = r'robocopy "N:\bpPipeline\bigKeeperPyIni\templateShotTask" "{}" {}'.format(inPath, roboCopyFlags)
            targetListWidget = self.listWidget_3
            headingText = 'New Shot Task'
        elif inType == 'typeLib':
            theCmd = r'robocopy "N:\bpPipeline\bigKeeperPyIni\templateAssetTask" "{}" {}'.format(inPath, roboCopyFlags)
            targetListWidget = self.listWidget_AssetTask
            headingText = 'New Asset Task'

        newItem = self.createProgressExecute([(inTask, theCmd)], headingText, targetListWidget)

        if newItem is None:
            self.printEcho('robocopy failed. Nothing was added to the list.')
            return

        # The task type is the pipeline step. Written only after robocopy reported success,
        # the notes folder comes from the template and does not exist before that.
        taskTypeFullName = os.path.join(inPath, 'notes', 'taskType.txt')
        with open(taskTypeFullName, 'w') as file:
            file.write(inTaskType)
        self.printEcho(taskTypeFullName)

        targetListWidget.setCurrentItem(newItem)
        targetListWidget.scrollToItem(newItem)

        self.listWidget_shotTask_action(newItem, inType)


    def newShotCreateAction(self, inType):
        println('def >>>>> newShotCreateAction')

        if inType == 'typeScene':
            newParentPath = self.selProjScnShotPath
            templatePath = r'N:\bpPipeline\bigKeeperPyIni\templateShot'
            targetListWidget = self.listWidget_2
            dialogLabel = 'New Shot Name :'
            headingText = 'New Shot'
        elif inType == 'typeLib':
            newParentPath = self.selProjAssetTypeAssetPath
            templatePath = r'N:\bpPipeline\bigKeeperPyIni\templateAsset'
            targetListWidget = self.listWidget_Asset
            dialogLabel = 'New Asset Name :'
            headingText = 'New Asset'

        inputName = self.nameInputAsk(headingText, dialogLabel, newParentPath)

        if inputName == '':
            return

        newPath = os.path.join(newParentPath, inputName)
        theCmd = r'robocopy "{}" "{}" {}'.format(templatePath, newPath, roboCopyFlags)

        newItem = self.createProgressExecute([(inputName, theCmd)], headingText, targetListWidget)

        if newItem is None:
            self.printEcho('robocopy failed. Nothing was added to the list.')
            return

        targetListWidget.setCurrentItem(newItem)
        targetListWidget.scrollToItem(newItem)

        self.listWidget_3_appear(newItem, inType)


    '''def existingNamesCheck(self, inNamesList, inParentPath):
        println('def >>>>> existingNamesCheck')

        existingNames = []
        for eachName in inNamesList:
            if os.path.isdir(os.path.join(inParentPath, eachName)):
                self.printEcho('already exists : {}'.format(eachName))
                existingNames.append(eachName)

        return existingNames'''


    def newShotCreateBatchAction(self, inType):
        println('def >>>>> newShotCreateBatchAction')

        if inType == 'typeScene':
            targetListWidget = self.listWidget_2
            newParentPath = self.selProjScnShotPath
            templatePath = r'N:\bpPipeline\bigKeeperPyIni\templateShot'
            dialogTitle = 'Open Shot Name List file'
            headingText = 'New Shot Batch'
        elif inType == 'typeLib':
            targetListWidget = self.listWidget_Asset
            newParentPath = self.selProjAssetTypeAssetPath
            templatePath = r'N:\bpPipeline\bigKeeperPyIni\templateAsset'
            dialogTitle = 'Open Asset Name List file'
            headingText = 'New Asset Batch'

        # ref: https://www.tutorialspoint.com/pyqt/pyqt_qfiledialog_widget.htm
        inputFile, selectedFilter = QFileDialog.getOpenFileName(self, dialogTitle, 'c:\\', 'Text file (*.txt)')

        if inputFile == '':
            self.printEcho('Cancelled or empty input. Nothing created.')
            return

        self.printEcho(inputFile)

        shotNamesList = []
        f = open(inputFile, 'r')
        for line in f:
            if line != '\n':
                shotNamesList.append(line.rstrip('\n'))

        f.close()

        self.printEcho(shotNamesList)

        if shotNamesList == []:
            self.printEcho('No name found in the file. Nothing created.')
            return

        problemReport = self.namesListCheck(shotNamesList, newParentPath)

        if problemReport != '':
            QMessageBox.warning(self, 'Ooops!', '{}\n\nNothing created. Fix the list file, then try again :\n\n{}'.format(
                headingText, problemReport))
            return

        commandPairs = []
        for i in shotNamesList:
            newPath = os.path.join(newParentPath, i)
            commandPairs.append((i, r'robocopy "{}" "{}" {}'.format(templatePath, newPath, roboCopyFlags)))

        newItem = self.createProgressExecute(commandPairs, headingText, targetListWidget)

        if newItem is None:
            self.printEcho('Every robocopy failed. Nothing was added to the list.')
            return

        targetListWidget.setCurrentItem(newItem)
        targetListWidget.scrollToItem(newItem)

        self.listWidget_3_appear(newItem, inType)



    def newSequenceCreateAction(self, inType):
        println('def >>>>> newSequenceCreateAction')

        if inType == 'typeScene':
            newParentPath = self.selProjScnPath
            targetListWidget = self.listWidget_1
            dialogLabel = 'New Sequence Name :'
            headingText = 'New Sequence'
        elif inType == 'typeLib':
            newParentPath = self.selProjLibPath
            targetListWidget = self.listWidget_AssetType
            dialogLabel = 'New Asset Type Name :'
            headingText = 'New Asset Type'

        inputName = self.nameInputAsk(headingText, dialogLabel, newParentPath)

        if inputName == '':
            return

        newPath = os.path.join(newParentPath, inputName)

        theCmd = 'mkdir "{}"'.format(newPath)
        self.printEcho(theCmd)
        os.system(theCmd)

        newItem = QListWidgetItem(inputName)
        targetListWidget.addItem(newItem)
        targetListWidget.setCurrentItem(newItem)
        targetListWidget.scrollToItem(newItem)

        self.listWidget_2_appear2(newItem, inType)




    def createNewWIP2(self):
        print ('\ndef >>>>> createNewWIP2')

        # Same as useCurrentWIP : newWipInType is stashed by listWidget_3C_action because this
        # dialog's buttons are connected once at startup and cannot carry the tag by lambda.
        taskParentPath, shotName, taskName = self.taskLevelConvert(self.newWipInType)

        self.selProjScnShotTaskWIPPath = os.path.join(taskParentPath, taskName, self.subDict[self.selProjWipCode])
        self.printEcho(self.selProjScnShotTaskWIPPath)

        # A task folder made by hand has no wip folder. The user has just answered New WIP,
        # so build it here instead of letting open() fail. Covers both open() calls below.
        os.makedirs(self.selProjScnShotTaskWIPPath, exist_ok = True)

        newWipName = (shotName + "_" + taskName + "_" + self.subDict[self.selProjWipCode] + "_v0000" + wipExtension)
        self.printEcho(newWipName)

        println()

        if nuke.Root().modified() == True:
            self.printEcho('current changes have not yet been saved!')
            nuke.scriptClose() ### pop a dialog instead of close.
            if nuke.Root().modified() == False:

                thepath = os.path.join(self.selProjScnShotTaskWIPPath, newWipName)
                f = open(thepath, 'w')
                f.close()

                self.dialogUi.close()
                self.openLastestWIP()

                println()
        else:
            println()
            thepath = os.path.join(self.selProjScnShotTaskWIPPath, newWipName)
            f = open(thepath, 'w')
            f.close()

            self.dialogUi.close()
            self.openLastestWIP()
            self.updateCurrentOpeningLocationPath()

        println()
        sys.path.append(r'N:\bpPipeline\bigKeeperPy\py\externalPyModule\compTeamNukePy')
        import projectRoot_published
        projectRoot_published.projectSetting()
        nuke.scriptSave()
        os.remove(os.path.join(self.selProjScnShotTaskWIPPath, newWipName+'~'))
        sys.path.remove(r'N:\bpPipeline\bigKeeperPy\py\externalPyModule\compTeamNukePy')





    def useCurrentWIP(self):
        println('\ndef >>>>> useCurrentWIP')

        self.printEcho('bigKeeperCacheFolderPath :{}'.format(bigKeeperCacheFolderPath))


        if os.path.exists(os.path.join(bigKeeperCacheFolderPath, 'nukeTempSaveB4NewUseCurrent.nk')):
            os.remove(os.path.join(bigKeeperCacheFolderPath, 'nukeTempSaveB4NewUseCurrent.nk'))
        nuke.scriptSaveAs(os.path.join(bigKeeperCacheFolderPath, 'nukeTempSaveB4NewUseCurrent.nk'))


        """
        if nuke.Root().modified() == True:
            println()
            self.printEcho('current changes have not yet been saved!')
            nuke.scriptClose() ### pop a dialog instead of close.

            '''
            if nuke.Root().modified() == False:

                println()
                self.selProjScnShotTaskWIPPath = os.path.join(self.selProjScnShotTaskPath, self.selTask, self.subDict[self.selProjWipCode])
                self.printEcho(self.selProjScnShotTaskWIPPath)


                newWipName = (self.selShot + "_" + self.selTask + "_" + self.subDict[self.selProjWipCode] + "_v0000" + wipExtension)
                self.printEcho(newWipName)
                saveName = os.path.join(self.selProjScnShotTaskWIPPath,newWipName)
                self.printEcho(saveName)
                nuke.scriptSaveAs(saveName)

                self.printEcho(nuke.root()['name'].value())
                self.printEcho(os.path.dirname( nuke.root().name() ))
                self.dialogUi.close()

            '''


        else:

            println()
            println('bigKeeperCacheFolderPath :{}'.format(bigKeeperCacheFolderPath))
            self.selProjScnShotTaskWIPPath = os.path.join(self.selProjScnShotTaskPath, self.selTask, self.subDict[self.selProjWipCode])
            self.printEcho(self.selProjScnShotTaskWIPPath)


            newWipName = (self.selShot + "_" + self.selTask + "_" + self.subDict[self.selProjWipCode] + "_v0000" + wipExtension)
            self.printEcho(newWipName)
            saveName = os.path.join(self.selProjScnShotTaskWIPPath,newWipName)
            self.printEcho(saveName)
            nuke.scriptSaveAs(saveName)

            self.printEcho(nuke.root()['name'].value())
            self.printEcho(os.path.dirname( nuke.root().name() ))
            self.dialogUi.close()

            self.updateCurrentOpeningLocationPath()
        """

        # The New WIP dialog is one shared instance and its two buttons are connected once at
        # startup in initializeNewWIPDialogWindow, so the tag cannot arrive by lambda. It is
        # stashed by listWidget_3C_action, the only def that opens the dialog.
        taskParentPath, shotName, taskName = self.taskLevelConvert(self.newWipInType)

        self.printEcho('bigKeeperCacheFolderPath :{}'.format(bigKeeperCacheFolderPath))
        self.selProjScnShotTaskWIPPath = os.path.join(taskParentPath, taskName, self.subDict[self.selProjWipCode])
        self.printEcho(self.selProjScnShotTaskWIPPath)


        newWipName = (shotName + "_" + taskName + "_" + self.subDict[self.selProjWipCode] + "_v0000" + wipExtension)
        self.printEcho(newWipName)
        saveName = os.path.join(self.selProjScnShotTaskWIPPath,newWipName)
        self.printEcho(saveName)
        nuke.scriptSaveAs(saveName)

        self.printEcho(nuke.root()['name'].value())
        self.printEcho(os.path.dirname( nuke.root().name() ))
        self.dialogUi.close()

        self.updateCurrentOpeningLocationPath()

        QMessageBox.information(self, 'New Wip with Used Current', 'New WIP in new task < {} > created.'.format(taskName))


    def nukeScriptOpenTolerant(self, inFullPath):
        println('\ndef >>>>> nukeScriptOpenTolerant')

        # nuke.scriptOpen raises RuntimeError for two very different things, and the bare call
        # this def replaces let both of them kill the rest of the open handler : the freeze
        # callback, the Scene Update check and the tab switch all stopped running.
        #   - The script IS loaded, but something in it complained. A knob value the current
        #     colour config no longer offers ( a Nuke 15 script carrying < display ACES > opened
        #     in Nuke 17 ), a missing gizmo, an unknown node. Nuke leaves that knob at its
        #     default value and the script is open, so the caller carries on.
        #   - The script is NOT loaded at all. nuke.root() is then still the previous script and
        #     the caller must stop, or it would run its follow up steps on the wrong script.
        # Comparing the root name against the path asked for is what tells the two apart.
        try:
            nuke.scriptOpen(inFullPath)
            errorText = ''
        except RuntimeError as theError:
            errorText = str(theError)

        openedPath = nuke.root().name()
        self.printEcho('asked for : {}'.format(inFullPath))
        self.printEcho('opened    : {}'.format(openedPath))

        # nuke.root().name() is forward slashed, os.path.join builds backslashes on Windows.
        isOpened = os.path.normpath(openedPath).lower() == os.path.normpath(inFullPath).lower()

        if errorText != '' and isOpened == True:
            QMessageBox.warning(self, 'Ooops!', '{}\n\nis open, but Nuke reported :\n\n{}\n\nThe knobs named above are left at their default value.\nSaving a new version writes the corrected value back.'.format(inFullPath, errorText))

        elif errorText != '':
            QMessageBox.warning(self, 'Ooops!', '{}\n\nis NOT opened. Nuke reported :\n\n{}'.format(inFullPath, errorText))

        return isOpened


    def pretendCloseNukeScript(self):
        println('\ndef >>>>> pretendCloseNukeScript')

        nuke.scriptClear()

        '''
        # script before knowing there is a nuke.scriptClear()
        nuke.scriptClose()

        thepath = os.path.join(os.environ['LOCALAPPDATA'], 'bigKeeperPy', 'tmpNukeScript.nk')
        f = open(thepath, 'w')
        f.close()

        nuke.scriptOpen(os.path.join(os.environ['LOCALAPPDATA'], 'bigKeeperPy', 'tmpNukeScript.nk'))
        nuke.onScriptLoad(self.nukeFileKnobFreezeScriptLoad())
        '''

    '''
    def checkCurrentUnsaveStatus(self):
        println('\ndef >>>>> checkCurrentUnsaveStatus')
        if in_nuke:
            if nuke.Root().modified() == True:
                self.printEcho('current changes have not yet been saved!')
                nuke.scriptClose() ### pop a dialog instead of close.
                if nuke.Root().modified() == False:
                    nuke.scriptOpen(os.path.join(self.selProjScnShotTaskWIPPath, self.listFile[-1]))
                    nuke.onScriptLoad(self.nukeFileKnobFreezeScriptLoad())

            else:

                nuke.scriptClose()
                nuke.scriptOpen(os.path.join(self.selProjScnShotTaskWIPPath, self.listFile[-1]))
                nuke.onScriptLoad(self.nukeFileKnobFreezeScriptLoad())
                #window.close()
    '''

    def updateCurrentOpeningLocationPath(self):
        println('\ndef >>>>> updateCurrentOpeningLocationPath')

        if in_nuke:
            self.currentOpeningLocationPath = os.path.dirname(nuke.root().name())
        elif in_houdini:
            self.currentOpeningLocationPath = os.path.dirname(hou.hipFile.path())
        elif in_maya:
            self.currentOpeningLocationPath = os.path.dirname(cmds.file(q=True, sn=True))
        elif in_python:
            self.currentOpeningLocationPath = os.path.dirname(os.getcwd())
        elif in_blender:
            self.currentOpeningLocationPath = os.path.dirname(bpy.data.filepath)


        if self.currentOpeningLocationPath == '':
            self.currentOpeningLocationPath = '-NONE-'
        self.printEcho(self.currentOpeningLocationPath)
        self.lineEdit_Location_2.setText(self.currentOpeningLocationPath)

    def createShotNewTask(self):
        println('\ndef >>>>> createShotNewTask')
        folderList = ['cache', 'daily/yyyymmdd', 'notes', 'preview', self.subDict[self.selProjPublishCode], 'research', 'textures/PSD', 'version', self.subDict[self.selProjWipCode]]
        taskName = str(input('Please input New Task Name :'))
        for folder in folderList:
            self.printEcho(os.path.join(self.selProjScnShotTaskPath, taskName, folder))
            os.makedirs(os.path.join(self.selProjScnShotTaskPath, taskName, folder))
        self.listWidget_3.addItem(str(taskName))

    '''def compareCurrentFrameInfo(self):
        bigKInfo = bigKeeperInfoGlobal_published.bigKeepCLASS()

        if in_nuke:
            if (nuke.Root().knob('first_frame').value() != float(bigKInfo.currentShotFrameIn())) or (nuke.Root().knob('last_frame').value() != float(bigKInfo.currentShotFrameOut())) or (nuke.Root().knob('fps').value() != float(bigKInfo.currentShotFrameFps())):
                self.pushButton_getFrameRange.setStyleSheet("background-color:rgb(250,5,5); color:rgb(10, 10, 10)")
            else:
                self.pushButton_getFrameRange.setStyleSheet("background-color:rgb(128,179,179); color:rgb(10, 10, 10)")'''

    def getCurrentFrameInfo(self):
        println('\ndef >>>>> getCurrentFrameInfo')
        bigKInfo = bigKeeperInfoGlobal_published.bigKeepCLASS()

        if in_nuke:
            nuke.Root().knob('first_frame').setValue(float(bigKInfo.currentShotFrameIn()))
            nuke.Root().knob('last_frame').setValue(float(bigKInfo.currentShotFrameOut()))
            nuke.Root().knob('fps').setValue(float(bigKInfo.currentShotFrameFps()))
            self.nukeUpdateMetadataNodeFps()

            self.printEcho(nuke.Root().knob('first_frame').value())
            self.printEcho(nuke.Root().knob('last_frame').value())
            self.printEcho(nuke.Root().knob('fps').value())

            #nuke.message('Done.')
            QMessageBox.information(self, 'message', "Done.\nAll fps in output <Metadata Node> aligned to Project Setting.")

        if in_houdini:
            getFrameIn = float(bigKInfo.currentShotFrameIn())
            getFrameOut = float(bigKInfo.currentShotFrameOut())
            getFps = float(bigKInfo.currentShotFrameFps())


            # Assign Frame Start and Frame End in Global Animation Options
            hou.hscript("tset " + str((getFrameIn-1)/getFps) + " " + str((getFrameOut)/getFps))
            hou.playbar.setPlaybackRange(getFrameIn,getFrameOut)
            hou.setFrame(getFrameIn)
            hou.setFps(getFps)

            #println(" The *** Frame Start *** is assigned to " + str(getFrameIn))
            #println(" The *** Frame End *** is assigned to " + str(getFrameOut))
            # For this section, I cannot find any suitable python function to set Global Animation Options : Start frame and End frame
            # The above is just copy from internet source : https://forums.odforce.net/topic/16709-how-can-i-set-the-playback-range/
            # Don't really how to set the frame range by the line <hou.hscript> & the line <hou.playbar.setPlaybackRange>.
            # please teach me what the follow means, if you know about it.
            # by Benson

            hou.ui.displayMessage('Done.', buttons=('OK',), default_choice=0, close_choice=0)

    def nukeTempTool1(self):
        println('nukeTempTool1')
        self.nukeTempUi.LoadInOutFrame()
        self.nukeTempUi.show()

        #bigKInfo = bigKeeperInfoGlobal_published.bigKeepCLASS()
        #self.nukeTempUi.initializeNukeTempWindow()

    def createShotNewTask_appear(self):
        println('\ndef >>>>> createShotNewTask_appear')
        if self.listWidget_2.currentRow() > -1:
            self.createShotNewTaskUi.show()
        else:
            #buttonReply = QMessageBox.question(self, 'PyQt5 message', "Do you like PyQt5?", QMessageBox.Yes | QMessageBox.No, QMessageBox.No)
            # QMessageBox ref: https://pythonspot.com/pyqt5-messagebox/
            QMessageBox.information(self, 'message', "no shot is selected.")
            '''if buttonReply == QMessageBox.Yes:
                self.printEcho('Yes clicked.')
            else:
                self.printEcho('No clicked.')'''




    def createShotNewTaskAction(self):
        println('\ndef >>>>> createShotNewTaskAction')
        self.printEcho(self.createShotNewTaskUi.lineEdit.text())
        folderList = ['cache', 'daily/yyyymmdd', 'notes', 'preview', self.subDict[self.selProjPublishCode], 'research', 'textures/PSD', 'version', self.subDict[self.selProjWipCode]]
        taskName = self.createShotNewTaskUi.lineEdit.text()
        for folder in folderList:
            self.printEcho(os.path.join(self.selProjScnShotTaskPath, taskName, folder))
            os.makedirs(os.path.join(self.selProjScnShotTaskPath, taskName, folder))
        self.listWidget_3.addItem(str(taskName))
        self.createShotNewTaskUi.close()

    def createShotNewTaskClose(self):
        println('\ndef >>>>> createShotNewTaskClose')
        self.createShotNewTaskUi.close()

    def tempchecklist2selected(self):
        println('\ndef >>>>> tempchecklist2selected')
        status = self.listWidget_2.currentRow()
        self.printEcho(status)

    def compLatestRvAction(self):
        println('\ndef >>>>> compLatestRvAction')
        self.printEcho(os.path.join(self.selProjScnShotTaskPath, 'comp', 'output'))
        thePath = os.path.join(self.selProjScnShotTaskPath, 'comp', 'output')
        if self.listWidget_2.currentRow() > -1:
            try:
                folderList = os.listdir(thePath)
            except:
                QMessageBox.information(self, 'message', 'Standard "Comp" & "Output" folder not found.')

            self.printEcho(folderList)
            listSeq = []
            for i in folderList:
                if (len(i) <= 5) and (i[0] == 'v') and i[1::].isnumeric():
                    self.printEcho(i)
                    self.printEcho(os.path.join(self.selProjScnShotTaskPath, 'comp', 'output', i))
                    if os.path.isdir(os.path.join(self.selProjScnShotTaskPath, 'comp', 'output', i)):
                        listSeq.append(os.path.join(self.selProjScnShotTaskPath, 'comp', 'output', i))
            listSeq.sort()
            self.printEcho(listSeq)
            if len(listSeq) > 0:
                self.printEcho(listSeq[-1])
                self.launchStudioEnvRv(listSeq[-1])
            else:
                QMessageBox.information(self, 'message', r'No folder in ...\comp\output')
        else:
            QMessageBox.information(self, 'message', "no shot is selected.")

    def editTaskAction(self, inType):
        println('\ndef >>>>> editTaskAction')

        # Both arms used to differ only by the listWidget, and both handed the shared selTask
        # down to listWidget_3C_action. The task name now comes from this tab's own state.
        taskParentPath, shotName, taskName = self.taskLevelConvert(inType)

        if inType == 'typeScene':
            listWidgetTask = self.listWidget_3
        elif inType == 'typeLib':
            listWidgetTask = self.listWidget_AssetTask

        if listWidgetTask.currentRow() > -1:
            self.printEcho(taskName)
            self.listWidget_3C_action(taskName, inType)
        else:
            QMessageBox.information(self, 'message', "no task is selected.")

    def shotAction2Action(self):
        println('\ndef >>>>> shotAction2Action')
        self.compLatestRvAction()

    def rvReviewPathRead(self, inType):
        println('\ndef >>>>> rvReviewPathRead')

        # The folder RV reviews and its mirror in the storage tree, as a plain tuple. The review
        # folder is no longer hardcoded comp\output : it is the folder rvReviewFolderPreset.txt
        # pairs with this task's Task Type, and taskTypeMenuRefresh only enables the RV rows when
        # that pair exists. The storage folder mirrors it under its own project folder, the way
        # the Visual Board does.
        taskLocationPath = self.taskLocationPathRead(inType)
        rvReviewPath = os.path.join(taskLocationPath, self.rvReviewFolderRead(self.taskTypeRead(taskLocationPath)))
        rvStorageFolderPath = os.path.join(rvSessionStorageRootPath, self.selProj, os.path.relpath(rvReviewPath, self.subDict[self.selProjPath]))
        self.printEcho(rvReviewPath)
        self.printEcho(rvStorageFolderPath)

        return (rvReviewPath, rvStorageFolderPath)

    def rvPreviousVersionShow(self, inType):
        println('\ndef >>>>> rvPreviousVersionShow')

        # rvPreviousVersionUi is a single dialog shared by both tabs. Its exec button and double
        # click are connected once in __init__, so the tab is stashed here for them to read.
        self.rvPreviousVersionInType = inType

        rvReviewPath, rvStorageFolderPath = self.rvReviewPathRead(inType)

        if not os.path.isdir(rvReviewPath):
            QMessageBox.information(self, 'message', 'Review folder not found :\n\n{}'.format(rvReviewPath))
            return

        folderOnlyList = []
        for i in os.listdir(rvReviewPath):
            if os.path.isdir(os.path.join(rvReviewPath, i)):
                folderOnlyList.append(i)
        folderOnlyList.sort(reverse=True)
        self.printEcho(folderOnlyList)

        # A version whose .rv is already in the storage tree is marked, so the user knows it opens
        # at once with no build. The marked text is no longer the folder name, so the folder name
        # rides in UserRole, which is what __init__ hands to rvReviewAction.
        self.rvPreviousVersionUi.listWidget.clear()
        for eachFolder in folderOnlyList:
            if os.path.isfile(os.path.join(rvStorageFolderPath, eachFolder + '.rv')):
                displayText = eachFolder + ' - <rv>'
            else:
                displayText = eachFolder

            newItem = QListWidgetItem(displayText)
            newItem.setData(Qt.UserRole, eachFolder)
            self.rvPreviousVersionUi.listWidget.addItem(newItem)

        # Row 0 picked, so the exec button never runs on no row.
        self.rvPreviousVersionUi.listWidget.setCurrentRow(0)
        self.rvPreviousVersionUi.show()


    def rvReviewAction(self, inType, inChosenVersion):
        println('\ndef >>>>> rvReviewAction')

        # inChosenVersion is None from the menu row, which reviews the latest version, or the
        # folder name picked in rvPreviousVersionUi.
        self.printEcho('inChosenVersion : {}'.format(inChosenVersion))

        rvReviewPath, rvStorageFolderPath = self.rvReviewPathRead(inType)

        if not os.path.isdir(rvReviewPath):
            QMessageBox.information(self, 'message', 'Review folder not found :\n\n{}'.format(rvReviewPath))
            return

        # The latest version is the highest of the v#### folders on the job drive and the
        # v####.rv sessions in the storage tree. An office whose frames have not arrived yet
        # still opens the newest .rv that K:'s sync brought, and RV itself reports the missing
        # frames.
        if inChosenVersion == None:
            listSeq = []
            for i in os.listdir(rvReviewPath):
                if (len(i) <= 5) and (i[0] == 'v') and i[1::].isnumeric() and os.path.isdir(os.path.join(rvReviewPath, i)):
                    listSeq.append(i)

            if os.path.isdir(rvStorageFolderPath):
                for i in os.listdir(rvStorageFolderPath):
                    versionName = i[:-3]
                    if i.lower().endswith('.rv') and (len(versionName) <= 5) and (versionName[0] == 'v') and versionName[1::].isnumeric() and versionName not in listSeq:
                        listSeq.append(versionName)

            listSeq.sort()
            self.printEcho(listSeq)

            if len(listSeq) == 0:
                QMessageBox.information(self, 'message', 'No v#### folder or .rv in :\n\n{}\n\n{}'.format(rvReviewPath, rvStorageFolderPath))
                return

            chosenVersion = listSeq[-1]
        else:
            chosenVersion = inChosenVersion

        chosenVersionPath = os.path.join(rvReviewPath, chosenVersion)
        self.printEcho(chosenVersionPath)

        # The .rv lives in the storage tree. The folder RV reviews on the job drive keeps only
        # a shortcut beside the version folder : output\v0005.rv.lnk
        rvFileName = chosenVersion + '.rv'
        rvStorageFullPath = os.path.join(rvStorageFolderPath, rvFileName)
        rvOriginalFullPath = os.path.join(rvReviewPath, rvFileName)
        shortcutFullPath = rvOriginalFullPath + '.lnk'
        self.printEcho(rvStorageFullPath)

        # An .rv built before the storage tree existed is copied there with no question asked :
        # it is the same session, only somewhere else.
        if not os.path.isfile(rvStorageFullPath) and os.path.isfile(rvOriginalFullPath):
            if not os.path.isdir(rvStorageFolderPath):
                os.makedirs(rvStorageFolderPath)
            shutil.copy2(rvOriginalFullPath, rvStorageFullPath)
            println('RV session copied : {}    >>>    {}'.format(rvOriginalFullPath, rvStorageFullPath))

        # The copy is in place by now, so the .rv on the job drive goes. One that is open in RV
        # refuses to be deleted, so it is left where it is and tried again on the next press.
        if os.path.isfile(rvOriginalFullPath):
            try:
                os.remove(rvOriginalFullPath)
                println('Old RV session deleted : {}'.format(rvOriginalFullPath))
            except OSError as deleteProblem:
                QMessageBox.warning(self, 'Ooops!',
                                    'The old RV session could not be deleted :\n\n{}\n\n{}\n\nThe session opens from its new home anyway, and BigKeeper tries this again the next time you open it.'.format(
                                        rvOriginalFullPath, deleteProblem))

        # An .rv that already exists is opened as it is, never rebuilt.
        if not os.path.isfile(rvStorageFullPath):

            # Only a v#### folder is built into an .rv session. Anything else, a LayerMask or a
            # FreeLayerMask folder, is opened in Explorer.
            if not ((len(chosenVersion) <= 5) and (chosenVersion[0] == 'v') and chosenVersion[1::].isnumeric()):
                os.startfile(chosenVersionPath)
                return

            # fps is the third line of the shot's frameRange.txt, the file bigKInfo.currentShotFrameFps
            # reads. It is read here from the shot picked in the browser, because bigKInfo follows the
            # script open in the DCC, and os.getcwd() in standalone python. No file, ask the user.
            componentsPath, shotName, taskName = self.taskLevelConvert(inType)
            frameRangeFullName = os.path.join(componentsPath, 'frameRange.txt')
            self.printEcho(frameRangeFullName)

            if os.path.isfile(frameRangeFullName):
                with open(frameRangeFullName) as file:
                    fps = float(file.readlines()[2])
            else:
                fps, ok = QInputDialog.getDouble(self, 'Input fps', 'frameRange.txt not found :\n{}\n\nfps of this review :'.format(frameRangeFullName), 24, 1, 240, 3)
                if not ok:
                    return

            self.printEcho('fps : {}'.format(fps))

            # The storage tree is built as it is used, so every level is made on its first build.
            if not os.path.isdir(rvStorageFolderPath):
                os.makedirs(rvStorageFolderPath)

            if not self.createRvFile(chosenVersionPath, chosenVersion, rvStorageFullPath, shotName, fps):
                return

        # Rebuilt whenever it is missing, so an .rv moved by hand still gets one back.
        if not os.path.isfile(shortcutFullPath):
            self.shortcutCreate(shortcutFullPath, rvStorageFullPath)

        self.launchStudioEnvRv(rvStorageFullPath)

    def createRvFile(self, inLatestVerPath, inLatestVer, inRvFullPath, inShotName, inFps):

        println('\ndef >>>>> createRvFile')
        self.printEcho(inLatestVerPath)
        self.printEcho(inLatestVer)

        # Returns True once the .rv is written, False when the folder holds no image sequence.
        # inFps comes from the caller, read from frameRange.txt or asked from the user. The fps
        # used to come from the bigkframepersecond EXR metadata, which no other format can carry.

        def getMetaData():
            self.printEcho('\n   def >>>>> getMetaData')

            import subprocess, os

            def getFrames(inPath):
                self.printEcho('\n       def >>>>> getFrames')
                # A frame is <name>.<number>.<extension>, whatever the image format. That rule alone
                # drops Thumbs.db, a .mov, and the .tmp files a render in progress leaves behind.
                allFiles = os.listdir(inPath)
                self.printEcho(inPath)
                onlyFiles = []
                self.printEcho(allFiles)
                for i in allFiles:
                    splitName = i.split('.')
                    if len(splitName) == 3 and splitName[1].isnumeric() and splitName[2].lower() != 'tmp' and os.path.isfile(os.path.join(inPath, i)):
                        onlyFiles.append(i)
                onlyFiles.sort()

                return onlyFiles

            theFrameList = getFrames(inLatestVerPath)
            self.printEcho('theFrameList : {}'.format(theFrameList))

            if len(theFrameList) == 0:
                return None

            FrameStartFullName = theFrameList[0].split('.')
            FrameEndFullName = theFrameList[-1].split('.')

            FrameFrontName = FrameStartFullName[0]
            FrameFirstFrameNo = FrameStartFullName[1]
            FrameEndFrameNo = FrameEndFullName[1]
            FrameExtension = FrameStartFullName[2]

            startFrameDigit = (len(FrameFirstFrameNo))
            startFrameDigitNoZero = (len(str(int(FrameFirstFrameNo))))
            endFrameDigit = (len(FrameEndFrameNo))
            endFrameDigitNoZero = (len(str(int(FrameEndFrameNo))))

            # Pattern 1 : name.0000001.exr to name.0010030.exr --> @@@@@@@
            # Pattern 2 : name.1.exr to name.0010030.exr --> @
            # Pattern 3 : name.998.exr to name.2001.exr -- > @@@
            # Pattern 4 : name.001001.exr to name.002001.exr --> @@@@@@
            # Pattern 5 : name.0998.exr to name.2001.exr --> #
            # Pattern 6 : name.1001.exr to name.2001.exr --> #

            if (startFrameDigit == endFrameDigit) and ((endFrameDigit - endFrameDigitNoZero) == 0):
                symbol = '#'
            else:
                symbol = '@'* startFrameDigit


            # carl.1001-1010@@@@@.exr
            rvStringName = (FrameFrontName + '.' + str(int(FrameFirstFrameNo)) + '-' + str(int(FrameEndFrameNo)) + symbol + '.' + FrameExtension)
            self.printEcho('rvStringName : ' + rvStringName)


            #externalToolPath = r'N:\BigKeeper\py\externalTool'
            input_file = os.path.normpath(os.path.join(inLatestVerPath, theFrameList[0]))
            self.printEcho(input_file)



            exec_command = os.path.normpath(os.path.join(externalToolPath, r'exiftool.exe'))
            self.printEcho(exec_command)
            #exec_command = r'N:\BigKeeper\py\externalTool\exiftool.exe'
            #input_file = r'N:\mnt\job\18012WOF\WorkingFile\WOF\scenes\hologramSeq\ac0343\components\comp\output\v0015\ac0343.1001.exr'
            arg1 = r'-all'
            arg2 = r'-ImageWidth'
            arg3 = r'-ImageHeight'
            arg0 = r'-s2' # s1--tag names instead of descriptions   s2--no extra spaces    s3--values only

            self.printEcho('before run')
            process = subprocess.Popen([exec_command, input_file, arg1, arg0], stdout = subprocess.PIPE, stderr = subprocess.STDOUT, universal_newlines = True)
            self.printEcho('after run')

            # store data in dict way
            infoDict = {}
            #println(process.stdout.read())
            for i in process.stdout:
                line = i.strip().split(':')     #splite Tag as line[0], value as line[1]. (line is <list> type)
                infoDict[line[0].strip()] = line[1].strip()     # line[0] as dict's key, line[1] as value.

            self.printEcho('infoDict:')
            self.printEcho(infoDict)

            metaData = []

            try:
                metaData.append(int(infoDict['ImageWidth']))
            except:
                metaData.append(320) #make a dramatic wrong, user will be alerted. Will develop to pop up dialog for user input.

            try:
                metaData.append(int(infoDict['ImageHeight']))
            except:
                metaData.append(240) #make a dramatic wrong, user will be alerted. Will develop to pop up dialog for user input.

            metaData.append(rvStringName)
            metaData.append(FrameFirstFrameNo)
            metaData.append(FrameEndFrameNo)

            return metaData

        def askFolderName():
            println('\n   def >>>>> askFolderName')
            try:
                defaultText = self.storedAnsweredFolder
            except:
                defaultText = ""
            answerFolder = QInputDialog.getText(self, 'Input Folder Name', 'To create instance-shortcut for comment folder,\nformat: <yyyymmdd>\n\nor\n\nPress cancel to skip.',QLineEdit.Normal, defaultText)
            self.printEcho(answerFolder)

            return answerFolder

        def createShortCut(folderName, inShotName, iniRvVersion, inRvFullPathName):
            println('\n   def >>>>> createShortCut')
            self.printEcho(self.subDict[self.selProjPath])

            # The comment folder sits in the RV storage tree on K:, so every office gets it through
            # K:'s sync. The shortcuts in it point at K: too, the same drive letter at every office.
            targetShortCutPath = os.path.normpath(os.path.join(rvSessionStorageRootPath, self.selProj, 'comment', folderName))
            self.printEcho(targetShortCutPath)
            if not os.path.isdir(targetShortCutPath):
                os.makedirs(targetShortCutPath)

            linkName = os.path.normpath(os.path.join(targetShortCutPath, str(inShotName + '_' + iniRvVersion))) + r'__shortcut' + r'.lnk'
            self.shortcutCreate(linkName, inRvFullPathName)




        # rvTemplate = r'N:\mnt\job\19901BigPicture_TestProj\_bigkeeperPyData\rv.template'

        with open(rvTemplate) as f:
            data = f.readlines()

        self.printEcho('***************************************')

        MetaData = getMetaData()

        if MetaData == None:
            QMessageBox.information(self, 'message', 'No image sequence in :\n\n{}'.format(inLatestVerPath))
            return False

        inWidth, inHeight, inRvStringName, inFrameFirstFrameNo, inFrameEndFrameNo = MetaData
        RvStringMovie = (str(inLatestVerPath + '/' + inRvStringName).replace("\\", "/"))
        rvTimeLineStart = 1
        rvTimeLineEnd = int(inFrameEndFrameNo) - int(inFrameFirstFrameNo) + 1 + rvTimeLineStart

        lineForWidthHeight = [80, 286, 601]
        lineForFps = [19, 79, 223, 255, 287, 581, 600]
        lineForPathStringMovie = [574]
        lineForStringName = [370]
        lineForStartFrame = [280, 598]
        lineForEndFrame = [281]
        lineForEndFramePlus1 = [598]
        lineForRvTimeLineStartEnd = [17, 18, 279]

        self.printEcho(inRvStringName[0:-4:1])
        self.printEcho(RvStringMovie)

        #string movie = "N:/mnt/job/18006Chery/WorkingFile/Chery/scenes/turnTable/ttb0030/components/comp/output/v0015/ttb0030.1-10030@@@@@@@.tga"
        for line in lineForWidthHeight:
            data[line-1] = data[line-1].replace('__<bigkeeperPy_Width>__', str(inWidth))
            data[line-1] = data[line-1].replace('__<bigkeeperPy_Height>__', str(inHeight))

        for line in lineForFps:
            data[line-1] = data[line-1].replace('__<bigkeeperPy_fps>__', str(inFps))

        for line in lineForPathStringMovie:
            data[line-1] = data[line-1].replace('__<bigkeeperPy_stringMovie>__', str(RvStringMovie))

        for line in lineForStringName:
            data[line-1] = data[line-1].replace('__<bigkeeperPy_stringName>__', str(inRvStringName[0:-4:1]))

        for line in lineForStartFrame:
            data[line-1] = data[line-1].replace('__<frameNoStart>__', str(int(inFrameFirstFrameNo)))

        for line in lineForEndFrame:
            data[line-1] = data[line-1].replace('__<frameNoEnd>__', str(int(inFrameEndFrameNo)))

        for line in lineForEndFramePlus1:
            data[line-1] = data[line-1].replace('__<frameNoEndPlus1>__', str(int(inFrameEndFrameNo)+1))

        for line in lineForRvTimeLineStartEnd:
            data[line-1] = data[line-1].replace('__<rvTimelineStart>__', str(rvTimeLineStart))
            data[line-1] = data[line-1].replace('__<rvTimelineEnd>__', str(rvTimeLineEnd))

        # inRvFullPath sits in the storage tree under rvSessionStorageRootPath, worked out by the
        # caller, which also makes its folder.
        writePath = inRvFullPath.replace("\\", "/")
        #writePath = writePath.replace("\\", "/")
        self.printEcho('writePath is :' + writePath)
        with open(writePath, 'w') as f:
            f.writelines(data)

        receivedAnswerFolder = askFolderName()
        if receivedAnswerFolder[1]:
            self.storedAnsweredFolder = receivedAnswerFolder[0]
            createShortCut(self.storedAnsweredFolder, inShotName, inLatestVer, writePath)

        return True

    def findNodeLargestNumber(self, InPrefix, InNodeClassName):
        println('\ndef >>>>> findNodeLargestNumber')

        dedictatedPrefix = InPrefix
        nodeClassName = InNodeClassName


        # Gather all the nodes in the scene
        allNodes = nuke.allNodes()
        sameNodeNameList = []

        # sort out only (bigK + targetClassName)nodes
        for i in allNodes:
            mergePrefix = dedictatedPrefix + '_' + nodeClassName + '_'
            if i.name()[0:len(mergePrefix)] == mergePrefix:
                sameNodeNameList.append(i.name())

        self.printEcho('sameNodeNameList :')
        self.printEcho(sameNodeNameList)
        if len(sameNodeNameList) > 0:
            # find out the Largest number
            seperator = '_' + nodeClassName + '_'
            self.printEcho('seperator')

            allNumbers = []
            for i in sameNodeNameList:
                splitName = i.split(seperator)
                self.printEcho(seperator)
                self.printEcho('splitName :')
                self.printEcho(splitName)
                allNumbers.append(int(splitName[-1]))
            allNumbers.sort()
            self.printEcho(allNumbers)
            LargestNumber = int(allNumbers[-1])
        else:
            LargestNumber = 0

        return LargestNumber


    def nukeBornBigKNode(self, InPrefix, InNodeClassName):
        println('\ndef >>>>> nnukeBornBigKNode')

        """dedictatedPrefix = 'bigK'
        nodeClassName = 'Grade'"""
        dedictatedPrefix = InPrefix
        nodeClassName = InNodeClassName

        self.printEcho('nodeClassName :')
        self.printEcho(nodeClassName)
        self.printEcho('dedictatedPrefix :')
        self.printEcho(dedictatedPrefix)

        targetNumber = self.findNodeLargestNumber(InPrefix = dedictatedPrefix, InNodeClassName = nodeClassName)
        self.printEcho('targetNumber :')
        self.printEcho(targetNumber)

        NewNodeName = dedictatedPrefix + '_' + nodeClassName + '_' + str(targetNumber + 1)

        self.printEcho('NewNodeName :')
        self.printEcho(NewNodeName)
        #newCreatedNode = nuke.nodes.nodeClassName(name=NewNodeName)
        #newCreatedNode.setInput(1, userSelNode)
        newCreatedNode = nuke.createNode(nodeClassName)
        newCreatedNode.knob('name').setValue(NewNodeName)

        return newCreatedNode

    def nukeBornGradeNode(self):
        println('\ndef >>>>> nukeBornGradeNode')

        #newCreatedNodeMetadata = self.nukeBornBigKNode('bigK', 'ModifyMetaData')
        newCreatedNodeMetadata = self.nukeBornMetadataNode()
        newCreatedNode = self.nukeBornBigKNode('bigK', 'Grade')
        newCreatedNode.setInput(0, newCreatedNodeMetadata)

        return newCreatedNode

    def nukeCheckKnobContentUnique(self, inClass, inKnob, inContent):
        println('\ndef >>>>> nukeCheckPathUnique')

        self.printEcho('inContent is :')
        self.printEcho(inContent)
        allNodes = nuke.allNodes(filter=inClass)
        nodeList = []
        duplicatedNodeList = []

        for i in allNodes:
            knobValue = os.path.normpath(i.knob(inKnob).getValue())
            nodeList.append(i)
            self.printEcho(inContent)
            self.printEcho(knobValue)
            if inContent in knobValue:
                duplicatedNodeList.append(i.name())

        self.printEcho(nodeList)
        self.printEcho(duplicatedNodeList)

        if len(duplicatedNodeList) > 0:
            isUnique = False

            dupMessage = inContent + '\n\nThe above path is already existed in :\n\n' + str(duplicatedNodeList)
            QMessageBox.information(self, 'message', dupMessage)
        else:
            isUnique = True

        return isUnique


    def nukeAskSubName(self, inDefaultName):
        println('\ndef >>>>> nukeAskSubName')

        # Keeps asking until the sub-name passes nameInputCheck, the same rules the browser
        # side uses. Returns an empty string when the user cancels, which nameInputCheck
        # already rejects as a name, so the two cannot be confused.
        # No already-exists test here : the folder is only made by the Write node at render
        # time, so on disk it is supposed to be missing.
        subName = inDefaultName

        while True:
            subName, ok = QInputDialog.getText(self, 'sub-name', 'Input a sub-name for sub-folderName and sub-framename', QLineEdit.Normal, subName)
            self.printEcho(subName)

            if not ok:
                self.printEcho('Cancelled. Nothing created.')
                return ''

            nameProblem = self.nameInputCheck(subName)

            if nameProblem == '':
                return subName

            QMessageBox.warning(self, 'Ooops!', 'sub-name\n\n<{}>    >>>    {}'.format(subName, nameProblem))


    def nukeAskSuffix(self):
        bigKInfo = bigKeeperInfoGlobal_published.bigKeepCLASS()
        self.printEcho(bigKInfo.currentCompIniSuffix())

    def compWriteNodePresetRead(self):
        println('\ndef >>>>> compWriteNodePresetRead')

        # The per project Write node preset. Read from currentProjWorkPath(), the project of the
        # script open in Nuke, the same source prerendKeywordShow uses for compPrerendPreset.txt.
        # Deliberately NOT subDict[selProjPath] : that is whichever project the browser comboBox
        # is showing, which is a different project as soon as the user browses elsewhere.
        bigKInfo = bigKeeperInfoGlobal_published.bigKeepCLASS()

        presetFullName = os.path.join(bigKInfo.currentProjWorkPath(), compWriteNodePresetFileName)
        self.printEcho(presetFullName)

        if not os.path.isfile(presetFullName):
            QMessageBox.warning(self, 'Ooops!', 'Write Node preset is missing :\n\n{}'.format(presetFullName))
            return []

        with open(presetFullName) as file:
            contents = file.readlines()

        presetLines = []

        for eachLine in contents:
            eachPreset = eachLine.replace('\n', "").strip()
            if eachPreset != '' and not eachPreset.startswith('#'):
                presetLines.append(eachPreset)

        self.printEcho(presetLines)

        return presetLines


    def compWriteNodePresetAsk(self):
        println('\ndef >>>>> compWriteNodePresetAsk')

        # Asks once and returns the display name of the chosen preset plus its knob and value
        # pairs, in the order the .txt wrote them. Returns an empty string and an empty list when
        # there is nothing to choose, when a line is malformed or when the user cancels, so the
        # caller tests displayLabel and leaves the nodes alone.
        # One line of the .txt :
        #   <setText><exr 16>|<file_type><exr>|<datatype><16 bit half>|<compression><Zip (16 scanlines)>
        # Field 1 is the only thing the artist sees. Every other field is one Nuke knob name and
        # the value to set on it, so a new knob is one more |<knobName><value> and no code change.
        # The whole file is parsed before the picker opens : the .txt is hand edited by the
        # project leader, so a malformed line stops everything and names itself, rather than
        # quietly dropping a preset out of the list.
        presetLines = self.compWriteNodePresetRead()

        if presetLines == []:
            println('No Write Node preset to choose from.')
            return '', []

        # displayLabels feeds the picker, allKnobValuePairs holds the parsed rest. The two lists
        # stay index aligned, so the picked row reads straight out of both.
        displayLabels = []
        allKnobValuePairs = []

        for eachLine in presetLines:
            knobValuePairs = []

            for eachField in eachLine.split('|'):
                eachField = eachField.strip()

                # <knobName><value> : strip the outer angle brackets, then split on the pair in
                # the middle. '<><exr>' becomes ['', 'exr'], caught by the empty-name test below.
                if not eachField.startswith('<') or not eachField.endswith('>') or '><' not in eachField:
                    QMessageBox.warning(self, 'Ooops!', 'This preset field is not shaped as <knobName><value> :\n\n{}\n\nin the line :\n\n{}'.format(eachField, eachLine))
                    return '', []

                knobName, knobValue = eachField[1 : -1].split('><', 1)
                knobValuePairs.append((knobName.strip(), knobValue.strip()))

            if len(knobValuePairs) < 2:
                QMessageBox.warning(self, 'Ooops!', 'This preset line needs a <setText> field and a <file_type> field :\n\n{}'.format(eachLine))
                return '', []

            firstKnobName, firstKnobValue = knobValuePairs[0]
            secondKnobName, secondKnobValue = knobValuePairs[1]

            if firstKnobName != 'setText' or firstKnobValue == '':
                QMessageBox.warning(self, 'Ooops!', 'The first field of a preset line must be <setText><display name> :\n\n{}'.format(eachLine))
                return '', []

            # file_type has to be set before Nuke will even create datatype / compression /
            # mov64_codec, so its place in the line is not a matter of taste.
            if secondKnobName != 'file_type' or secondKnobValue == '':
                QMessageBox.warning(self, 'Ooops!', 'The second field of a preset line must be <file_type><value> :\n\n{}'.format(eachLine))
                return '', []

            for eachKnobName, eachKnobValue in knobValuePairs[1 : ]:
                if eachKnobName == '' or eachKnobValue == '':
                    QMessageBox.warning(self, 'Ooops!', 'This preset line carries an empty knob name or an empty value :\n\n{}'.format(eachLine))
                    return '', []

            displayLabels.append(firstKnobValue)
            allKnobValuePairs.append(knobValuePairs[1 : ])

        # getItem hands back the text, not the row, so two lines sharing a display name would
        # silently apply whichever one comes first.
        if len(set(displayLabels)) != len(displayLabels):
            QMessageBox.warning(self, 'Ooops!', 'Two preset lines carry the same <setText> display name :\n\n     {}'.format('\n     '.join(displayLabels)))
            return '', []

        # Pre-select the preset picked last time. This session only, same idea as
        # freeLayerMaskLastFolder, so a second node usually needs one click.
        if self.compWriteNodePresetLastChoice in displayLabels:
            currentRow = displayLabels.index(self.compWriteNodePresetLastChoice)
        else:
            currentRow = 0

        displayLabel, ok = QInputDialog.getItem(self, 'WriteNode Preset', 'Preset :', displayLabels, currentRow, False)

        if not ok:
            self.printEcho('Cancelled. No preset is applied.')
            return '', []

        self.compWriteNodePresetLastChoice = displayLabel

        knobValuePairs = allKnobValuePairs[displayLabels.index(displayLabel)]
        self.printEcho(knobValuePairs)

        return displayLabel, knobValuePairs


    def compWriteNodePresetApply(self, inNode, inKnobValuePairs):
        println('\ndef >>>>> compWriteNodePresetApply')

        # Sets every knob the chosen preset line names, in the order the .txt wrote them, then
        # rewrites the tail of the file path. Returns True when the node was changed, so the
        # caller can list what it did.
        # compWriteNodePresetAsk already checked the shape of the line, so file_type is always
        # the first pair. That order is what makes the rest reachable : Nuke only creates
        # datatype / compression / mov64_codec after the file type is set.
        # Only Enumeration knobs are supported for now. A numeric knob such as mov64_fps says so
        # by name instead of raising.
        fileType = ''

        for eachKnobName, eachKnobValue in inKnobValuePairs:

            eachKnob = inNode.knob(eachKnobName)

            if eachKnob is None:
                QMessageBox.warning(self, 'Ooops!', '{} :\n\nThis Nuke has no knob named < {} >.\n\nThe rest of the preset is not applied.'.format(inNode.name(), eachKnobName))
                return False

            # values() belongs to Enumeration knobs only.
            if not hasattr(eachKnob, 'values'):
                QMessageBox.warning(self, 'Ooops!', '{} :\n\nKnob < {} > is not an enumeration.\n\nOnly enumeration knobs are supported for now.\nThe rest of the preset is not applied.'.format(inNode.name(), eachKnobName))
                return False

            # Some Nuke enumeration entries carry a tab and a tooltip behind the value, so
            # compare against the part in front of the tab.
            knobValues = [eachEntry.split('\t')[0] for eachEntry in eachKnob.values()]

            if eachKnobValue not in knobValues:
                QMessageBox.warning(self, 'Ooops!', '{} :\n\nKnob < {} > does not accept < {} >.\n\nIt accepts :\n\n     {}'.format(inNode.name(), eachKnobName, eachKnobValue, '\n     '.join(knobValues)))
                return False

            eachKnob.setValue(eachKnobValue)

            # The file_type value is also the file extension the path is rewritten with.
            if eachKnobName == 'file_type':
                fileType = eachKnobValue

        fileKnob = inNode.knob('file')

        if not fileKnob.enabled():
            println('{} : <file> knob is locked. The format knobs are set, the path is not rewritten.'.format(inNode.name()))
            return True

        # Rewrite only the tail. The folder, the shot name, the sub-name and the suffix all stay
        # exactly as they are, which is what lets this def run on an existing node as well as on
        # a node that was just born. A sequence keeps its .%04d, a movie is one single file and
        # loses it. The sub-name passed nameInputCheck, whose whitelist is A-Z a-z 0-9 _ , so the
        # only dots in the basename are the padding and the extension.
        originalPath = fileKnob.value()
        self.printEcho('originalPath : {}'.format(originalPath))

        headPath, baseName = os.path.split(originalPath)
        stemName = baseName.rsplit('.', 1)[0]

        if stemName.endswith('.%04d'):
            stemName = stemName[0 : -len('.%04d')]

        if fileType in compWriteNodeSingleFileTypes:
            baseName = stemName + '.' + fileType
        else:
            baseName = stemName + '.%04d.' + fileType

        updatedPath = os.path.join(headPath, baseName).replace(os.sep, '/')
        self.printEcho('updatedPath  : {}'.format(updatedPath))

        fileKnob.setValue(updatedPath)

        return True


    def compWriteNodePresetApplyToSelected(self):
        println('\ndef >>>>> compWriteNodePresetApplyToSelected')

        # The preset is asked once, then applied to every selected Write node. Ask and Apply are
        # two defs on purpose : this button needs one dialog for many nodes, and later
        # nukeBornWriteNode will need the same pair for one node it has just created.
        selectedWriteNodes = nuke.selectedNodes('Write')

        if len(selectedWriteNodes) == 0:
            QMessageBox.information(self, 'message', 'No Write node is selected.')
            return

        displayLabel, knobValuePairs = self.compWriteNodePresetAsk()

        if displayLabel == '':
            return

        appliedNodeNames = []

        for eachNode in selectedWriteNodes:
            if self.compWriteNodePresetApply(eachNode, knobValuePairs):
                appliedNodeNames.append(eachNode.name())

        # Every node that failed already raised its own warning naming itself, so only report
        # the ones that went through.
        if len(appliedNodeNames) > 0:
            doneMessage = displayLabel + '\n\nis applied to :\n\n     ' + '\n     '.join(appliedNodeNames)
            QMessageBox.information(self, 'message', doneMessage)

    def nukeBornWriteNode(self, inType, *args):
        println('\ndef >>>>> nukeBornWriteNode')

        # answerName starts as '' not None, it is fed back into the dialog as the default
        # text when a clashed path sends the loop round again.
        answerName = ''
        answerSuffix = readyToCreate = None

        try:
            self.printEcho(args)
            self.printEcho(args[0])
        except:
            args=[None]
            self.printEcho('no args, assigned {} instead.'.format(args[0]))

        try:
            orignalSelNode = nuke.selectedNode()
            self.printEcho('original :::')
            self.printEcho(orignalSelNode)
            self.printEcho(type(orignalSelNode))
        except:
            orignalSelNode = None

        numOfSelNodes = len(nuke.selectedNodes())

        if numOfSelNodes > 1:
            QMessageBox.information(self, 'message', 'Please only select 1 node as anchor OR as input node.')

        elif numOfSelNodes < 1 :
            QMessageBox.information(self, 'message', 'No node is selected.\n\nPlease create a "DOT" node as an anchor.')

        else:
            if len(orignalSelNode.dependent()) > 1:
                errorMessage = 'The output of the selected node :\n     ' + str(orignalSelNode.name()) + "\nis linked to other node.\n\nTo avoid Node Graph chaos :\n1) Create a seperate DOT node as an Anchor.\n2) Select the Anchor to generate again.\n3) After the nodes are generated, re-connect manually, if needed."
                QMessageBox.information(self, 'message', errorMessage)
            else:
                bigKInfo = bigKeeperInfoGlobal_published.bigKeepCLASS()

                # The output format is asked before the retry loop, so it is asked once no matter
                # how many times a clashed path sends the loop round again. Asking here also means
                # a Cancel leaves no half built node behind, same as the suffix dialogs below.
                # An empty label is Cancel, an unreadable .txt, or a .txt that is not there at all,
                # all of which already showed their own message.
                # The node is created with the .exr frame name the branches below build, then
                # compWriteNodePresetApply rewrites the tail of that path once the node exists.
                presetDisplayLabel, presetKnobValuePairs = self.compWriteNodePresetAsk()

                if presetDisplayLabel == '':
                    println('WriteNode Preset dialog cancelled. Nothing is created.')
                    return

                # The target folder does not exist on disk yet, a Write node only makes it at
                # render time. So the other Write nodes in this script are the only place a
                # duplicated target can be found.
                # canRetry says whether asking again could produce a different path. It is True
                # only for the types whose folder carries a name the user typed. CompMaster,
                # CompMaster-V and Prerend build their path from the task, the version and a
                # preset keyword, so looping there would ask the same question forever.
                passToken = False
                canRetry = False

                while passToken == False:

                    if inType == 'CompMaster':
                        self.printEcho(inType)
                        canRetry = False

                        answerName = inType

                        if answerSuffix is None:
                            answerSuffix = bigKInfo.currentCompIniSuffix()

                        answerSuffix, readyToCreate = QInputDialog.getText(self, 'Suffix', 'Suffix : (empty if not needed.)', QLineEdit.Normal, answerSuffix)

                        if readyToCreate == False:
                            println('Suffix dialog cancelled. Nothing is created.')
                            return

                        frameName = str(bigKInfo.currentShot()) + answerSuffix + '.%04d' + '.exr'
                        verFolder = 'v' + str(bigKInfo.currentThisWipVerNum()).zfill(4)
                        targetFilePath = os.path.normpath(os.path.join(str(bigKInfo.currentTaskPath()), 'output', verFolder, frameName))
                        checkPath      = os.path.normpath(os.path.join(str(bigKInfo.currentTaskPath()), 'output', verFolder))
                        backdropLabel = inType


                    elif inType == 'CompMasterToV':
                        self.printEcho(inType)
                        canRetry = False

                        answerName = inType

                        if answerSuffix is None:
                            answerSuffix = bigKInfo.currentCompIniSuffix()

                        answerSuffix, readyToCreate = QInputDialog.getText(self, 'Suffix', 'Suffix : (empty if not needed.)', QLineEdit.Normal, answerSuffix)

                        if readyToCreate == False:
                            println('Suffix dialog cancelled. Nothing is created.')
                            return

                        frameName = str(bigKInfo.currentShot()) + answerSuffix + '.%04d' + '.exr'
                        vDriveFolder = self.vDrivePathRead(os.path.join(bigKInfo.currentProjWorkPath(), 'bigPathsProject.ini'), 'BIGPATHS', 'vOutput')
                        outputVdriveFolder = os.path.join(vDriveFolder, bigKInfo.currentShot())

                        targetFilePath = os.path.normpath(os.path.join(outputVdriveFolder, frameName))
                        checkPath      = outputVdriveFolder
                        backdropLabel = inType

                    elif inType == 'LayerMask':
                        self.printEcho(inType)
                        canRetry = True

                        answerName = self.nukeAskSubName(answerName)

                        if answerName == '':
                            println('sub-name dialog cancelled. Nothing is created.')
                            return

                        if answerSuffix is None:
                            answerSuffix = bigKInfo.currentCompIniSuffix()

                        answerSuffix, readyToCreate = QInputDialog.getText(self, 'Suffix', 'Suffix : (empty if not needed.)', QLineEdit.Normal, answerSuffix)

                        if readyToCreate == False:
                            println('Suffix dialog cancelled. Nothing is created.')
                            return

                        frameName = str(bigKInfo.currentShot()) + '_' + answerName + answerSuffix + '.%04d' + '.exr'
                        verFolder = 'v' + str(bigKInfo.currentThisWipVerNum()).zfill(4) + '_' + inType
                        targetFilePath = os.path.normpath(os.path.join(str(bigKInfo.currentTaskPath()), 'output', verFolder, answerName, frameName))
                        checkPath = os.path.normpath(os.path.join(str(bigKInfo.currentTaskPath()), 'output', verFolder, answerName))
                        backdropLabel = answerName + '_' + inType

                    elif inType == freeLayerMaskType:
                        self.printEcho(inType)
                        canRetry = True

                        # Same three answers as LayerMask, but the parent folder is picked by the
                        # user instead of being <taskPath>\output. Remembered for this session only,
                        # so a retry re-opens the dialog on the folder that just clashed.
                        if self.freeLayerMaskLastFolder == '':
                            self.freeLayerMaskLastFolder = str(bigKInfo.currentTaskPath())

                        parentFolder = self.askExistingFolder('Choose the parent folder of this ' + inType + ' output', self.freeLayerMaskLastFolder)
                        self.printEcho('parentFolder : {}'.format(parentFolder))

                        if parentFolder == '':
                            println('Folder dialog cancelled. Nothing is created.')
                            return

                        self.freeLayerMaskLastFolder = parentFolder

                        answerName = self.nukeAskSubName(answerName)

                        if answerName == '':
                            println('sub-name dialog cancelled. Nothing is created.')
                            return

                        if answerSuffix is None:
                            answerSuffix = bigKInfo.currentCompIniSuffix()

                        answerSuffix, readyToCreate = QInputDialog.getText(self, 'Suffix', 'Suffix : (empty if not needed.)', QLineEdit.Normal, answerSuffix)

                        if readyToCreate == False:
                            println('Suffix dialog cancelled. Nothing is created.')
                            return

                        frameName = str(bigKInfo.currentShot()) + '_' + answerName + answerSuffix + '.%04d' + '.exr'
                        verFolder = 'v' + str(bigKInfo.currentThisWipVerNum()).zfill(4) + '_' + inType
                        targetFilePath = os.path.normpath(os.path.join(parentFolder, verFolder, answerName, frameName))
                        checkPath = os.path.normpath(os.path.join(parentFolder, verFolder, answerName))
                        backdropLabel = answerName + '_' + inType

                    elif inType == 'PreRend':
                        # *** unknow bug, this elif section need to keep. If this section deleted, the 'Prerend' section will sytax error. To Be Fix.
                        self.printEcho(inType)
                        canRetry = True

                        answerName = self.nukeAskSubName(answerName)

                        if answerName == '':
                            println('sub-name dialog cancelled. Nothing is created.')
                            return

                        frameName = str(bigKInfo.currentShot()) + '_' + answerName + '.%04d' + '.exr'
                        verFolder = 'v' + str(bigKInfo.currentThisWipVerNum()).zfill(4)
                        targetFilePath = os.path.normpath(os.path.join(str(bigKInfo.currentTaskPath()), 'prerend', verFolder, answerName, frameName))
                        checkPath = os.path.normpath(os.path.join(str(bigKInfo.currentTaskPath()), 'prerend', verFolder, answerName))
                        backdropLabel = answerName + '_' + inType
                        # *** unknow bug, this elif section need to keep. If this section deleted, the 'Prerend' section will sytax error. To Be Fix.

                    elif inType == 'Prerend':
                        self.printEcho(inType)
                        canRetry = False

                        answerName = args[0]
                        self.printEcho('3 self.prerendKeyword is {}'.format(answerName))

                        if answerSuffix is None:
                            answerSuffix = bigKInfo.currentCompIniSuffix()

                        answerSuffix, readyToCreate = QInputDialog.getText(self, 'Suffix', 'Suffix : (empty if not needed.)', QLineEdit.Normal, answerSuffix)

                        if readyToCreate == False:
                            println('Suffix dialog cancelled. Nothing is created.')
                            return

                        frameName = str(bigKInfo.currentShot()) + '_' + answerName + answerSuffix + '.%04d' + '.exr'
                        verFolder = 'v' + str(bigKInfo.currentThisWipVerNum()).zfill(4)
                        targetFilePath = os.path.normpath(os.path.join(str(bigKInfo.currentTaskPath()), 'prerend', verFolder, answerName, frameName))
                        checkPath = os.path.normpath(os.path.join(str(bigKInfo.currentTaskPath()), 'prerend', verFolder, answerName))
                        backdropLabel = answerName + '_' + inType



                    self.printEcho('checkPath is : ' + checkPath)
                    checkPath = str(checkPath + os.sep)
                    self.printEcho('checkPath is : ' + checkPath)

                    # nukeCheckKnobContentUnique raises its own message box naming the clashing
                    # nodes, so the retry loop needs no extra dialog of its own.
                    passToken = self.nukeCheckKnobContentUnique('Write', 'file', checkPath)

                    if passToken == False and canRetry == False:
                        println('Not Unique Path, and < ' + inType + ' > builds its path with nothing to ask again. Nothing is created.')
                        return

                #newCreatedNodeMetadata = self.nukeBornBigKNode('bigK', 'ModifyMetaData')
                newCreatedNodeMetadata = self.nukeBornMetadataNode()
                newCreatedNode = self.nukeBornBigKNode('bigK' +  '_' + answerName, 'Write')
                newCreatedNode.setInput(0, newCreatedNodeMetadata)
                newCreatedNode.knob('channels').setValue('rgba')

                #targetFilePath = os.path.join(str(bigKInfo.currentTaskPath()), 'output', str(bigKInfo.currentThisWipVerNum(), (str(bigKInfo.currentShot()) + '.%04d' + '.exr')))
                targetFilePath = targetFilePath.replace(os.sep, '/')
                newCreatedNode.knob('file').setValue(targetFilePath)
                newCreatedNode.knob('create_directories').setValue(True)
                newCreatedNode.knob('metadata').setValue('all metadata')
                newCreatedNode.knob('noprefix').setValue(True)

                # The format knobs, and the tail of the path the <file> knob was just given.
                # Its own warnings name the node and the knob, and a node it refuses to touch is
                # left as the .exr sequence the branches above built, so nothing is checked here.
                self.compWriteNodePresetApply(newCreatedNode, presetKnobValuePairs)

                # Stamp the type on the node itself. The node name only carries answerName,
                # which is the sub-name for LayerMask and Prerend, so the name cannot tell
                # nukeUpdateWriteNodeVer what kind of Write node this is.
                newCreatedNode.addKnob(nuke.Text_Knob(bigKWriteTypeKnobName, 'bigK Write Type', inType))

                # addKnob creates the "User" tab and Nuke brings it to the front of the
                # already open properties panel. Close and reopen so it lands on Write.
                newCreatedNode.hideControlPanel()
                newCreatedNode.showControlPanel()

                allNewNodes = [orignalSelNode, newCreatedNodeMetadata, newCreatedNode]
                self.printEcho(newCreatedNodeMetadata)
                self.printEcho('***')
                self.printEcho(newCreatedNode)
                self.printEcho('*************allNewNodes : ***************************')
                self.printEcho(allNewNodes)

                for i in allNewNodes:
                    i.setSelected(True)

                newBD = self.nukeBornBackdrop(allNewNodes, backdropLabel, inType, 'BackdropNode')

                self.printEcho('original After:::')

                # setSelected to let user move the position of the created nodes
                for i in allNewNodes:
                    i.setSelected(True)
                newBD.setSelected(True)

                #orignalSelNode.setSelected(False)

                return newCreatedNode


    def nukeBornBackdrop(self, inNodes, inLabelText, inTypeForColor, inPrefix):
        println('\ndef >>>>> nukeBornBackdrop')



        #allNode = nuke.selectedNode()
        #labelText = 'write\nLayerMask'

        allNode = inNodes
        labelText = 'write' + '\n' + inLabelText

        marginHeight = 100
        marginWidth = 100
        yLabelSpace = 25
        rightOffSetSpace = 20
        #labelFontSize = 20
        noteFontSize = 20
        zOrder = 0

        allExistBackdrops = nuke.allNodes(filter='BackdropNode')
        allExistBackdropsNames = []

        for existBackdrop in allExistBackdrops:
            allExistBackdropsNames.append(existBackdrop.knob('name').value())


        existedSameBackdropNameCounter = 0

        '''
        for existBackdrop in allExistBackdrops:
            self.printEcho(existBackdrop.knob('name').value())
            self.printEcho(type(existBackdrop.knob('name').value()))
            if existBackdrop.knob('name').value().startswith('bigK_FreezedScnUpdt'):
                existedSameBackdropNameCounter +=1
            self.printEcho(existedSameBackdropNameCounter)

        if existedSameBackdropNameCounter < 1:
            existedSameBackdropNameCounter = ''
        else:
            existedSameBackdropNameCounter += 1
        '''
        newPrefix = inPrefix + ''
        #duplicateBackdropExistToken = True

        self.printEcho('start of while loop')
        loopcounter = 0
        self.printEcho('1 ' + newPrefix)
        self.printEcho(allExistBackdropsNames)
        self.printEcho('2 ' + newPrefix)
        #while newPrefix in allExistBackdropsNames and loopcounter < 20:
        while newPrefix in allExistBackdropsNames and loopcounter < len(allExistBackdropsNames):
            existedSameBackdropNameCounter += 1
            newPrefix = inPrefix + str(existedSameBackdropNameCounter)
            loopcounter += 1
            self.printEcho(loopcounter)
            self.printEcho(existedSameBackdropNameCounter)
            self.printEcho('3' + newPrefix)

        self.printEcho('end of while loop')


        if inTypeForColor == 'CompMaster':
            baseColor = 2419101951
        elif inTypeForColor == 'CompMasterToV':
            baseColor = 2319101951
        elif inTypeForColor == 'LayerMask':
            baseColor = 2068476415
        elif inTypeForColor == 'FreeLayerMask':
            baseColor = 3292363519
        elif inTypeForColor == 'PreRend':
            baseColor = 2060476415
        elif inTypeForColor == 'Prerend':
            baseColor = 2060476415
        elif inTypeForColor == lightQCType:
            baseColor = 2320101951
            marginHeight = 38
            marginWidth = 90
            zOrder = -10
            labelText = inLabelText
        elif inTypeForColor == 'FreezedScnUpdt':
            baseColor = 16776960
            marginHeight = 50
            marginWidth = 90
            #zOrder = -5
            yLabelSpace = 30
            labelText = inLabelText
            #labelFontSize = 5
            noteFontColor = 3221488895
            noteFontSize = 15

        allNode = nuke.selectedNode()
        self.printEcho('nodes :' + str(len(allNode)))




        xpMax = allNode.xpos()
        xpMin = allNode.xpos()
        ypMax = allNode.ypos()
        ypMin = allNode.ypos()


        for a in nuke.selectedNodes():
            if a.xpos() > xpMax:
                xpMax = a.xpos()
            if a.xpos() < xpMin:
                xpMin = a.xpos()
            if a.ypos() > ypMax:
                ypMax = a.ypos()
            if a.ypos() < ypMin:
                ypMin = a.ypos()

            #marginHeight = 200
        '''
        bd = nuke.nodes.BackdropNode(bdwidth=(xpMax-xpMin)+marginWidth , bdheight=(ypMax-ypMin)+ marginHeight + yLabelSpace )
        bd.setXpos(int(xpMin-marginWidth/2 + rightOffSetSpace * 1.8))
        bd.setYpos(int(ypMin-marginHeight/2 - yLabelSpace))

        bd.knob('tile_color').setValue(baseColor)
        bd.knob('label').setValue(labelText)
        bd.knob('note_font_size').setValue(noteFontSize)
        bd.knob('name').setValue(inPrefix)
        bd.knob('z_order').setValue(zOrder)

        if inTypeForColor == 'FreezedSceneUpdate':
            bd.knob('note_font_color').setValue(noteFontColor)
        '''


        bd = nukescripts.autoBackdrop()

        bd.setXpos(int(xpMin-marginWidth/2 + rightOffSetSpace * 1.8))
        bd.setYpos(int(ypMin-marginHeight/2 - yLabelSpace))

        bd.knob('tile_color').setValue(baseColor)
        bd.knob('label').setValue(labelText)
        bd.knob('note_font_size').setValue(noteFontSize)
        bd.knob('name').setValue('{}'.format(newPrefix))
        bd.knob('z_order').setValue(zOrder)

        if inTypeForColor == 'FreezedScnUpdt':
            bd.knob('note_font_color').setValue(noteFontColor)


        return bd



    def nukeBornMetadataNode(self):
        println('\ndef >>>>> nukeBornMetadataNode')

        newCreatedNodeMetadata = self.nukeBornBigKNode('bigK', 'ModifyMetaData')

        fpsFromProjectSetting = nuke.Root().knob('fps').value()
        filenameWhenSave = os.path.basename(nuke.root().name())

        #newdata = "{set FramesPerSecond 2323}"
        newdata = "{set bigkframepersecond " + str(fpsFromProjectSetting) + "}" + '\n' + "{set bigk_nukeScript_From " + str(filenameWhenSave) + "}"
        newCreatedNodeMetadata['metadata'].fromScript(newdata)

        return newCreatedNodeMetadata


    def nukeUpdateMetadataNodeFps(self):
        println('\ndef >>>>> nukeUpdateMetadataNodeFps')
        allNodes = nuke.allNodes(filter='ModifyMetaData')
        fpsFromProjectSetting = nuke.Root().knob('fps').value()
        filenameWhenSave = os.path.basename(nuke.root().name())

        for i in allNodes:
            if 'bigK_' in i.name():
                self.printEcho(i.name())

                newdata = "{set bigkframepersecond " + str(fpsFromProjectSetting) + "}" + '\n' + "{set bigk_nukeScript_From " + str(filenameWhenSave) + "}"
                i['metadata'].fromScript(newdata)



    def lightQCBornBackdrop(self):
        println('\ndef >>>>> lightQCBornBackdrop')

        isAlreadyExist = False

        allNodes = nuke.allNodes(filter='BackdropNode')
        for checkNode in allNodes:
            self.printEcho(checkNode['name'].value())

            if checkNode['name'].value() == lightQCBackdropName:
                isAlreadyExist = True

        if not isAlreadyExist:

            allSelNodesName = []

            allNodes = nuke.selectedNodes()
            for node in allNodes:
                allSelNodesName.append(node['name'].value())

            self.printEcho(allSelNodesName)

            backdropLabel = lightQCBackdropName
            inType = lightQCType
            Prefix = lightQCBackdropName

            self.nukeBornBackdrop(allSelNodesName, backdropLabel, inType, Prefix)

        else:

            dupMessage = '\n\nBackdrop Node Name <{}> is already existed\n\n'.format(lightQCBackdropName)
            QMessageBox.information(self, 'message', dupMessage)


    def lightQCCopyAction(self):
        println('\ndef >>>>> lightQCCopyAction')

        def findSeqBaseName(inReadNodeFilePath):
            #println('\ndef >>>>> findSeqBaseName')
            thePath = pathlib.Path(inReadNodeFilePath)
            #println('inReadNodeFilePath : {}'.format(thePath))

            numPadPhase = thePath.stem.split('.')[-1]
            if numPadPhase.startswith('%') or numPadPhase.isnumeric():
                seqBaseName = str(thePath.stem).rstrip('.'+ numPadPhase)
            else:
                seqBaseName = thePath.stem
            #println(seqBaseName)
            #println('def findSeqBaseName <<<<<')
            return seqBaseName

        targetBackdrop = nuke.toNode(lightQCBackdropName)

        # Scripts made before the LightQC rename carry a bigK_lightPublish backdrop, which this
        # no longer finds. The old backdrop is not converted -- the artist rebuilds it.
        if targetBackdrop is None:
            QMessageBox.warning(self, 'Ooops!', '\n\nBackdrop <{}> is not found.\n\nIf this script still carries an old <bigK_lightPublish> backdrop, delete it and re-build with the current LightQC Backdrop button.\n\n'.format(lightQCBackdropName))
            return

        nodesInBackdrop = targetBackdrop.getNodes()



        self.printEcho(nodesInBackdrop)

        copySourcePaths = []
        for node in nodesInBackdrop:
            self.printEcho('node class : {}'.format(node.Class()))
            if 'file' in node.knobs() and node.Class() != 'Viewer':
                self.printEcho(node['file'].value())
                copySourcePaths.append(node['file'].value())

        self.versionUpSaveWIP(False)

        bigKInfo = bigKeeperInfoGlobal_published.bigKeepCLASS()
        currentVerNumber = bigKInfo.currentThisWipVerNum()
        currentTaskPath = bigKInfo.currentTaskPath()

        self.printEcho(currentVerNumber)


        QApplication.processEvents()

        msgBox = QMessageBox()
        msgBox.setStandardButtons(QMessageBox.NoButton)
        msgBox.show()

        totalPaths = len(copySourcePaths)
        counter = 0

        start_time = time.time()

        for sourcePath in copySourcePaths:
            self.printEcho('\n\n\n\n\n************************************************\n***\n***\n***\n***\n***\n***\n***\n***        START        \n***\n***\n***\n***\n***\n***\n***\n************************************************\n\n\n\n')
            sourceReadNodeFilePath = pathlib.Path(sourcePath)
            self.printEcho(sourceReadNodeFilePath)
            self.printEcho(sourceReadNodeFilePath.parent)


            '''
            numPadPhase = str(sourceReadNodeFilePath.stem).split('.')[-1]
            if numPadPhase.startswith('%') or numPadPhase.isnumeric():
                sourceSeqBaseName = str(sourceReadNodeFilePath.stem).rstrip('.'+ numPadPhase)
            else:
                sourceSeqBaseName = sourceReadNodeFilePath.stem
            '''
            sourceSeqBaseName = findSeqBaseName(sourceReadNodeFilePath)
            self.printEcho('\n\nsourceSeqBaseName : {}\n\n'.format(sourceSeqBaseName))

            #find original version path to be copied to
            originalVerNumber = os.path.normpath(sourcePath).split(os.path.sep)[12]
            self.printEcho(originalVerNumber)

            #println(os.path.join(currentTaskPath, lightQCPublishFolderName, (str(currentVerNumber).zfill(4)), os.path.basename(sourceReadNodeFilePath.parent)))
            destinationVerPath = os.path.join(currentTaskPath, lightQCPublishFolderName, (str(originalVerNumber).zfill(4)), os.path.basename(sourceReadNodeFilePath.parent))


            listFiles = os.listdir(sourceReadNodeFilePath.parent)


            #for copy to under according to LightQC .nk ver Number
            targetFiles = []

            for file in listFiles:
                jointFilePath = os.path.join(sourceReadNodeFilePath.parent, file)
                if not os.path.isdir(jointFilePath):
                    libPath = pathlib.Path(jointFilePath)
                    #if libPath.stem.startswith(sourceSeqBaseName):
                    #println(sourceSeqBaseName)
                    #println('vs')
                    #println(findSeqBaseName(jointFilePath))
                    if findSeqBaseName(jointFilePath) == sourceSeqBaseName:
                        targetFiles.append(libPath)
                        self.printEcho('                                      append >>> {}\n'.format(libPath))
                    else:
                        self.printEcho('                                                            Skipped. --- seqBasename not match.\n')
                        pass
                else:
                    self.printEcho('                                                            Skipped. --- It is a folder\n')
                    pass

            self.printEcho('targetFiles :')
            for line in targetFiles:
                self.printEcho(line)


            self.printEcho('>>> start {}'.format(destinationVerPath))
            if not os.path.isdir(destinationVerPath):
                os.makedirs(destinationVerPath)

            counter += 1
            for copyFile in targetFiles:

                # compare if the existing file are the same SIZE and SAME MODIFIED TIME
                assumeExistFile = os.path.join(destinationVerPath, os.path.basename(copyFile))
                if os.path.isfile(assumeExistFile):
                    if self.comparefileSizeModifytime(copyFile, assumeExistFile) == 'same':
                        self.printEcho('existFile with same SIZE and ModifyTIME, skipped copy.')
                else:
                    msgBox.setText('Publishing < {} of {} >:\n\n <......\{}\{}>\n\n{}'.format(counter, totalPaths, os.path.basename(sourceReadNodeFilePath.parent.parent), os.path.basename(sourceReadNodeFilePath.parent), copyFile))
                    QApplication.processEvents()
                    #destinationPath = shutil.copytree(sourceReadNodeFilePath.parent, destinationVerPath)
                    self.printEcho('destinationVerPath : {}'.format(destinationVerPath))
                    destinationPath = shutil.copy2(copyFile, destinationVerPath)
                    QApplication.processEvents()

                self.printEcho('<<< publish-copy of this layer is done. {}'.format(destinationVerPath))


        QApplication.processEvents()

        end_time = time.time()
        QMessageBox.information(self, 'message', '< {} of {} > Publish-Copy done. ({} seconds)'.format(counter, totalPaths, round (end_time - start_time, 2)))
        msgBox.close()


    def comparefileSizeModifytime(self, inFile1, inFile2):
        stat1 = os.stat(inFile1)
        stat2 = os.stat(inFile2)

        # Compare file sizes
        if stat1.st_size != stat2.st_size:
            return 'diff size'
        elif stat1.st_mtime != stat2.st_mtime:
            return 'diff mtime'
        else:
            return 'same'


    def openCacheFolder(self):
        println('\ndef >>>>> openCacheFolder')
        os.startfile(os.path.join(self.selProjScnShotTaskPath, self.selTask, 'cache'))


    def openOutputFolder(self):
        println('\ndef >>>>> openOutputFolder')
        os.startfile(os.path.join(self.selProjScnShotTaskPath, self.selTask, 'output'))


    def fileKnobFreeze(self):
        println('\ndef >>>>> fileKnobFreeze')

        allSelNodes = nuke.selectedNodes()
        allSelNodesName = []

        for node in allSelNodes:
            allSelNodesName.append(node['name'].value())

            #lock all the knob('file')
            node.knob('file').setEnabled(False)
            node.knob('note_font_color').setValue(3221488895)
            if node.knob('label').value() == '':
                node.knob('label').setValue('\n{}'.format('bigK_FreezedScnUpdt'))
            else:
                node.knob('label').setValue('{}\n\n{}'.format(node.knob('label').value(), 'bigK_FreezedScnUpdt'))


        #Then, create backdrop to visually show to user
        self.printEcho(allSelNodesName)
        backdropLabel= 'bigK_FreezedScnUpdt'
        inType = 'FreezedScnUpdt'
        Prefix = 'bigK_FreezedScnUpdt'
        self.nukeBornBackdrop(allSelNodesName, backdropLabel, inType, Prefix)


    def fileKnobUnFreeze(self):
        println('\ndef >>>>> fileKnobUnFreeze')

        allSelNodes = nuke.selectedNodes()
        allSelBackdrops = nuke.selectedNodes(filter = 'BackdropNode')

        if len(allSelBackdrops) > 0:

            for node in allSelNodes:
                self.printEcho("node.knob('name').value()")
                self.printEcho(node.knob('name').value())
                self.printEcho('node')
                self.printEcho(node)
                self.printEcho("type(node)")
                self.printEcho(type(node))
                if 'file' in node.knobs():
                    #println("node.knob(file).Enabled():")
                    #println(node.knob('file').enabled())
                    self.printEcho('knob "FILE" exist')
                    node.knob('file').setEnabled(True)
                    node.knob('note_font_color').setValue(0)

                    #remove bigK_FreezedScnUpdt from label
                    newLabel = node.knob('label').value().replace('bigK_FreezedScnUpdt', '')
                    node.knob('label').setValue(newLabel.rstrip())

                else:
                    self.printEcho('knob "FILE" not exsit')

            for backdrop in allSelBackdrops:
                nuke.delete(backdrop)
        else:
            QMessageBox.information(self, 'No Backdrop is selected.', 'No Backdrop is selected.')


    def nukeFileKnobFreezeScriptLoad(self):
        println('\ndef >>>>> nukeFileKnobFreezeScriptLoad')

        allNodes = nuke.allNodes()

        self.printEcho(allNodes)

        for node in allNodes:
            self.printEcho(node.knob('name').value())
            if 'file' in node.knobs():
                self.printEcho('have FILE knob')
                self.printEcho('label value :{}'.format(node.knob('label').value()))
                if 'bigK_FreezedScnUpdt' in node.knob('label').value():
                    node.knob('file').setEnabled(False)
                    node.knob('note_font_color').setValue(0)
            else:
                self.printEcho('have NOT FILE knob xxxxx')

        println('\ndef >>>>> nukeFileKnobFreezeScriptLoad <<<<<')



    def genCgRenderBackdrop(self):
        println('\ndef >>>>> genCgRenderBackdrop')


    def genOtherBackdrop(self):
        println('\ndef >>>>> genOtherBackdrop')






    def nukeUpdateWriteNodeVer(self):
        println('\ndef >>>>> nukeUpdateWriteNodeVer')
        println('3189')
        # This function is intentionally read and update the path data according to the current content, instead of using bigkeeperinfo toolkit. To avoid unwanted overwrite data.

        # check if it is in Nuke Assist
        nukeEnv = nuke.env
        isAssist = nukeEnv['assist']

        '''
        if isAssist:
            theMessage = 'Warning !!!\n\n' + 'Currently in < Nuke Assist >.\n\n' + 'Therefore <Write Nodes> are not updated to align output version number.\n'+ '- Do not render this nuke script verion.\n' + '- < Version Up > in Nuke or Nuke X, before submit render to align the write node version number.'
            QMessageBox.information(self, 'WARNING !!! ', theMessage)'''


        bigKInfo = bigKeeperInfoGlobal_published.bigKeepCLASS()
        currentVerNumber = bigKInfo.currentThisWipVerNum()
        currentTaskPath = bigKInfo.currentTaskPath()
        currentShotname = bigKInfo.currentShot()
        dedictatedPrefix = 'bigK'
        nodeClassName = 'Write'


        # Gather all the nodes in the scene
        allNodes = nuke.allNodes()
        self.printEcho(allNodes)
        self.printEcho(len(allNodes))
        self.printEcho(type(allNodes))
        sameNodeNameList = []

        # sort out only (bigK + targetClassName)nodes, filter by .name()
        allFilteredNodes = []

        for i in allNodes:

            '''
            # to sort out Disabled Write node. For Freeze the version update status.
            if i.Class() == 'Write' and i.knob('disable').getValue() == True:
                pass

            else:
                mergePrefix = dedictatedPrefix + '_' + nodeClassName + '_'
                if i.name()[0:len(mergePrefix)] == mergePrefix:
                    sameNodeNameList.append(i.name())
                    #create a list containing "node" instead of nodeName, for coding convinient
                    allFilteredNodes.append(nuke.toNode(i.name()))
            '''

            # Cancel the above procedure of sorting out Disable Write Node. After discuss with Apple and Lik.
            mergePrefix = dedictatedPrefix + '_' + nodeClassName + '_'
            #if i.name()[0:len(mergePrefix)] == dedictatedPrefix:

            if i.name()[0:len(dedictatedPrefix)] == dedictatedPrefix and i.Class() == 'Write':
                sameNodeNameList.append(i.name())
                #create a list containing "node" instead of nodeName, for coding convinient
                allFilteredNodes.append(nuke.toNode(i.name()))

        self.printEcho(allFilteredNodes)

        '''
        # To avoid, in case, previous version is copy and paste from window explorer.
        try:
            seperator = '/output/v'
        except:
            seperator = '\output\v'
        '''

        seperatorKeywords = ['output', 'prerend']

        # The version folder of a FreeLayerMask node is v0007_FreeLayerMask, and its parent
        # folder is whatever the user picked. So the four version digits are found by looking
        # backwards from this word, never by rebuilding the path.
        freeLayerMaskFolderTail = '_' + freeLayerMaskType
        unUpdatedFreeLayerMaskNodes = []

        for i in allFilteredNodes:

            self.printEcho(f"i.knob('file').value() : {i.knob('file').value()}")
            originalContent = os.path.normpath(i.knob('file').value())


            self.printEcho('originalContent :')
            self.printEcho(originalContent)

            writeTypeKnob = i.knob(bigKWriteTypeKnobName)

            if writeTypeKnob is not None and writeTypeKnob.value() == freeLayerMaskType:
                self.printEcho(f'{freeLayerMaskType} Node Found. -- {i.name()}')

                # tokenIndex points at the underscore of _FreeLayerMask.
                # tokenIndex - 5 is the 'v', tokenIndex - 4 to tokenIndex - 1 are the digits.
                tokenIndex = originalContent.rfind(freeLayerMaskFolderTail)
                self.printEcho(f'tokenIndex : {tokenIndex}')

                if tokenIndex < 5 or originalContent[tokenIndex - 5] != 'v' or not originalContent[tokenIndex - 4 : tokenIndex].isdigit():
                    println(f'{i.name()} : version folder pattern v####{freeLayerMaskFolderTail} not found. Left untouched.')
                    unUpdatedFreeLayerMaskNodes.append(i.name())
                    continue

                updatedContent = originalContent[0 : tokenIndex - 4] + str(currentVerNumber).zfill(4) + originalContent[tokenIndex : ]
                updatedContent = updatedContent.replace(os.sep, '/')

            elif r'\vDrive' in originalContent:
                seperator = r'\vDrive'
                self.printEcho(f'vDrive Node Found. -- {seperator}')

                basename = os.path.basename(originalContent)
                self.printEcho(f'basename : {basename}')
                basenameFull = basename.split('.')
                self.printEcho(f'basenameFull : {basenameFull}')
                basenameFullShotName = basenameFull[0].split('_')
                self.printEcho(f'basenameFullShotName : {basenameFullShotName}')

                splitContent = originalContent.split(seperator)
                self.printEcho(f'splitContent : {splitContent}')

                splitContentEnd = splitContent[-1]
                self.printEcho(f'splitContentEnd : {splitContentEnd}')
                splitContentEnd = splitContentEnd.replace(basenameFullShotName[0], currentShotname)
                self.printEcho(f'splitContentEnd : {splitContentEnd}')

                vDriveFolder = self.vDrivePathRead(os.path.join(bigKInfo.currentProjWorkPath(), 'bigPathsProject.ini'), 'BIGPATHS', 'vOutput')
                self.printEcho(f'vDriveFolder : {vDriveFolder}')

                updatedContent = str(os.path.normpath(vDriveFolder + splitContentEnd))
                updatedContent = updatedContent.replace(os.sep, '/')

            else:

                for keyword in seperatorKeywords:
                    self.printEcho(r'\{}\v'.format(keyword))
                    if r'\{}\v'.format(keyword) in originalContent:
                        seperator = r'\{}\v'.format(keyword)
                        self.printEcho(seperator)

                #To find out current frame name for both CompMaster(tsq0010) & LayerMask(tsq0010_shadow), store in basenameFullShotName[0]
                basename = os.path.basename(originalContent)
                self.printEcho(f'basename : {basename}')
                basenameFull = basename.split('.')
                self.printEcho(f'basenameFull : {basenameFull}')
                basenameFullShotName = basenameFull[0].split('_')
                self.printEcho(f'basenameFullShotName : {basenameFullShotName}')

                splitContent = originalContent.split(seperator)
                self.printEcho(f'splitContent : {splitContent}')
                splitContentFront = splitContent[0]
                splitVerNumber = splitContent[1][0:4]
                splitContentEnd = splitContent[1][4::]

                self.printEcho('splitContentEnd is :')
                self.printEcho(splitContentEnd)
                splitContentEnd = splitContentEnd.replace(basenameFullShotName[0], currentShotname)

                newVerNumber = currentVerNumber
                updatedContent = str(os.path.normpath(currentTaskPath + seperator + str(newVerNumber).zfill(4) + splitContentEnd))
                updatedContent = updatedContent.replace(os.sep, '/')

            self.printEcho('updatedContent :')
            self.printEcho(updatedContent)

            if i.knob('file').enabled():
                self.printEcho("{}'s <file> knob is not locked.".format(i.knob('name').value()))
                i.knob('file').setValue(updatedContent)
            else:
                self.printEcho("{}'s <file> knob is locked.".format(i.knob('name').value()))

        if len(unUpdatedFreeLayerMaskNodes) > 0:
            theMessage = 'WARNING !!!\n\n' + 'These < ' + freeLayerMaskType + ' > Write nodes were NOT version updated :\n\n     ' + '\n     '.join(unUpdatedFreeLayerMaskNodes) + '\n\nTheir file path no longer carries the < v####' + freeLayerMaskFolderTail + ' > folder.\nFix the path by hand, or re-generate the node.'
            QMessageBox.information(self, 'WARNING !!! ', theMessage)

        println('3326')

    def cleanUpCompOutput(self, inScns):
        println('\ndef >>>>> cleanUpCompOutput')

        import datetime
        totalSortoutCompSizeGB = 0


        # Ask user to include upstream images or not
        includeAskitems = ("Yes","No")
        isIncludeRenderSource, includeOkPressed = QInputDialog.getItem(self, "Include Updream :","Include Upstream asset, such as Footage, CG Render Images, Deep Images?", includeAskitems, 0, False)


        # ref : https://pythonspot.com/pyqt5-input-dialog/
        keepVers, VersOkPressed = QInputDialog.getInt(self, 'Input :', 'How many Latest VERSIONS to be kept and protected?', 10, 1, 10000, 1)
        if VersOkPressed:
            self.printEcho('keepVers inputed : %d' %keepVers)


            keepDays, DaysOkPressed = QInputDialog.getInt(self, 'Input :', 'How many Latest DAYS to be kept and protected?', 30, 0, 10000, 1)
            if DaysOkPressed:
                self.printEcho('keepDays inputed : %d' %keepDays)

                showAskPath = True
                for selectedScn in inScns:

                    timerStart = datetime.datetime.now()

                    # Calculate boundary data (currentTime - KeepDays)
                    currentTimeStamp = datetime.datetime.now().timestamp()
                    currentTimeStamp_YYYYmmddHHMMSS = datetime.datetime.fromtimestamp(currentTimeStamp).strftime('%Y-%m-%d %H:%M:%S')
                    self.printEcho(currentTimeStamp_YYYYmmddHHMMSS)
                    value_currentTimeStamp_YYYYmmddHHMMSS = datetime.datetime.strptime(currentTimeStamp_YYYYmmddHHMMSS , '%Y-%m-%d %H:%M:%S')
                    DayValue = datetime.timedelta(days=keepDays)
                    boundryDate = value_currentTimeStamp_YYYYmmddHHMMSS - DayValue
                    self.printEcho('boundryDate is : ')
                    self.printEcho(boundryDate)
                    saveNameCurrentTimeStamp = 'toBeDel_' + selectedScn.text() + '_' + datetime.datetime.fromtimestamp(currentTimeStamp).strftime('-D%Y-%m-%d_T%H%M%S')

                    if showAskPath:
                        saveFullPath = None
                        println(os.path.join(self.selProjRootPath,saveNameCurrentTimeStamp))
                        saveFullPath = self.askSaveFile(os.path.join(self.selProjRootPath,saveNameCurrentTimeStamp))
                        saveDirPath = os.path.dirname(saveFullPath)
                    else:
                        saveFullPath = os.path.join(saveDirPath, saveNameCurrentTimeStamp + '.txt')

                    if saveFullPath != None:

                        sourceCheckPath = os.path.join(self.selProjScnPath, selectedScn.text())
                        self.printEcho('<><><><><>')
                        self.printEcho(selectedScn.text())
                        self.printEcho(sourceCheckPath)
                        self.printEcho('<><><><><>')

                        toBeDelList, toBeKeepList = self.cleanUpSortOutDelVers(sourceCheckPath, keepVers, keepDays)



                        self.printEcho('\ntoBeDelList is :')
                        for i in toBeDelList:
                            self.printEcho(i)

                        self.printEcho('\ntoBeKeepList is :')
                        for i in toBeKeepList:
                            self.printEcho(i)

                        if isIncludeRenderSource == 'Yes':
                            toBeDelPlusRenderSourceList, toBeKeepPlusRenderSourceList = self.TraceRenderOutputFromKeepVersPath(toBeKeepList)

                            toBeKeepList.extend(toBeKeepPlusRenderSourceList)
                            toBeKeepList = list(set(toBeKeepList))
                            toBeKeepList.sort()

                            toBeDelList.extend(toBeDelPlusRenderSourceList)
                            toBeDelList = list(set(toBeDelList))
                            toBeDelList.sort()

                            for pathForSaftyCheck in toBeDelList:
                                if pathForSaftyCheck in toBeKeepList:
                                    toBeDelList.remove(pathForSaftyCheck)


                        self.printEcho('\ntoBeDelList + toBeDelPlusRenderSourceList is :')
                        for i in toBeDelList:
                            self.printEcho(i)


                        totalSize = 0

                        print()



                        msgBox = QMessageBox()
                        msgBox.setStandardButtons(QMessageBox.NoButton)
                        msgBox.show()

                        QApplication.processEvents()
                        for i in toBeDelList:
                            self.printEcho(i)
                            size = self.cleanUpCheckFolderSize(i)
                            self.printEcho('Path : ' + i + '     Size in MB : ' + str(size/1024/1024))
                            totalSize += size
                            QApplication.processEvents()
                            #msgBox.setText(os.path.normpath(i))
                            msg = 'Path : ' + str(i) + '     Size in MB : ' + str(size/1024/1024)
                            msgBox.setText(msg)

                        print()
                        '''println('toBeDelList is :')
                        println(toBeDelList)
                        for i in toBeDelList:
                            println(i)
                        '''

                        print()
                        self.printEcho('Keeping %d Latest Vers ---OR--- verions within %d Latest Days (%s)' %(keepVers, keepDays, str(boundryDate)))
                        self.printEcho('totalSize is :')
                        self.printEcho('totalSize in MB (to be deleted) : ' + str(totalSize/1024/1024))
                        self.printEcho('totalSize in GB (to be deleted) : ' + str(totalSize/1024/1024/1024))
                        totalSortoutCompSizeGB  += totalSize/1024/1024/1024
                        timerEnd = datetime.datetime.now()
                        self.printEcho(timerEnd - timerStart)

                        headerContentList = []
                        headerContentList.append(str('Keeping %d Latest Vers ---OR--- verions within %d Latest Days (%s)' %(keepVers, keepDays, str(boundryDate))))
                        headerContentList.append(str('totalSize in MB (to be deleted): ' + str(totalSize/1024/1024)))
                        headerContentList.append(str('totalSize in GB (to be deleted): ' + str(totalSize/1024/1024/1024)))

                        #writePath = os.path.normpath(r'D:\\')
                        self.cleanUpWriteToText(saveFullPath, headerContentList, toBeDelList, toBeKeepList)

                        showAskPath = False

                        totalSizeLogFilePath = os.path.join(saveDirPath, 'sizeLog.txt')
                        f = open(totalSizeLogFilePath, 'w')
                        f.write(str(totalSortoutCompSizeGB) + ' GB')
                        f.close()




        println('\n\n')
        println(f'****************************************')
        println(f'**  Total sortout size (GB): {totalSortoutCompSizeGB}')
        println(f'****************************************')
        println('\n\n')





    def checkVerFolderFormat(self, inName):
        println('\ndef >>>>> checkVerFolderFormat')

        valid = None
        if inName[0] == 'v':
            for i in range(1, 5):
                if inName[i].isnumeric():
                    #println(inName[i])
                    valid = True
                else:
                    valid = False
                    break

        if valid:
            return True
        else:
            return False


    def cleanUpSortOutDelVers(self, inPathRoot, inKeepVers, inKeepDays):
        println('\ndef >>>>> cleanUpSortOutDelVers')

        keepVers = inKeepVers
        keepDays = inKeepDays

        delVersPath = []
        keepVersPath = []

        msgBox = QMessageBox()
        msgBox.setStandardButtons(QMessageBox.NoButton)
        msgBox.show()

        self.printEcho('**********')
        self.printEcho(inPathRoot)
        self.printEcho('**********')

        # for loop of each SHOT
        #for i in self.listShot:
        for i  in os.listdir(inPathRoot):
            thePath = os.path.join(inPathRoot, i)
            self.printEcho(thePath)


            theCompOutputPath = os.path.join(thePath, 'components', 'comp', 'output')
            self.printEcho(theCompOutputPath)

            if os.path.isdir(theCompOutputPath):
                tempDirs = os.listdir(theCompOutputPath)
                self.printEcho('tempDirs is : {} {}'.format(len(tempDirs), tempDirs))

                folderOnlyList = []

                # for loop of each version in SHOT-Comp-Output
                for j in tempDirs:

                    if self.checkVerFolderFormat(j) and os.path.isdir(os.path.join(theCompOutputPath, j)):
                        folderOnlyList.append(j)

                    unKeepFolderList = []
                    keepFolderList = []
                    keptVerNumList = []
                    counter = 0

                    folderOnlyList.sort(reverse = True)

                    for j in folderOnlyList[::]:

                        # to identify "CompMaster" and "_LayerMask"
                        previousJ = folderOnlyList[folderOnlyList.index(j)-1]
                        self.printEcho('j in folderOnlyList : {} in {}'.format(j, folderOnlyList))
                        self.printEcho('previousJ : {}'.format(previousJ))
                        #println(f'j is {j}, index is {folderOnlyList.index(j)}, j-1 is {folderOnlyList[folderOnlyList.index(j)-1]}, j[0:5] is {j[0:5]}, previousJ is {previousJ[0:5]}')


                        ###     Capri Modified on 20230308  --- Start
                        ###     modified:   keep version based on master version
                        ###     added:  check and keep latest layer's layermask version

                        if counter < keepVers:
                            if j[0:5] != previousJ[0:5]:
                                if not j.find("_LayerMask") > 0:
                                    counter += 1
                                keptVerNumList.append(j[0:5])
                                keepFolderList.append(j)
                            else:
                                pass
                                counter += 1
                                keptVerNumList.append(j[0:5])
                                keepFolderList.append(j)
                        else:
                            if j[0:5] == previousJ[0:5] and j[0:5] in keptVerNumList:
                                continue
                            else:
                                unKeepFolderList.append(j)

                        unKeepFolderList.sort()
                        keepFolderList.sort()


                        layerMaskFolders = []

                        for compVer in folderOnlyList:
                            if compVer.endswith('_LayerMask') == True:
                                layerMaskFolders.append(compVer)

                        layerMaskLayer = []

                        for layerMaskVer in layerMaskFolders:
                            if layerMaskVer not in keepFolderList:
                                layerMask = os.listdir(os.path.join(theCompOutputPath, layerMaskVer))
                                for layer in layerMask:
                                    layerMaskLayer.append(layer)

                            elif layerMaskVer in keepFolderList:
                                pass

                        layerMaskLayer = list(dict.fromkeys(layerMaskLayer))

                        layerMaskFolders.sort(reverse = True)

                        for layerMask in layerMaskLayer:
                            for layerMaskVer in layerMaskFolders:
                                checkLayerMaskExists = os.path.isdir(os.path.join(theCompOutputPath, layerMaskVer, layerMask))

                                if checkLayerMaskExists == True:
                                    if layerMaskVer in unKeepFolderList:
                                        unKeepFolderList.remove(layerMaskVer)
                                        keepFolderList.insert(0, layerMaskVer)
                                    break

                        unKeepFolderList.sort()
                        keepFolderList.sort()



                        ###     Capri Modified on 20230308  --- End


                self.printEcho('folderOnlyList   : {} {}'.format(len(folderOnlyList), folderOnlyList))
                self.printEcho('keepFolderList   : {} {}'.format(len(keepFolderList), keepFolderList))
                self.printEcho('unKeepFolderList : {} {}'.format(len(unKeepFolderList), unKeepFolderList))

                for l in keepFolderList:
                    keepVersPath.append(os.path.normpath(os.path.join(theCompOutputPath, l)))

                for k in unKeepFolderList:
                    if self.isEarlierThanKeepDays(os.path.join(theCompOutputPath, k), keepDays):
                        #println('Earlier.\n')
                        delVersPath.append(os.path.normpath(os.path.join(theCompOutputPath, k)))
                    else:
                        keepVersPath.append(os.path.normpath(os.path.join(theCompOutputPath, k)))  #<------ Check it line 2880, why "l" variable not "k"?

            QApplication.processEvents()
            msgBox.setText(theCompOutputPath)


        msgBox.close()

        return delVersPath, keepVersPath


    def TraceRenderOutputFromKeepVersPath(self, inKeepList):
        println('\n\n<><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><\n\n')
        println('\ndef >>>>> TraceRenderOutputFromKeepVersPath\n\n')

        #Extract Nuke working file
        nukeNumPadDigit = 4 + 1     #("v" + 4digit)
        toBeKeepRenderOutputList = []
        toBeDelRenderOutputList = []

        def extract_wipNumber(inText):
            self.printEcho('\n   def >>>>> extract_wipNumber')
            num_str = ''
            counter = 0
            for char in inText:
                counter += 1
                if char.isdigit() and counter <= 5:
                    num_str += char
            if num_str:
                return int(num_str), 'v' + num_str
            else:
                return None


        def extractReadNodeKeepRenderImagePath(InPath):

            println('\n   def >>>>> extractReadNodeKeepRenderImagePath')

            # The original of this def is designed to input from a list of path, so now keep it as individual def.
            def extract_file_paths(script_file):
                ('\n       def >>>>> extract_file_paths')
                file_paths = []


                with open(script_file, "r") as script_file_handle:
                    lines = script_file_handle.readlines()
                    for i in range(len(lines)):
                        line = lines[i].strip()
                        if line.startswith("Read {") and line.endswith("Read {"):
                            if i + 3 < len(lines):
                                file_path = lines[i + 3].split("file ")[-1].strip("\n").strip("}")
                                file_paths.append(file_path)

                        elif line.startswith("DeepRead {") and line.endswith("DeepRead {"):
                            if i + 2 < len(lines):
                                file_path = lines[i + 2].split("file ")[-1].strip("\n").strip("}")
                                file_paths.append(file_path)


                return file_paths

            # List variable to store file paths
            all_file_paths = []

            # Extract file paths from script file
            self.printEcho(f'==={InPath}===')
            self.printEcho("Processing script:", InPath)
            file_paths = extract_file_paths(InPath)
            all_file_paths.extend(file_paths)
            self.printEcho("Script processed.")

            '''
            #Print the list of file paths
            println("All file paths extracted:")
            for i in all_file_paths:
                println(i)
            '''

            return all_file_paths


        def toBeDelRenderImagePath(inKeepPathList, inKeepPathComponent, inKeepTaskName):
            println('\n   def >>>>> toBeDelRenderImagePath')
            theKeepTaskPath = os.path.join(inKeepPathComponent, taskName)

            def findAllVerInRenderImagePath(inPath):
                self.printEcho('\n       def >>>>> findAllVerInRenderImagePath')

                theLibPath = pathlib.Path(inPath)
                self.printEcho('inPath :{}'.format(inPath))
                #println('theLibPath :{}'.format(theLibPath))
                self.printEcho('theLibPath.parents[-12] :{}'.format(theLibPath.parents[-12]))
                self.printEcho('\n')

                allVerInRenderImagePath = os.listdir(theLibPath.parents[-12])
                onlyVerFolderPath = []
                #println('allVerInRenderImagePath :')
                #println(allVerInRenderImagePath)

                for i in allVerInRenderImagePath:
                    checkPath = os.path.join(os.path.normpath(theLibPath.parents[-12]), i)
                    #println('checkPath : {}'.format(checkPath))
                    if os.path.isdir(checkPath):
                        onlyVerFolderPath.append(checkPath)

                self.printEcho('\nallVerInRenderImagePath :')
                self.printEcho(allVerInRenderImagePath)
                self.printEcho('\nreturn:')
                self.printEcho('onlyVerFolderPath :')
                self.printEcho(onlyVerFolderPath)


                return onlyVerFolderPath

            keepVersionPathList = []
            outKeepList = []
            outDelList = []
            allVersionPath = []

            # tidy up keep VERSION path list, find out all the VERSION paths
            for i in inKeepPathList:
                theKeepLibPath = pathlib.Path(i)

                self.printEcho('theKeepLibPath              :{}'.format(theKeepLibPath))

                if  len(theKeepLibPath.parents) < 13:
                    self.printEcho('No. of folders level less than pipeline structure, skipped.\n')
                    pass
                else:

                    if os.path.exists(theKeepLibPath.parents[-13]):

                        println('theKeepLibPath.parents[-13] :{}'.format(theKeepLibPath.parents[-13]))

                        if os.path.normpath(theKeepLibPath.parents[-11]) != os.path.normpath(theKeepTaskPath) :   #To exclude from same TASK. Becoz artist may readIn previous nuke render output to QC.
                            self.printEcho('theKeepTaskPath             :{}'.format(theKeepTaskPath))
                            self.printEcho('vs')
                            self.printEcho('theKeepLibPath.parents[-11] :{}'.format(theKeepLibPath.parents[-11]))
                            self.printEcho('The RenderImage Path is from Different Task, OK.\n')
                            self.printEcho('theKeepLibPath.parents[-13] :',theKeepLibPath.parents[-13])

                            if str(os.path.normpath(i)).startswith(str(inKeepPathComponent)):   #To include only within the same shot. For saftly, Exclude out of the same shot on-purpose.

                                storePaths = findAllVerInRenderImagePath(theKeepLibPath)     #allVersionPathList store at here.
                                for j in storePaths:
                                    allVersionPath.append(os.path.normpath(j))

                                if os.path.normpath(theKeepLibPath.parents[-13]) in keepVersionPathList:
                                    self.printEcho('os.path.normpath(theKeepLibPath.parents[-13])  in keepVersionPathList, skipped.\n')
                                    pass
                                else:
                                    keepVersionPathList.append(os.path.normpath(theKeepLibPath.parents[-13]))    #keepVersionPathList created here.

                            else:
                                self.printEcho('The RenderImage Path is out of the same shot, skipped.\n')
                                pass

                        else:
                            self.printEcho('The RenderImage Path is within the same Task, skipped.\n')
                            pass
                    else:
                        self.printEcho('theKeepLibPath is missing !!! {}'.format(theKeepLibPath.parents[-13]))
                        pass



            self.printEcho("\nkeepVersionPathList:")
            for i in keepVersionPathList:
                self.printEcho(i)


            self.printEcho("\nallVersionFolders:")
            for i in allVersionPath:
                self.printEcho(i)


            if allVersionPath:
                # Filter outDelList from the above 2 set of paths
                for i in allVersionPath:
                    if os.path.normpath(i) in keepVersionPathList:
                        outKeepList.append(i)
                    else:
                        outDelList.append(i)

            self.printEcho('\noutDelList:')
            for i in outDelList:
                self.printEcho(i)

            return outDelList, outKeepList





        self.printEcho('\n\ninKeepList :::')
        for i in inKeepList:
            self.printEcho(i)
        self.printEcho('\n\n\n')

        inKeepListReverseSort = inKeepList
        inKeepListReverseSort.sort(reverse = True)
        inKeepListReverseSortCounter = 0


        for i in inKeepList:
            inKeepListReverseSortCounter += 1

            #Extract shot name full path

            theLibPath = pathlib.Path(i)
            self.printEcho('theLibPath :{}'.format(theLibPath))
            pathComponent = theLibPath.parents[2]

            taskName = os.path.basename(theLibPath.parents[1])
            workFileName = pathlib.Path(theLibPath).stem
            shotName = os.path.basename(pathlib.Path(theLibPath.parents[3]))
            justVer, vWithVer = extract_wipNumber(workFileName)


            self.printEcho('pathComponent :{}'.format(pathComponent))
            self.printEcho('taskName :{}'.format(taskName))
            self.printEcho('shotName :{}'.format(shotName))
            self.printEcho('baseName :{}'.format(workFileName))
            self.printEcho('justVer :{}'.format(justVer))


            # combine to a nuke script file path
            nukeScriptWIPfileName = shotName + '_' + taskName + '_wip_' + vWithVer + '.nk'
            nukeScriptFilePath = os.path.join(pathComponent, taskName, 'wip', nukeScriptWIPfileName)
            self.printEcho('nukeScriptFilePath :{}'.format(nukeScriptFilePath))

            storeDelList = []
            storeKeepList = []



            if os.path.exists(nukeScriptFilePath) :
                self.printEcho('| | | | | .nk nuke Script exist. | | | | | :\n{}\n'.format(nukeScriptFilePath))
                storeDelList, storeKeepList = (toBeDelRenderImagePath(extractReadNodeKeepRenderImagePath(nukeScriptFilePath), pathComponent, taskName))

                self.printEcho(storeDelList)
                self.printEcho(storeKeepList)

                for j in storeKeepList:
                    self.printEcho('storeKeepList: {}'.format(j))
                    self.printEcho(j)

                    if j not in toBeKeepRenderOutputList:
                        toBeKeepRenderOutputList.append(j)

                for j in storeDelList:
                    if j not in toBeKeepRenderOutputList and j not in toBeDelRenderOutputList:
                        toBeDelRenderOutputList.append(j)

                """
                self.printEcho('toBeKeepRenderOutputList :')
                for i in toBeKeepRenderOutputList:
                    self.printEcho(i)
                self.printEcho('toBeDelRenderOutputList :')
                for i in toBeDelRenderOutputList:
                    self.printEcho(i)
                """
            elif os.path.exists(nukeScriptFilePath) == False and inKeepListReverseSortCounter > 1:
                self.printEcho('x x x x x .nk nuke Script not found. x x x x x : (not largest keepVer comp output, countinue)\n{}\n'.format(nukeScriptFilePath))
            elif os.path.exists(nukeScriptFilePath) == False and inKeepListReverseSortCounter == 1:
                self.printEcho('x x x x x .nk nuke Script not found. x x x x x : (LARGEST keepVer comp output, BREAK)\n{}\n'.format(nukeScriptFilePath))
                break



        self.printEcho('\nend of TraceRenderOutputFromKeepVersPath\n')
        self.printEcho('toBeKeepRenderOutputList :')

        '''
        for i in toBeKeepRenderOutputList:
            self.printEcho(i)
        '''
        self.printEcho('toBeDelRenderOutputList :')


        # To double confirm no path in Keep List that exist in Del List
        toBeKeepRenderOutputList = list(set(toBeKeepRenderOutputList))
        toBeKeepRenderOutputList.sort()

        toBeDelRenderOutputList = list(set(toBeDelRenderOutputList))
        toBeDelRenderOutputList.sort()

        for i in toBeKeepRenderOutputList:
            if i in toBeDelRenderOutputList:
                toBeDelRenderOutputList.remove(i)


        '''
        for i in toBeDelRenderOutputList:
            self.printEcho(i)
        self.printEcho('\n\n<><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><\n\n')
        '''

        return toBeDelRenderOutputList, toBeKeepRenderOutputList


    def isEarlierThanKeepDays(self, inPath, inKeepDays):
        import datetime

        # ref : https://thispointer.com/python-get-last-modification-date-time-of-a-file-os-stat-os-path-getmtime/
        #filePath = r'N:\mnt\job\19901BigPicture_TestProj\WorkingFile\BigPicture19_TestProj\scenes\bensonSeq\tsq9010\components\comp\output'
        #keepDays = 50

        filePath = inPath
        keepDays = inKeepDays

        #modTimeStamp = os.path.getmtime(filePath)
        #currentTimeStamp = datetime.datetime.now().timestamp()
        createTimeStamp = os.path.getctime(filePath)
        creation_YYYYmmddHHMMSS = datetime.datetime.fromtimestamp(createTimeStamp).strftime('%Y-%m-%d %H:%M:%S')
        self.printEcho(creation_YYYYmmddHHMMSS)
        value_creation_YYYYmmddHHMMSS = datetime.datetime.strptime(creation_YYYYmmddHHMMSS, '%Y-%m-%d %H:%M:%S')

        #currentTimeStamp_YYYYmmddHHMMSS = datetime.datetime.fromtimestamp(currentTimeStamp).strftime('%Y-%m-%d %H:%M:%S')
        #value_currentTimeStamp_YYYYmmddHHMMSS = datetime.datetime.strptime(currentTimeStamp_YYYYmmddHHMMSS , '%Y-%m-%d %H:%M:%S')
        #println(currentTimeStamp_YYYYmmddHHMMSS)


        # found boundary date (currentTime - keepDays)
        currentTimeStamp = datetime.datetime.now().timestamp()
        currentTimeStamp_YYYYmmddHHMMSS = datetime.datetime.fromtimestamp(currentTimeStamp).strftime('%Y-%m-%d %H:%M:%S')
        self.printEcho(currentTimeStamp_YYYYmmddHHMMSS)
        value_currentTimeStamp_YYYYmmddHHMMSS = datetime.datetime.strptime(currentTimeStamp_YYYYmmddHHMMSS , '%Y-%m-%d %H:%M:%S')
        DayValue = datetime.timedelta(days=keepDays)
        boundryDate = value_currentTimeStamp_YYYYmmddHHMMSS - DayValue
        self.printEcho('boundryDate is : ')
        self.printEcho(boundryDate)

        # Same date count as NOT Earlier, tends to keep for safe.
        if (datetime.datetime.strptime(str(creation_YYYYmmddHHMMSS), '%Y-%m-%d %H:%M:%S') - datetime.datetime.strptime(str(boundryDate), '%Y-%m-%d %H:%M:%S')).days < -1:
            return True
        else:
            return False


    def cleanUpCheckFolderSize(self, inPathRoot):
        println('\ndef >>>>> cleanUpCheckFolderSize')
        self.printEcho(inPathRoot)
        sizeUnit = {'Bytes': 1, 'Kilobytes': float(1)/1024, 'Megabytes': float(1)/(1024*1024), 'Gigabytes': float(1)/(1024*1024*1024)}
        total_size = 0
        start_path = inPathRoot  # To get size of current directory
        checking = True
        filecounter = 0

        for path, dirs, files in os.walk(start_path):
            for f in files:
                filecounter += 1
                #println(filecounter)
            totalfiles = filecounter

        filecounter = 0

        for path, dirs, files in os.walk(start_path):
            for f in files:
                filecounter += 1
                ###println(start_path)
                fp = os.path.join(path, f)
                fileSize = os.path.getsize(fp)
                total_size += fileSize

                ###println('%d of %d   ---   %d' %(filecounter, totalfiles, (filecounter/totalfiles)*100.0) + '%')
                #println(start_path)
                ###println(str(fp))
                ###println('total_size in MB : %s' %str(total_size * float(sizeUnit['Megabytes'])))



        self.printEcho("Directory size in bytes: " + str(total_size))
        self.printEcho("Directory size in MB: " + str(total_size * float(sizeUnit['Megabytes'])))

        #msgBox.close()

        return total_size

    def cleanUpWriteToText(self, inPath, inHeader, inDelList, inKeepList):
        println('\ndef >>>>> cleanUpWriteToText')
        import datetime

        currentTimeStamp = datetime.datetime.now().timestamp()
        currentTimeStamp_YYYYmmddHHMMSS = datetime.datetime.fromtimestamp(currentTimeStamp).strftime('-D%Y-%m-%d_T%H%M%S')
        #filename = 'toBeDel' + currentTimeStamp_YYYYmmddHHMMSS + '.txt'
        #f = open(os.path.join(inPath, filename), 'w')
        f = open(inPath, 'w')
        for lines in inHeader:
            f.writelines('<bigK_header>...' + lines + '\n')
        for lines in inDelList:
            f.writelines('< del* >' + lines + '\n')
        for lines in inKeepList:
            f.writelines('< Keep >' + lines + '\n')
        f.close()
        #println('Text File written to <%s>' %os.path.join(inPath, filename))
        self.printEcho('Text File written to <%s>' %inPath)

        libPath = pathlib.Path(inPath)
        os.startfile(libPath.parent)


    def askExistingFolder(self, inDialogTitle, inStartFolder):
        println('\ndef >>>>> askExistingFolder')

        # getExistingDirectory returns a single string and '' on Cancel.
        # It is NOT the (fileName, selectedFilter) tuple that getOpenFileName returns.
        folderName = QFileDialog.getExistingDirectory(self, inDialogTitle, inStartFolder)

        self.printEcho('folderName : {}'.format(folderName))

        return folderName

    def askOpenFile(self):
        println('\ndef >>>>> askOpenFile')

        QMessageBox.information(self, 'Clean Up Comp Output', 'Warning !!!\n\n\nYou are about to mass DELETE folders!!!\n\n\n')

        # ref : https://pythonspot.com/pyqt5-file-dialog/
        options = QFileDialog.Options()
        #options |= QFileDialog.DontUseNativeDialog
        fileName, _ = QFileDialog.getOpenFileName(self,"QFileDialog.getOpenFileName()", "","All Files (*);;Python Files (*.py)", options=options)

        if fileName:
            self.printEcho(fileName)
            return fileName



    def askSaveFile(self, inName):

            # ref : https://pythonspot.com/pyqt5-file-dialog/
            options = QFileDialog.Options()
            #options |= QFileDialog.DontUseNativeDialog
            fileNamePrefix = inName
            fileName, _ = QFileDialog.getSaveFileName(self,"QFileDialog.getSaveFileName()", fileNamePrefix,"All Files (*);;Text Files (*.txt)", options=options)
            if fileName:
                self.printEcho(fileName)
                return fileName




    def cleanUpDelAction(self, inAction):
        #inAction is to decide : delAction / moveAction


        println('\ndef >>>>> cleanUpDelAction')


        import shutil

        '''
        theFile = self.askOpenFile()
        println(theFile)
        println(type(theFile))
        '''


        answerFolder = QInputDialog.getText(self, 'Input Folder Path', 'Please input the folder path containing ALL toBeDel_xxxxxxx.txt\n\n\n\n***** this is DELETE action. *****\n\n\n',QLineEdit.Normal)

        self.printEcho(answerFolder[0])
        self.printEcho(type(answerFolder[0]))

        allFiles = os.listdir(answerFolder[0])
        counter = 0
        delConfirm = False
        delToken = False
        moveConfirm = False
        moveToken = False

        while delToken == False and moveToken == False:

            if inAction == 'delAction':
                inputCheck = QInputDialog.getText(self, 'Double Confirmation', 'If you confirm to batch delete all files.\n\n input the following correctly:\n\n"Delete, confirm to delete a lot of files."\n\n\n',QLineEdit.Normal)
                if inputCheck[0] == 'Delete, confirm to delete a lot of files.':
                    delConfirm = True
                    delToken = True
            elif inAction == 'moveAction':

                moveDestPath, null = QInputDialog.getText(self, 'Input Destination Folder Path', 'Please input the move-destination folder path:',QLineEdit.Normal)
                moveDestPath = os.path.normpath(moveDestPath)
                self.printEcho('moveDestPath :{}'.format(moveDestPath))


                inputCheck = QInputDialog.getText(self, 'Double Confirmation', 'If you confirm to batch move all files.\n\n input the following correctly:\n\n"Move, confirm to move all."\n\n\n',QLineEdit.Normal)
                if inputCheck[0] == 'Move, confirm to move all.':
                    moveConfirm = True
                    moveToken = True


        if delConfirm == True or moveConfirm == True:

            # create _done directory to store the .txt
            doneFolder = os.path.join(answerFolder[0], '_done')
            if not os.path.exists(doneFolder):
                os.mkdir(doneFolder)
                self.printEcho(doneFolder ,  " --- Created ")


            for file in allFiles:

                theFile = os.path.join(answerFolder[0], file)
                self.printEcho(theFile)

                if theFile.endswith('.txt'):
                    f = open(theFile, 'r')
                    linePaths = []
                    QApplication.processEvents()
                    for line in f:
                        if not line.startswith('<bigK_header>') or not line.startswith('< KEEP >'):
                            if line.startswith('< del* >'):
                                counter += 1
                                targetPath = line.lstrip('< del* >').rstrip('\n')
                                linePaths.append(targetPath)
                                self.printEcho(str(counter) + 'line :' + targetPath)

                                if delConfirm == True:
                                    #ref : https://thispointer.com/python-how-to-delete-a-directory-recursively-using-shutil-rmtree/
                                    shutil.rmtree(targetPath, ignore_errors=True)

                                elif moveConfirm == True:
                                    QApplication.processEvents()
                                    combineMoveDestPath = os.path.join(moveDestPath, targetPath.replace(':', '_', 1))
                                    self.printEcho(combineMoveDestPath)
                                    QApplication.processEvents()

                                    #option A, run by shutil. but the UI freeze without repond
                                    shutil.move(targetPath, combineMoveDestPath)
                                    QApplication.processEvents()


                                    #option B, run by cmd, want to see respond
                                    #to be enhance

                                    fMove = open(os.path.join(doneFolder, '_LOG.txt'), 'a')
                                    fMove.writelines(str(line))
                                    fMove.close()

                                    QApplication.processEvents()
                                    pass

                        QApplication.processEvents()

                    f.close()

                    shutil.move(theFile, doneFolder)



        println('End of cleanUpDelAction.')


















    '''
    # ref: https://www.tutorialspoint.com/pyqt/pyqt_qinputdialog_widget.htm
    # ref: https://pythonspot.com/pyqt5-input-dialog/
    def ask(self):
        println('\ndef >>>>> ask')
        try:
            defaultText = self.answer[0]
        except:
            defaultText = ""
        self.answer = QInputDialog.getText(self, 'Input Folder Name', 'To create instance-shortcut for comment folder,\nformat: <yyyymmdd>\n\nor\n\nPress cancel to skip.',QLineEdit.Normal, defaultText)
        println(self.answer)

    def theAnswer(self):
        try:
            println('theAnswer')
            println(self.answer)
            println(type(self.answer))
        except:
            println('No Value.')'''


# The QT Child window class
class ChildWindow(UiPyChild.Ui_MainWindow, QMainWindow):
    def __init__(self, parent = None):
        super(ChildWindow, self).__init__(parent)
        self.setupUi(self)

# The QT window class for list out nukeWrongFormat
class subListView(UiList.Ui_MainWindow, QMainWindow):
    def __init__(self, parent = None):
        super(subListView, self).__init__(parent)
        self.setupUi(self)
        self.setWindowModality(Qt.ApplicationModal)


class SceneUpDateListView(UiListB.Ui_MainWindow, QMainWindow):
    def __init__(self, parent = None):
        super(SceneUpDateListView, self).__init__(parent)
        self.setupUi(self)
        #self.setWindowModality(Qt.ApplicationModal)

'''
class prerendKeywordListView(UiList.Ui_MainWindow, QMainWindow):
    def __init__(self, parent = None):
        super(prerendKeywordListView, self).__init__(parent)
        self.setupUi(self)
        self.setWindowModality(Qt.ApplicationModal)
        '''

class NewWIPDialogWindow(UiDialog.Ui_MainWindow, QMainWindow):
    def __init__(self, parent = None):
        super(NewWIPDialogWindow, self).__init__(parent)
        self.setupUi(self)

class doneWindow(UiDone.Ui_MainWindow, QMainWindow):
    def __init__(self, parent = None):
        super(doneWindow, self).__init__(parent)
        self.setupUi(self)
        self.setWindowModality(Qt.ApplicationModal)



class nukeTempWindow(UiNukeTemp.Ui_nukeReadNodeFrameInOut, QMainWindow):
    def __init__(self, parent = None):
        super(nukeTempWindow, self).__init__(parent)
        self.setupUi(self)
        #self.setWindowModality(Qt.ApplicationModal)


    def initializeNukeTempWindow(self):
        println('\ndef >>>>> initializeNukeTempWindow')
        self.pushButton_execute.clicked.connect(self.action)

    def LoadInOutFrame(self):
        println('\ndef >>>>> LoadInOutFrame')
        import bigKeeperInfoGlobal_published
        bigKInfo = bigKeeperInfoGlobal_published.bigKeepCLASS()
        self.lineEdit_NewFrameIn.setText(bigKInfo.currentShotFrameIn())
        self.lineEdit_NewFrameOut.setText(bigKInfo.currentShotFrameOut())


    def action(self):
        println('\ndef >>>>> action')

        if len(nuke.selectedNodes('Read')) < 1:
            QMessageBox.information(self, 'message', 'No "Read Node" is selected.')
            """if in_nuke:
                nuke.message('No "Read Node" is selected.')
            '''if in_maya:
                cmds.confirmDialog( title='Confirm', message='No "Read Node" is selected.', button=['OK'], defaultButton='OK')
            if in_houdini:
                hou.ui.displayMessage('No "Read Node" is selected.', buttons=('OK',), default_choice=0, close_choice=0)'''"""

        else:
            if self.lineEdit_NewFrameIn.text().isnumeric and self.lineEdit_NewFrameOut.text().isnumeric:
                FrameInInt = int(self.lineEdit_NewFrameIn.text())
                FrameOutInt = int(self.lineEdit_NewFrameOut.text())

                self.printEcho(FrameInInt)
                self.printEcho(FrameOutInt)

                counter = 0
                for n in nuke.selectedNodes('Read'):
                    n['first'].setValue(FrameInInt)
                    n['last'].setValue(FrameOutInt)
                    n['origfirst'].setValue(FrameInInt)
                    n['origlast'].setValue(FrameOutInt)
                    counter += 1

                if in_nuke:
                    msg = str(counter) + ' "Read Node" received.'
                    nuke.message(msg)

                self.close()

            else:

                if in_nuke:
                    nuke.message('Only accept Integer.')
                '''if in_maya:
                    cmds.confirmDialog( title='Confirm', message='Only accept Integer.', button=['OK'], defaultButton='OK')
                if in_houdini:
                    hou.ui.displayMessage('Only accept Integer.', buttons=('OK',), default_choice=0, close_choice=0)'''

class createShotNewTaskWindow(UiNewTask.Ui_MainWindow, QMainWindow):
    def __init__(self, parent = None):
        super(createShotNewTaskWindow, self).__init__(parent)
        println('my createShotNewTaskWindow - __init__')
        self.setupUi(self)
        self.label.setText('New Task Name :')
        #self.setWindowModality(Qt.ApplicationModal)

class nukeAskKeywordWindow(UiPreset.Ui_MainWindow, QMainWindow):
    def __init__(self, parent = None):
        super(nukeAskKeywordWindow, self).__init__(parent)
        println('my nukeAskKeywordWindow - __init__')
        #self.setWindowModality(Qt.ApplicationModal)
        self.setupUi(self)



def main():
    window = BigMainWindow()
    window.show()

    try:
        app.exec_()
    except:
        pass

if not in_houdini:
    if __name__ == "__main__":
        main()
else:
    main()






